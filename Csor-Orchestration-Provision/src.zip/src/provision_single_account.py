import argparse

from provision_task import provision_account
from utils import make_request
from config.config import Config

def parse_args():
    parser = argparse.ArgumentParser(
        description="Script to provision a single account in a single region"
    )
    parser.add_argument(
        "--env",
        type=str,
        help="The environment you want to submit to",
        choices=[
            "internal-dev",
            "internal-qa",
            "tenant-dev",
            "tenant-qa",
            "tenant-sand",
            "tenant-prod",
        ],
        required=True
    )
    parser.add_argument(
        "--account",
        type=str,
        help="The account id you want to provision",
        required=True
    )
    parser.add_argument(
        "--account-name",
        type=str,
        help="The account name you want to provision",
        required=True
    )
    parser.add_argument(
        "--user",
        type=str,
        help="Email for user who triggered pipeline",
        required=True,
    )
    parser.add_argument(
        "--region",
        type=str,
        help="Tenant region to create provision AWS resources",
        default="us-east-2"
    )

    return parser.parse_args()

def main(args):
    # Load Configs
    config = Config(args.env)

    # Logging
    logging = config.get_logging()

    user = args.user

    logging.info(
        "Attempting to run provision account %s(%s) in region %s",
        args.account_name,
        args.account,
        args.region
    )

    provision_result = provision_account(
        {
            "account_data": {"id": args.account, "region": args.region},
            "config": config,
            "env": args.env,
            "user": user
        }
    )

    if provision_result["success"]:
        logging.info(
            "Successfully provisioned account %s with result:\n%s\n",
            provision_result["id"],
            provision_result["result"],
        )
    else:
        logging.info(
            "Failed to provision account %s with result:\n%s\n",
            provision_result["id"],
            provision_result["result"],
        )
        raise RuntimeError(f"Failed to provision account {args.account_name}({args.account})")

    return 0

if __name__ == "__main__":
    main(parse_args())
