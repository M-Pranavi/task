import logging

from .global_constants import (
    BOM_FILENAME,
    JSON_CONFIG_PATH,
    LOGGING_LEVEL,
    MAX_THREADS,
    STATUS_QUERY,
)
from .utils import read_file


class Config:

    def __init__(self, env):
        self.env = env
        self.__MAX_THREADS = MAX_THREADS
        self.__JSON_CONFIG_PATH = JSON_CONFIG_PATH
        self.__STATUS_QUERY = STATUS_QUERY

        self.__logging = self.__config_logging()
        self.__bom = self.load_bom(BOM_FILENAME)
        self.__env_config = self.load_env_configs(env, "environments")

    # Set to Public for testing
    def load_bom(self, filename):
        return read_file(filename)

    # Set to Public for testing
    def load_env_configs(self, environment, config_file_prefix_path):
        env_config_filename = f"{config_file_prefix_path}/{environment}.json"
        environment_config = {}

        environment_config = read_file(env_config_filename)

        environment_config["bom"] = self.load_bom(BOM_FILENAME)

        return environment_config

    # Configure Logging
    def __config_logging(self):
        logging.basicConfig(format="%(threadName)s:%(message)s", level=LOGGING_LEVEL)
        return logging

    def get_env_config(self):
        return self.__env_config

    def get_bom(self):
        return self.__bom

    def get_logging(self):
        return self.__logging

    def get_max_threads(self):
        return self.__MAX_THREADS

    def get_json_config_path(self):
        return self.__JSON_CONFIG_PATH

    def get_status_query(self):
        return self.__STATUS_QUERY
