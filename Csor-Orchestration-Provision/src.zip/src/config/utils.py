import json


def read_file(filename):
    try:
        with open(filename, encoding="UTF-8") as json_file:
            content = json.load(json_file)
            return content
    except FileNotFoundError as e:
        raise FileNotFoundError(f"The file {filename} does not exist: {e}") from e
    except json.JSONDecodeError as e:
        raise json.JSONDecodeError(
            f"Failed to decode JSON from the file {filename}: {e}"
        ) from e
    except Exception as e:
        raise e
