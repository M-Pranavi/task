## GLOBAL CONSTANTS
MAX_THREADS = 10

## SOR Queries
STATUS_QUERY = """
query ($arn: String!) {
    statusByExecution(executionArn: $arn) {
        arn
        status
        stateMachineType
        startTime
        configurationDocument
        deployers {
            name
            status
            version
            outputs
        }
    }
}
"""

## BOM FILENAME
BOM_FILENAME = "bom.json"

## Path to <env>.json files. Parameterized because the path could be toggled during tests.
JSON_CONFIG_PATH = "environments"

## Logging Config
LOGGING_LEVEL = "INFO"
