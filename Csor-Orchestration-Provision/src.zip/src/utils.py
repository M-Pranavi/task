import json
import boto3  # type: ignore
import requests  # type: ignore
import urllib3  # type: ignore
from botocore.auth import SigV4Auth  # type: ignore
from botocore.awsrequest import AWSRequest  # type: ignore

urllib3.disable_warnings()

def make_request(method, url, data, role, region, user):
    awsrequest = AWSRequest(
        method=method,
        url=url,
        data=json.dumps(data),
    )

    session = boto3.Session(region_name=region)

    sts_client = boto3.client("sts")
    response = sts_client.assume_role(
        RoleArn=role, RoleSessionName=user
    )
    session = boto3.Session(
        aws_access_key_id=response["Credentials"]["AccessKeyId"],
        aws_secret_access_key=response["Credentials"]["SecretAccessKey"],
        aws_session_token=response["Credentials"]["SessionToken"],
        region_name=region,
    )

    SigV4Auth(session.get_credentials(), "execute-api", session.region_name).add_auth(
        awsrequest
    )
    response = requests.request(
        method=method,
        url=url,
        data=json.dumps(data),
        headers=awsrequest.headers,
        verify=False,
        timeout=10,
    )
    if response.status_code != 200:
        raise RuntimeError(
            f"Request failed with status code {response.status_code}. Response: {response.text}"
        )
    return response.content.decode("utf-8")
