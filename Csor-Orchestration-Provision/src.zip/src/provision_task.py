import copy
import json
import time

from utils import make_request

def wait_for_completion(execution_arn, config, status_query, logging, user):
    t_end = time.time() + 60 * config["max_wait_time_in_minutes"]

    while time.time() < t_end:
        query = {"query": status_query, "variables": {"arn": execution_arn}}

        try:
            response = make_request(
                "POST",
                config["sor_url"],
                query,
                config["orchestration_aws_assume_role"],
                config["sor_aws_region"],
                user,
            )
        except RuntimeError as e:
            logging.error(
                "Failed to query status of provision for arn %s", execution_arn
            )
            return False, e

        if not (execution := json.loads(response)["data"]["statusByExecution"]):
            logging.error(
                "Failed to query status of provision for arn %s", execution_arn
            )
            return False, f"Execution ARN: {execution_arn} does not exist"

        status = execution["status"]

        if status == "SUCCEEDED":
            return True, execution

        if status in set(["TIMED_OUT", "FAILED", "ABORTED"]):
            logging.error(
                "Provision execution %s failed with status %s", execution_arn, status
            )
            return False, execution

        logging.info("Provision execution %s is still running.", execution_arn)
        time.sleep(30)

    return False, f"Execution {execution_arn} failed to complete in allotted time."


def provision_account(task_data):
    account_id = task_data["account_data"]["id"]
    config = task_data["config"].get_env_config()
    status_query = task_data["config"].get_status_query()
    environment = task_data["env"]
    logging = task_data["config"].get_logging()
    user = task_data["user"]

    bom = copy.deepcopy(config["bom"])
    bom["account"] = account_id
    bom["region"] = task_data["account_data"]["region"]
    bom["eks"] = "true"

    logging.info("Using BOM for account %s:\n %s\n", account_id, bom)

    try:
        response = make_request(
            "POST",
            config["orchestration_url"],
            bom,
            config["orchestration_aws_assume_role"],
            config["orchestration_aws_region"],
            user,
        )
    except RuntimeError as e:
        logging.error("Failed to submit provision for account %s", account_id)
        return {"id": account_id, "success": False, "result": e}

    execution_arn = json.loads(response)['resourceId']
    logging.info("Recieved execution arn %s", execution_arn)
    success, result = wait_for_completion(execution_arn, config, status_query, logging, user)

    return {"id": account_id, "success": success, "result": result}
