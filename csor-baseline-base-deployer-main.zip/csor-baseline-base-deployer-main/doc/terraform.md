<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 5.0 |
| <a name="requirement_external"></a> [external](#requirement\_external) | ~> 2.2 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 5.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_config_config_rule.cloudtrail](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/config_config_rule) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_assume_role_arn"></a> [assume\_role\_arn](#input\_assume\_role\_arn) | Role that is assumed by terraform before deploying resources. | `string` | `"arn:aws:iam::081297776604:role/logging_deployer_role"` | no |
| <a name="input_config_lambda_arn"></a> [config\_lambda\_arn](#input\_config\_lambda\_arn) | (Required) Config Lambda rule ARN | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | AWS region that resources are deployed to. | `string` | `"us-east-2"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to be applied to resources. | `map` | <pre>{<br>  "repo": "braintree/config-terraform"<br>}</pre> | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
