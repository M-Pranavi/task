#!/bin/bash

report_status_to_graphql() {
  TASK_STATUS="$1"
  csor_report \
    --deployer $DEPLOYER_NAME \
    --version $DEPLOYER_VERSION \
    --execution-arn $EXECUTION_ID \
    --graphql-endpoint $SOR_ENDPOINT \
    --region $ORCHESTRATION_REGION \
    --status $TASK_STATUS
  return $?
}

get_account_tags() {
  csor_get_tags \
    --graphql-endpoint "$SOR_ENDPOINT" \
    --account "$ACCOUNT_NUMBER"
  return $?
}

acquire_terraform_lock() {
  csor_terraform_lock \
    --dynamodb_table $DYNAMODB_GLOBAL_DEPLOYER_LOCK \
    --lock_id $TERRAFORM_LOCK \
    --region $ORCHESTRATION_REGION \
    --tenant_region $TENANT_REGION
}

release_terraform_lock() {
  csor_terraform_lock \
    --dynamodb_table $DYNAMODB_GLOBAL_DEPLOYER_LOCK \
    --lock_id $TERRAFORM_LOCK \
    --region $ORCHESTRATION_REGION \
    --tenant_region $TENANT_REGION \
    --release
}

run_change_approval() {
  csor_create_change_approval \
    --region $ORCHESTRATION_REGION \
    --tenant-region $ORCHESTRATION_REGION \
    --execution-arn $EXECUTION_ID \
    --graphql-endpoint $SOR_ENDPOINT \
    --tenant-account $ACCOUNT_NUMBER \
    --deployer $DEPLOYER_NAME \
    --bucket $TERRAFORM_PLAN_BUCKET \
    --version $DEPLOYER_VERSION \
    --state-machine-type "baseline" \
    --requestor $REQUESTOR \
    --change-type "Terraform" \
    --repository "https://github.com/PayPal-Braintree/csor-baseline-base-deployer"
  return $?
}

close_change_approval() {
  SUCCESS=$1
  csor_close_change_approval \
    --success $SUCCESS \
    --tenant-account $ACCOUNT_NUMBER \
    --execution-arn $EXECUTION_ID \
    --graphql-endpoint $SOR_ENDPOINT \
    --deployer $DEPLOYER_NAME \
    --region $ORCHESTRATION_REGION
  return $?
}

get_deployer_inputs() {
  csor_get_deployer_inputs \
    --execution-arn "$EXECUTION_ID" \
    --graphql-endpoint "$SOR_ENDPOINT" \
    --account-id "$ACCOUNT_NUMBER" \
    --state-machine-type "baseline"
  return $?
}

exit_if_failed() {
  EXIT_CODE="$1"
  MESSAGE="$2"
  if [ "$EXIT_CODE" -ne 0 ]; then
    echo "$MESSAGE"
    echo "Releasing terraform lock $TERRAFORM_LOCK"
    release_terraform_lock
    close_change_approval false
    report_status_to_graphql "Failed"
    if [ $? -ne 0 ]; then
      echo "Failed to report status to graphql while exiting"
    fi
    exit 1
  fi
}

csor_scripts_version=$(pip freeze | grep csor-deployer-scripts)
echo "Running with csor-deployer-scripts version ${csor_scripts_version}"

report_status_to_graphql "In_Progress"
exit_if_failed $? "Failed to report status to graphql"

if [[ -n "${EXECUTION_ID}" ]]; then
  echo "Getting account tags"
  get_account_tags
  exit_if_failed $? "Failed to get account tags"

  echo "Getting inputs"
  get_deployer_inputs
  exit_if_failed $? "Failed to get deployer inputs"
fi

terraform init \
  -backend-config="bucket=$BUCKET_TERRAFORM_STATE" \
  -backend-config="key=${ACCOUNT_NUMBER}/${ORCHESTRATION_REGION}/${KEY_TERRAFORM_STATE}" \
  -backend-config="region=$ORCHESTRATION_REGION" \
  -backend-config="dynamodb_table=$TERRAFORM_DYNAMODB_LOCK" \
  -no-color
exit_if_failed $? "Terraform init failed"

TERRAFORM_LOCK="${ACCOUNT_NUMBER}-baseline-${DEPLOYER_NAME}"
echo "Acquiring terraform lock $TERRAFORM_LOCK"
acquire_terraform_lock
exit_if_failed $? "Acquiring terraform lock failed"

if [[ "$DESTROY" == "true" ]]; then
  echo "Destroy mode enabled. Executing terraform destroy..."

  terraform destroy \
    -var-file="csor-data.tfvars.json" \
    -auto-approve \
    -no-color
  exit_if_failed $? "Terraform destroy failed"

  echo "Releasing terraform lock $TERRAFORM_LOCK"
  release_terraform_lock

  report_status_to_graphql "Destroy_Success"
  exit_if_failed $? "Failed to report destroy status to graphql"

  close_change_approval true

  exit 0
fi

echo "Destroy flag not set. Proceeding with terraform plan only for approval..."

terraform plan \
  -var-file="csor-data.tfvars.json" \
  -var="region=$ORCHESTRATION_REGION" \
  -out=plan.tfplan \
  -no-color
exit_if_failed $? "Terraform plan failed"

if [[ -n "${EXECUTION_ID}" && -f plan.tfplan ]]; then
  terraform show -json plan.tfplan > "${EXECUTION_ID}.json"
  exit_if_failed $? "Terraform show before apply failed"

  aws s3 cp "${EXECUTION_ID}.json" "s3://${TERRAFORM_PLAN_BUCKET}/${ACCOUNT_NUMBER}/${ORCHESTRATION_REGION}/${DEPLOYER_NAME}/${EXECUTION_ID}.json"
  exit_if_failed $? "Failed to upload plan to S3"

  run_change_approval
  exit_if_failed $? "Failed to generate SNOW ticket."
fi

echo "User approved. Proceeding with terraform apply..."

terraform apply \
  -no-color \
  plan.tfplan
exit_if_failed $? "Terraform apply failed"

terraform show -json > terraform_state.json
exit_if_failed $? "Terraform show after apply failed"

terraform output -json > terraform_output.json
exit_if_failed $? "Terraform output failed"

echo "Releasing terraform lock $TERRAFORM_LOCK"
release_terraform_lock

report_status_to_graphql "Success"
exit_if_failed $? "Failed to report status to graphql"

close_change_approval true

exit 0
