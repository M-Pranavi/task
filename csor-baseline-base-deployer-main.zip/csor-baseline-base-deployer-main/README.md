# csor-baseline-base-deployer

This repository manages all the code related to the base deployer for Cloud System of Record (CSoR).

---

## Table of Contents

- [Description](#description)
- [Prerequisites](#requirements)
- [Usage](#usage)
- [Release Process](#release)
- [Publish Artifact](#publish-artifact)
- [Contributing](#contributing)
- [Contact](#contact)

---

## Description

Base deployer will be a deployer that is part of the CSoR's orchestration engine and will be a part of the orchestration state machine.

The deployer will create IAM roles that will be used by the other deployers within CSoR orchestration.


This repository contains x components:
| Directory | Description |
| --- | --- |
| `infrastructure/` | All IaC code (terraform) |

The deploy is managed by Jenkins `./JenkinsFile`.
- **PR** Request in this repo will trigger a pipeline run to TF Checks and TF Plan in the **Dev environment**
- **PR** Merge in this repo will trigger a pipeline run to TF Apply in the **Dev environment**

## Requirements

- Teraform >= 1.5
- Python 3.10


## Usage
Jenkins pipeline is using a Docker images created in the dockerfiles repository called [csor_tooling](https://github.com/PayPal-Braintree/dockerfiles/blob/main/app_base/csor_tooling/). The images are passed as an environment variable in .JenkinsFile

```pipeline {
  agent any
  environment {
    CSOR_TOOLING_IMAGE = "dockerhub.braintree.tools/bt/csor-tooling:latest"
  }
```
- [CSOR_TOOLING_IMAGE docker file](https://github.com/PayPal-Braintree/dockerfiles/blob/main/app_base/csor_tooling/Dockerfile) - This one is used for all Terraform stages in Jenkins.

When running a pipeline from this repo, some terraform check will be executed
- TFLINT
- TFSEC

The TFLINT is using the .tflinh.hcl file to enable to aws linter, as follow

```
plugin "aws" {
  enabled = true
  version = "0.27.0"
  source  = "github.com/terraform-linters/tflint-ruleset-aws"
}
```

Both TFLINT and TFSEC are executed in the TFSCAN jenkins pipeline stage, warnings will appear in the pipeline output, the pipeline wont break when warnings are detected. Also both tools are installed in the CSOR_TOOLING_IMAGE docker image, that is the one used by jenkins to run the pipeline.

## Release

Runbook to release a deployer version:
https://github.com/PayPal-Braintree/csor-deployers-scripts?tab=readme-ov-file#deployer-version-release-script

## Publish Artifact

### Name
A deployer can publish two types of zip artifacts to S3:
1. GitSHA artifact - ^.+_deployer-<GitSHA>.zip$` (For testing, these can be overwritten)
2. Versioned artifact - `^.+_deployer-\d+-\d+-\d+.zip$` (For deployment, these have a S3 legal hold and cannot be overwritten)

### Contents
A deployer artifact must be a zip with the following structure
- An `infrastructure` folder with all the Terraform code
- All required code and dependencies must either be included in the zip file or pre-installed in a top-level `entrypoint.sh` script

### Steps
An infra team must then carry out the following steps on a cpair/terminal to publish a zip artifact to S3:

1. Zip the `infrastructure` folder, into a zip artifact in one of the [name formats](#name)
```
zip -r baseline_base_deployer-0-1-0.zip` infrastructure
```

2. Login to the `dev` orchestration account that holds the artifact S3 bucket
```
cagent login csor-orchestration-tenant-dev
```

3. Publish the zip artifact to S3 using `csorcli publish`
```
% csorcli publish -e dev -f baseline_base_deployer-0-1-0.zip
{
  "status": "success",
  "message": "Uploaded baseline_base_deployer-0-1-0.zip to S3 bucket csor-deployer-artifacts-339712721196 with legal hold",
  "s3_path": "s3://csor-deployer-artifacts-339712721196/baseline_base_deployer/baseline_base_deployer-0-1-0.zip",
  "version": "0.1.0"
}
```

### Deployment
The CSoR team is responsible for unzipping this artifact and setting up the specified terraform infrastructure in the AWS account when the deployer runs as part of the state machine.

## Contributing

To contribute in this repository, ensure you have access to it. Open a Pull request with your proposed changes, this PR will be reviewed by the bt-cloud-infra team.

Also ensure that you open you PR following the bellow:

- [Development Standards](https://engineering.paypalcorp.com/confluence/display/Braintree/Simple+Development+Standards)
- Add the items you changed in your PR to the CHANGELOG.md file
- CHANGELOG update is checked during PR build


### General Guidelines


- Ensure that you are familiar with the project's objective and architecture before making significant changes.
- Maintain a consistent coding style and follow the conventions adopted by the team.

## Contact

<bt-cloud-infra@paypal.com>

## Note on Git Tags

Due to [DTBTCOPS-1217](https://paypal.atlassian.net/browse/DTBTCOPS-1217), git tag references have been updated to the following. Only the Jenkinsfile has been modified to remove the upstream trigger. No other code has been changed. The git history is preserved because no commits are being deleted.

| Tag | Original SHA | Updated SHA |
| --- | --- | --- |
| [0.1.0](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.0) | [05c5b6869dd916351bbb50c83006d6a6dc0eac86](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/05c5b6869dd916351bbb50c83006d6a6dc0eac86) | [74cd3e5b1c45a5f8d800da3436d71723922d41a5](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/74cd3e5b1c45a5f8d800da3436d71723922d41a5) |
| [0.1.1](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.1) | [69eac8de307f6fb9d5f43089f871fc5a0dbc5a1b](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/69eac8de307f6fb9d5f43089f871fc5a0dbc5a1b) | [7ee23a5d903e4b1d69a8545d5fdfa6cd10be3d83](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/7ee23a5d903e4b1d69a8545d5fdfa6cd10be3d83) |
| [0.1.2](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.2) | [9f584536696c0a59196b73e59fdbddfb74eecd7b](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/9f584536696c0a59196b73e59fdbddfb74eecd7b) | [a2eafc529315bdb2fddcae9ef741575824936ab5](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/a2eafc529315bdb2fddcae9ef741575824936ab5) |
| [0.1.3](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.3) | [e7805755250e356a9b653e02c744c8366b4432ee](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/e7805755250e356a9b653e02c744c8366b4432ee) | [e2604f5f61f4f5ad90505886df71f3081882ad09](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/e2604f5f61f4f5ad90505886df71f3081882ad09) |
| [0.1.4](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.4) | [e3dd40879362c3a2bcd21ddcaa923369b26c87a1](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/e3dd40879362c3a2bcd21ddcaa923369b26c87a1) | [65af2fbed298735856cf1f9b504fad3747382777](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/65af2fbed298735856cf1f9b504fad3747382777) |
| [0.1.5](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.5) | [e3dd40879362c3a2bcd21ddcaa923369b26c87a1](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/e3dd40879362c3a2bcd21ddcaa923369b26c87a1) | [4d990f25f153ac40a3e88a7968e7fb2fa986185a](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/4d990f25f153ac40a3e88a7968e7fb2fa986185a) |
| [0.1.6](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.6) | [83ba242d288d30378a4151bb1af0c77002afe9b7](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/83ba242d288d30378a4151bb1af0c77002afe9b7) | [a778c4e2e775a4f9c370a7f2180d68d560618dbe](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/a778c4e2e775a4f9c370a7f2180d68d560618dbe) |
| [0.1.7](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.7) | [e85a085f0d127f9d3a81a8c56117dbb595740fdb](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/e85a085f0d127f9d3a81a8c56117dbb595740fdb) | [2c34f5d4538b108257be17673e8d391ca90ebf14](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/2c34f5d4538b108257be17673e8d391ca90ebf14) |
| [0.1.8](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/tree/0.1.8) | [57e63f288278208714c08dff1f63c26aac027df1](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/57e63f288278208714c08dff1f63c26aac027df1) | [006a58e1eb620ddc0c4bbd0e082086ce90c500a8](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/commit/006a58e1eb620ddc0c4bbd0e082086ce90c500a8) |
