# CSoR Baseline Base Deployer Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
- Update Jenkins pipeline to publish framework artifact

## [0.1.27](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.26...0.1.27)
- Remove references the use of the serverless framework for python packaging
- Create cpair role for Chargehound accounts

## [0.1.26](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.25...0.1.26)
- Removal of assume_scoped_role_root
- Pin version for providers

## [0.1.25](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.24...0.1.25)
- Cutting over cagent role from root to base for infra-sso
- Remove creation of `service-now-discovery-connector` IAM role

## [0.1.24](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.23...0.1.24)
- Fix entrypoint.sh to insert destroy flag for manual deletion

## [0.1.23](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.22...0.1.23)
- Only create cpair IAM role for Braintree accounts

## [0.1.22](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.21...0.1.22)
- Create `service_now_connector_read_access` IAM role only for Braintree AWS accounts

## [0.1.21](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.20...0.1.21)
- Fix UntagResource permission to proper UntagLogGroup permission for shield deployer

## [0.1.20](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.19...0.1.20)
- Add UntagResource permission to shield deployer
- Migrate to the generic deployer framework

## [0.1.19](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.18...0.1.19)
- Creating CHANGELOG file and and mandatory check to ensure it is updated during PR build 
- Do not create `service_now_connector_read_access` IAM role for Chargehound accounts
- Fix typo in business unit name and fix incorrect logic creating `service_now_connector_read_access` IAM role

## [0.1.18](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.16...0.1.18) 
- Update Terraform Version to 1.11.3

## [0.1.17](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.14...0.1.17) 
- Narrow the cpair trust policy
- Change docker image to CSOR_TOOLING_IMAGE

## [0.1.15](https://github.com/PayPal-Braintree/csor-baseline-base-deployer/compare/0.1.13...0.1.15) 
- Add service now discovery role to tenant accounts
