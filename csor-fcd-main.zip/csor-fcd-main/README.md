# csor-fcd

[![Build Status](https://ci.braintree.tools/buildStatus/icon?job=paypal-braintree%2Fcsor-fcd%2Fmain)](https://ci.braintree.tools/job/PayPal-Braintree/job/csor-fcd/job/main/)


This repository will contain the most up-to-date fcd.json file, which we will use as our stable FCD for orchestration baseline. A bash script to be used in Jenkins that submits baselines for the stable FCD in a particular environment based on configurations given to it by the Jenkins stage, and finally, a Jenkinsfile that houses a pipeline to apply a new stable FCD to all accounts in all environments.

This repository will be owned the CloudNX team and CloudNX team ONLY will be able to merge changes to this repo. However, deployer teams should be able to open up change requests to the repo so they can update their respective deployer versions and have those versions automatically applied to all accounts.

The pipeline that exists in this repo is of utmost importance to our platform, therefore we should at a minimum have some sort of alerting mechanism for any pipeline failures and a way to block any new updates if the last run on main is not green. In the future, ideally this pipeline would be hooked up to CloudNX pagerduty, so on failure the on-call engineer can immediately start triage and working with other teams to resolve the issues.

## Stable Deployer Versions 

[Stable FCD](fcd.json)


## Developers Guide
This repository contains the following components:

#### csor-fcd
| Directory     | Description                                   |
| ---           | ---                                           |
| `src/`        | Python files for baselining accounts          |
| `test/`       | Unit tests                                    |
| `config/`     | Environment specific configurations           |
| `bin/`        | Bash Scripts required for Jenkins Pipeline Build                                                           |
| `fcd.json`    | Stable FCD                                    |
| `docs`        | Additional Documentation/Images               |

#### bin/ci Folder

| Directory         | Description                           |
| ---               | ---                                   |
| `docker.sh`       | Docker setup to run script files during Jenkins Pipeline Build                            |
| `baseline_accounts.sh` | Script to invoke src/baseline_accounts.py  |
| `run_tests.sh`     | Script to invoke Pytests  |


#### src Folder

| Directory                     | Description                                   |
| ---                           | ---                                           |
| `config/`                     | Global Constants and Configurations needed for Baselining   |
| `argument_parser.py`          | Argument Parser                               |
| `baseline_accounts.py`        | Main file for baselining accounts             |
| `baseline_task.py`            | Baseline Task Details                       |
| `load_accounts.py`            | Load Accounts from SOR                        |


#### config Folder

| Directory                     | Description                           |
| ---                           | ---                                   |
| `global_constants.py`         | All Global Constants defined here     |
| `config.py`                   | Config Class loading all constants and configurations                       |
| `uitls.py`                    | Utils for Config Class                |

#### Architectural Flow

![Architectural Flow](./docs/csor_fcd_flow.png)

## Contacts
Email: cloudnx@paypal.com

Slack channel: #bt-csor-collab

## Continuous Integration
[Jenkins CI](https://ci.braintree.tools/blue/organizations/jenkins/PayPal-Braintree%2Fcsor-fcd/activity)


## References

- [CSOR-FCD: Final Design](https://paypal.atlassian.net/wiki/spaces/BTSRE/pages/1008028910/CSOR-FCD+Final+Design)
