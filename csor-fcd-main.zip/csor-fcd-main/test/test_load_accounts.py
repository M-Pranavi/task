import json
import os
from json import load
from unittest.mock import patch

from src.config.config import Config
from src.load_accounts import load_accounts


@patch("src.load_accounts.make_request")
def test_load_account_with_end_to_end(mock_make_request):
    config = Config("internal-dev")

    mock_graphql_response = {
        "data": {
            "accounts": [
                {
                    "id": "081297776604",
                    "name": "dev-bt-app1",
                    "baselineChangeApprovalRequired": False,
                }
            ]
        }
    }
    json_str = json.dumps(mock_graphql_response)
    mock_make_request.return_value = json_str.encode("utf-8")

    accounts = load_accounts(config, True, True, "dev person")
    expected_accounts = [{"id": "081297776604", "name": "dev-bt-app1"}]
    assert accounts == expected_accounts


@patch("src.load_accounts.make_request")
def test_load_accounts_with_no_end_to_end(mock_make_request):
    config = Config("internal-dev")

    mock_graphql_response = {
        "data": {
            "accounts": [
                {
                    "id": "account_1",
                    "name": "Account 1",
                    "baselineChangeApprovalRequired": True,
                },
                {
                    "id": "831145966718",
                    "name": "Denied Account",
                    "baselineChangeApprovalRequired": True,
                },
                {
                    "id": "account_2",
                    "name": "Account 2",
                    "baselineChangeApprovalRequired": False,
                },
                {
                    "id": "992382467107",
                    "name": "End to End Account",
                    "baselineChangeApprovalRequired": False,
                }
            ]
        }
    }
    json_str = json.dumps(mock_graphql_response)
    mock_make_request.return_value = json_str.encode("utf-8")

    accounts = load_accounts(config, True, False, "dev person")
    expected_accounts = [{"id": "account_1", "name": "Account 1"}]
    assert accounts == expected_accounts

    accounts = load_accounts(config, False, False, "dev person")
    expected_accounts = [{"id": "account_2", "name": "Account 2"}]
    assert accounts == expected_accounts
