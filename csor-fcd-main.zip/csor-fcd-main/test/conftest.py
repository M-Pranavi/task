from test.factory import FactoryUtil

import pytest  # type: ignore


@pytest.fixture(scope="function")
def factory(request):
    env = request.param
    factory = FactoryUtil(env)
    try:
        yield factory
    finally:
        # cleanup if any
        pass
