import pytest  # type: ignore


@pytest.mark.parametrize("factory", ["internal-dev"], indirect=True)
def test_load_wrong_fcd(factory):
    with pytest.raises(FileNotFoundError):
        factory.set_fcd("wrong-fcd.json")


@pytest.mark.parametrize("factory", ["internal-dev"], indirect=True)
def test_load_empty_fcd_json(factory):
    with pytest.raises(TypeError):
        factory.set_fcd("test/resources/invalid-empty-fcd.json")


@pytest.mark.parametrize("factory", ["internal-dev"], indirect=True)
def test_load_empty_config_json(factory):
    with pytest.raises(TypeError):
        factory.set_env_config("invalid-empty-config", "test/resources")


@pytest.mark.parametrize("factory", ["internal-dev"], indirect=True)
def test_load_internal_dev_config(factory):
    configs = factory.get_configs()
    assert len(configs) == 9
    assert (
        configs["orchestration_url"]
        == "https://v4g1gd0jni-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_orchestration/baseline"
    )
    assert configs["orchestration_aws_region"] == "us-east-2"
    assert (
        configs["orchestration_aws_assume_role"]
        == "arn:aws:iam::614751254790:role/csor-nonprod-dev-jenkins-service-account-role"
    )
    assert (
        configs["sor_url"]
        == "https://jc36bzfu99-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_sor/graphql"
    )
    assert configs["sor_aws_region"] == "us-east-2"
    assert configs["parallelism"] == 10
    assert configs["max_wait_time_in_minutes"] == 20
    assert configs["end_to_end_account"] == "992382467107"


@pytest.mark.parametrize("factory", ["internal-qa"], indirect=True)
def test_load_internal_qa_config(factory):
    configs = factory.get_configs()
    assert len(configs) == 9

    assert (
        configs["orchestration_url"]
        == "https://em6lrx4ov6-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_orchestration/baseline"
    )
    assert configs["orchestration_aws_region"] == "us-east-2"
    assert (
        configs["orchestration_aws_assume_role"]
        == "arn:aws:iam::381492044061:role/csor-orchestration-qa-jenkins-service-account-role"
    )
    assert (
        configs["sor_url"]
        == "https://wpkjswnpd1-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_sor/graphql"
    )
    assert configs["sor_aws_region"] == "us-east-2"
    assert configs["parallelism"] == 10
    assert configs["max_wait_time_in_minutes"] == 20
    assert configs["end_to_end_account"] == "262417653833"


@pytest.mark.parametrize("factory", ["tenant-dev"], indirect=True)
def test_load_tenant_dev_config(factory):
    configs = factory.get_configs()
    assert len(configs) == 9

    assert (
        configs["orchestration_url"]
        == "https://lpu51vqtmk-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_orchestration/baseline"
    )
    assert configs["orchestration_aws_region"] == "us-east-2"
    assert (
        configs["orchestration_aws_assume_role"]
        == "arn:aws:iam::339712721196:role/csor-orchestration-tenant-dev-jenkins-service-account-role"
    )
    assert (
        configs["sor_url"]
        == "https://sy6pj2y5gb-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_sor/graphql"
    )
    assert configs["sor_aws_region"] == "us-east-2"
    assert configs["parallelism"] == 4
    assert configs["max_wait_time_in_minutes"] == 20
    assert configs["end_to_end_account"] == "730335412120"


@pytest.mark.parametrize("factory", ["tenant-qa"], indirect=True)
def test_load_tenant_qa_config(factory):
    configs = factory.get_configs()
    assert len(configs) == 9

    assert (
        configs["orchestration_url"]
        == "https://bhxnaup753-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_orchestration/baseline"
    )
    assert configs["orchestration_aws_region"] == "us-east-2"
    assert (
        configs["orchestration_aws_assume_role"]
        == "arn:aws:iam::891377279854:role/csor-orchestration-tenant-qa-jenkins-service-account-role"
    )
    assert (
        configs["sor_url"]
        == "https://dii9nbiw43-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_sor/graphql"
    )
    assert configs["sor_aws_region"] == "us-east-2"
    assert configs["parallelism"] == 4
    assert configs["max_wait_time_in_minutes"] == 20
    assert configs["end_to_end_account"] == "590183724737"


@pytest.mark.parametrize("factory", ["tenant-sand"], indirect=True)
def test_load_tenant_sand_config(factory):
    configs = factory.get_configs()
    assert len(configs) == 9

    assert (
        configs["orchestration_url"]
        == "https://x4sg9p08nb-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_orchestration/baseline"
    )
    assert configs["orchestration_aws_region"] == "us-east-2"
    assert (
        configs["orchestration_aws_assume_role"]
        == "arn:aws:iam::339713027185:role/csor-orchestration-tenant-sand-jenkins-service-account-role"
    )
    assert (
        configs["sor_url"]
        == "https://bh4er4sc53-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_sor/graphql"
    )
    assert configs["sor_aws_region"] == "us-east-2"
    assert configs["parallelism"] == 2
    assert configs["max_wait_time_in_minutes"] == 20
    assert configs["end_to_end_account"] == "767397851611"


@pytest.mark.parametrize("factory", ["tenant-prod"], indirect=True)
def test_load_tenant_prod_config(factory):
    configs = factory.get_configs()
    assert len(configs) == 9

    assert (
        configs["orchestration_url"]
        == "https://n4jtsh20r9-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_orchestration/baseline"
    )
    assert configs["orchestration_aws_region"] == "us-east-2"
    assert (
        configs["orchestration_aws_assume_role"]
        == "arn:aws:iam::339712719475:role/csor-orchestration-tenant-prod-jenkins-service-account-role"
    )
    assert (
        configs["sor_url"]
        == "https://extz10neji-vpce-0a8103716a6bb595d.execute-api.us-east-2.amazonaws.com/csor_sor/graphql"
    )
    assert configs["sor_aws_region"] == "us-east-2"
    assert configs["parallelism"] == 2
    assert configs["max_wait_time_in_minutes"] == 20
    assert configs["end_to_end_account"] == "533267054952"
