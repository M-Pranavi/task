from unittest.mock import patch

import pytest

from src.argument_parser import parse_args


def test_env_only():
    test_args = ["baseline_accounts.py", "--env", "internal-dev", "--user", "dev person"]
    with patch("sys.argv", test_args):
        args = parse_args()
        assert args.env == "internal-dev"
        assert args.change_approval == False
        assert args.end_to_end == False


def test_env_with_change_approval():
    test_args = [
        "baseline_accounts.py",
        "--env",
        "tenant-dev",
        "--change-approval",
        "--user",
        "dev person",
    ]
    with patch("sys.argv", test_args):
        args = parse_args()
        assert args.env == "tenant-dev"
        assert args.change_approval == True
        assert args.end_to_end == False


def test_env_with_account():
    test_args = [
        "baseline_accounts.py",
        "--env",
        "tenant-qa",
        "--end-to-end",
        "--user",
        "dev person",
    ]
    with patch("sys.argv", test_args):
        args = parse_args()
        assert args.env == "tenant-qa"
        assert args.change_approval == False
        assert args.end_to_end == True


def test_all_args():
    test_args = [
        "baseline_accounts.py",
        "--env",
        "tenant-prod",
        "--change-approval",
        "--end-to-end",
        "--user",
        "dev person",
    ]
    with patch("sys.argv", test_args):
        args = parse_args()
        assert args.env == "tenant-prod"
        assert args.change_approval == True
        assert args.end_to_end == True


def test_missing_required_env():
    test_args = ["bin/ci/baseline_accounts.sh", "--change-approval"]
    with patch("sys.argv", test_args):
        # argparse should exit with error
        with pytest.raises(SystemExit):
            parse_args()
