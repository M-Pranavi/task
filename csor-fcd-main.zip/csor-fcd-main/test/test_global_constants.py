import pytest  # type: ignore

from src.config.global_constants import ACCOUNT_DENYLIST, MAX_THREADS


@pytest.mark.parametrize("factory", ["internal-dev"], indirect=True)
def test_global_contants(factory):
    assert factory.get_max_threads() == MAX_THREADS

    assert len(factory.get_env_map()) == 6
    assert factory.get_env_map()["internal-dev"] == "DEV"
    assert factory.get_env_map()["internal-qa"] == "QA"
    assert factory.get_env_map()["tenant-dev"] == "DEV"
    assert factory.get_env_map()["tenant-qa"] == "QA"
    assert factory.get_env_map()["tenant-sand"] == "SAND"
    assert factory.get_env_map()["tenant-prod"] == "PROD"

    assert len(ACCOUNT_DENYLIST) == 2
    expected_deny_list = [
        "831145966718",  # dev-bt-runtime-services
        "123456789123",  # doc-test-app
    ]
    for element in expected_deny_list:
        assert (
            element in factory.get_account_denylist()
        ), f"Element {element} is missing from the list"

    queries = factory.get_sor_queries()  # type: ignore

    assert len(queries) == 3

    assert (
        queries["ACCOUNTS_QUERY"]
        == """
{
    accounts(businessUnit: "Braintree") {
        id
        name
        baselineChangeApprovalRequired
    }
}
"""
    )

    assert (
        queries["SINGLE_ACCOUNT_QUERY"]
        == """
query ($id: String!) {
    accounts(id: $id) {
        id
        name
        baselineChangeApprovalRequired
    }
}
"""
    )

    assert (
        queries["STATUS_QUERY"]
        == """
query ($arn: String!) {
    statusByExecution(executionArn: $arn) {
        arn
        status
        stateMachineType
        startTime
        configurationDocument
        deployers {
            name
            status
            version
            outputs
        }
    }
}
"""
    )
