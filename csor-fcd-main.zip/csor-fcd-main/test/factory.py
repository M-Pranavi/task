from src.config.config import Config


class FactoryUtil:
    def __init__(self, env):
        self.__configs = Config(env)

    def get_full_config_map(self):
        return self.__configs

    def get_logging(self):
        return self.__configs.get_logging()

    def get_fcd(self):
        return self.__configs.get_fcd()

    def get_configs(self):
        return self.__configs.get_env_config()

    def set_fcd(self, filename):
        return self.__configs.load_fcd(filename)

    def set_env_config(self, environment, config_file_prefix_path):
        return self.__configs.load_env_configs(environment, config_file_prefix_path)

    def get_sor_queries(self):
        queries = {}
        queries["ACCOUNTS_QUERY"] = self.__configs.get_accounts_query()
        queries["SINGLE_ACCOUNT_QUERY"] = self.__configs.get_single_account_query()
        queries["STATUS_QUERY"] = self.__configs.get_status_query()

        return queries

    def get_max_threads(self):
        return self.__configs.get_max_threads()

    def get_json_config_path(self):
        return self.__configs.get_json_config_path()

    def get_env_map(self):
        return self.__configs.get_env_map()

    def get_account_denylist(self):
        return self.__configs.get_account_denylist()
