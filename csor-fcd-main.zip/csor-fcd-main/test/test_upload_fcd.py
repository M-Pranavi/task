from unittest.mock import patch, MagicMock
from json import dumps

from src.upload_fcd import main

@patch('src.upload_fcd.make_request')
@patch('src.upload_fcd.Config')
@patch('src.upload_fcd.parse_args')
def test_upload_fcd(
    mock_parse_args,
    mock_config_class,
    mock_make_request
):
    mock_args = MagicMock()
    mock_args.env = 'internal-dev'
    mock_args.user = 'dev'
    mock_parse_args.return_value = mock_args
    mock_config = MagicMock()
    mock_config_class.return_value = mock_config
    mock_env_configs = {
        "sor_url": "http://fake-sor-url.com",
        "orchestration_aws_assume_role": "fake_role",
        "sor_aws_region": "fake_region"
    }
    mock_config.get_env_config.return_value = mock_env_configs
    mock_fcd = {
        "base_deployer": "0.1.15",
        "cicd_deployer": "0.1.10",
        "logging_deployer": "0.1.14",
        "network_deployer": "0.1.20",
        "security_shield_deployer": "0.1.11",
        "stackset_deployer": "0.1.11"
    }
    mock_config.get_fcd.return_value = mock_fcd
    mock_logging = MagicMock()
    mock_config.get_logging.return_value = mock_logging
    expected_response = {
        "data": {
            "createFcd": {
            "configurationDocument": {
                "base_deployer": "0.1.15",
                "cicd_deployer": "0.1.10",
                "logging_deployer": "0.1.14",
                "network_deployer": "0.1.20",
                "security_shield_deployer": "0.1.11",
                "stackset_deployer": "0.1.11"
            },
            "createdAt": "2025-04-22T15:30:08Z"
            }
        }
    }
    mock_make_request.return_value = expected_response
    expected_mutation = """
        mutation ($fcd: JSON!) {
            createFcd(fcd: $fcd) {
                configurationDocument
                createdAt
            }
        }       
     """

    expected_fcd_dump = dumps(mock_fcd, indent=2)
    expected_query = {"query": expected_mutation,"variables": {"fcd": mock_fcd}}

    actual_response = main(mock_args)
    mock_config.get_env_config.assert_called_once()
    mock_config.get_fcd.assert_called_once()
    mock_logging.info.assert_any_call(f"Uploading current FCD to SOR: {expected_fcd_dump}")

    mock_make_request.assert_called_once_with(
        "POST",
        mock_env_configs["sor_url"],
        expected_query,
        mock_env_configs["orchestration_aws_assume_role"],
        mock_env_configs["sor_aws_region"],
        mock_args.user,
    )

    assert actual_response == expected_response
