import sys
from json import dumps

if any('pytest' in arg for arg in sys.argv):
    from src.config.config import Config
    from src.argument_parser import parse_args
    from src.load_accounts import make_request
else:
    from config.config import Config # type: ignore
    from argument_parser import parse_args # type: ignore
    from load_accounts import make_request # type: ignore

def main(args):

    config = Config(args.env)
    env_configs = config.get_env_config()
    user = args.user
    logging = config.get_logging()

    mutation = """
        mutation ($fcd: JSON!) {
            createFcd(fcd: $fcd) {
                configurationDocument
                createdAt
            }
        }       
     """

    fcd = config.get_fcd()
    logging.info(f"Uploading current FCD to SOR: {dumps(fcd, indent=2)}")
    query = {"query": mutation,"variables": {"fcd": fcd}}

    response = make_request(
            "POST",
            env_configs["sor_url"],
            query,
            env_configs["orchestration_aws_assume_role"],
            env_configs["sor_aws_region"],
            user,
    )

    logging.info("The FCD was successfully uploaded")
    return response


if __name__ == '__main__':
    main(parse_args())
