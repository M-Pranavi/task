from multiprocessing.pool import ThreadPool

from argument_parser import parse_args
from baseline_task import baseline_account
from config.config import Config
from load_accounts import load_accounts


def main(args):
    # Load Configs
    config = Config(args.env)

    ## Logging
    logging = config.get_logging()

    ## Parameters to invoke baseline task
    thread_parallelism = config.get_env_config()["parallelism"]
    max_threads = config.get_max_threads()

    user = args.user

    # Load Accounts
    if not (accounts := load_accounts(config, args.change_approval, args.end_to_end, user)):
        logging.info(
            "No accounts to baseline with change_approval: %s. Skipping...",
            args.change_approval,
        )
        return 0

    # Baseline
    logging.info(
        "Attempting to run baseline for %s accounts with change_approval: %s\n",
        len(accounts),
        args.change_approval,
    )

    with ThreadPool(processes=min(thread_parallelism, max_threads)) as pool:
        baseline_results = pool.map(
            baseline_account,
            [
                {"account_data": account, "config": config, "env": args.env, "user": user}
                for account in accounts
            ],
        )

    successful_baselines = [result for result in baseline_results if result["success"]]
    failed_baselines = [result for result in baseline_results if not result["success"]]

    # Post Run Actions
    for baseline in successful_baselines:
        logging.info(
            "Successfully baselined account %s with result:\n%s\n",
            baseline["id"],
            baseline["result"],
        )

    for baseline in failed_baselines:
        logging.info(
            "Failed to baseline account %s with result:\n%s\n",
            baseline["id"],
            baseline["result"],
        )

    if failed_baselines:
        raise RuntimeError(f"Failed to baseline {len(failed_baselines)} accounts.")

    logging.info(
        "Successfully baselined all accounts with change_approval: %s",
        args.change_approval,
    )

    return 0


if __name__ == "__main__":
    main(parse_args())
