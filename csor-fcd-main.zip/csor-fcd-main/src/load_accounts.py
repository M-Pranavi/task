import json

import boto3  # type: ignore
import requests  # type: ignore
import urllib3  # type: ignore
from botocore.auth import SigV4Auth  # type: ignore
from botocore.awsrequest import AWSRequest  # type: ignore

urllib3.disable_warnings()

# Create a single session for connection reuse
requests_session = requests.Session()
requests_session.verify = False


def make_request(method, url, data, role, region, user):
    awsrequest = AWSRequest(
        method=method,
        url=url,
        data=json.dumps(data),
    )

    session = boto3.Session(region_name=region)

    sts_client = boto3.client("sts")
    response = sts_client.assume_role(
        RoleArn=role, RoleSessionName=user
    )
    session = boto3.Session(
        aws_access_key_id=response["Credentials"]["AccessKeyId"],
        aws_secret_access_key=response["Credentials"]["SecretAccessKey"],
        aws_session_token=response["Credentials"]["SessionToken"],
        region_name=region,
    )

    SigV4Auth(session.get_credentials(), "execute-api", session.region_name).add_auth(
        awsrequest
    )
    response = requests_session.request(
        method=method,
        url=url,
        data=json.dumps(data),
        headers=awsrequest.headers,
        verify=False,
        timeout=10,
    )
    if response.status_code != 200:
        raise RuntimeError(
            f"Request failed with status code {response.status_code}. Response: {response.text}"
        )
    return response.content.decode("utf-8")


def load_accounts(config, change_approval, end_to_end, user):
    env_configs = config.get_env_config()
    if not end_to_end:
        query = {"query": config.get_accounts_query(), "variables": {}}
        response = make_request(
            "POST",
            env_configs["sor_url"],
            query,
            env_configs["orchestration_aws_assume_role"],
            env_configs["sor_aws_region"],
            user,
        )
        accounts = [
            {"id": account["id"], "name": account["name"]}
            for account in json.loads(response)["data"]["accounts"]
            if account["baselineChangeApprovalRequired"] == change_approval
               and account["id"] not in config.get_account_denylist()
               and account["id"] != env_configs["end_to_end_account"]
        ]
    else:
        query = {
            "query": config.get_single_account_query(),
            "variables": {"id": env_configs["end_to_end_account"]},
        }
        response = make_request(
            "POST",
            env_configs["sor_url"],
            query,
            env_configs["orchestration_aws_assume_role"],
            env_configs["sor_aws_region"],
            user,
        )
        accounts = [
            {"id": account["id"], "name": account["name"]}
            for account in json.loads(response)["data"]["accounts"]
        ]

    return accounts
