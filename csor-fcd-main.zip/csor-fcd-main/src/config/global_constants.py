## GLOBAL CONSTANTS

MAX_THREADS = 10

ENV_MAP = {
    "internal-dev": "DEV",
    "internal-qa": "QA",
    "tenant-dev": "DEV",
    "tenant-qa": "QA",
    "tenant-sand": "SAND",
    "tenant-prod": "PROD",
}


## Filter accounts while auto-baseline
ACCOUNT_DENYLIST = [
    "831145966718",  # dev-bt-runtime-services
    "123456789123",  # doc-test-app
]

## SOR Queries

ACCOUNTS_QUERY = """
{
    accounts(businessUnit: "Braintree") {
        id
        name
        baselineChangeApprovalRequired
    }
}
"""

SINGLE_ACCOUNT_QUERY = """
query ($id: String!) {
    accounts(id: $id) {
        id
        name
        baselineChangeApprovalRequired
    }
}
"""

STATUS_QUERY = """
query ($arn: String!) {
    statusByExecution(executionArn: $arn) {
        arn
        status
        stateMachineType
        startTime
        configurationDocument
        deployers {
            name
            status
            version
            outputs
        }
    }
}
"""

FCD_QUERY = """
query ($id: String!, $region: Region) {
    accounts(id: $id, region: $region) {
        baseline {
            lastSuccess {
                arn
                status
                startTime
                configurationDocument
            }
        }
    }
}
"""


## FCD FILENAME
FCD_FILENAME = "fcd.json"

## Path to <env>.json files. Parameterized because the path could be toggled during tests.
JSON_CONFIG_PATH = "config"

## Logging Config
LOGGING_LEVEL = "INFO"
