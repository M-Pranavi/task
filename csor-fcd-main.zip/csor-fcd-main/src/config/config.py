import logging

from .global_constants import (
    ACCOUNT_DENYLIST,
    ACCOUNTS_QUERY,
    ENV_MAP,
    FCD_FILENAME,
    JSON_CONFIG_PATH,
    LOGGING_LEVEL,
    MAX_THREADS,
    SINGLE_ACCOUNT_QUERY,
    STATUS_QUERY,
    FCD_QUERY,
)
from .utils import read_file


class Config:

    def __init__(self, env):
        self.env = env
        self.__MAX_THREADS = MAX_THREADS
        self.__ENV_MAP = ENV_MAP
        self.__ACCOUNT_DENYLIST = ACCOUNT_DENYLIST
        self.__JSON_CONFIG_PATH = JSON_CONFIG_PATH
        self.__ACCOUNTS_QUERY = ACCOUNTS_QUERY
        self.__SINGLE_ACCOUNT_QUERY = SINGLE_ACCOUNT_QUERY
        self.__STATUS_QUERY = STATUS_QUERY
        self.__FCD_QUERY = FCD_QUERY

        self.__logging = self.__config_logging()
        self.__fcd = self.load_fcd(FCD_FILENAME)
        self.__env_config = self.load_env_configs(env, "config")

    # Set to Public for testing
    def load_fcd(self, filename):
        return read_file(filename)

    # Set to Public for testing
    def load_env_configs(self, environment, config_file_prefix_path):
        env_config_filename = f"{config_file_prefix_path}/{environment}.json"
        environment_config = {}

        environment_config = read_file(env_config_filename)

        environment_config["fcd"] = self.load_fcd(FCD_FILENAME)

        return environment_config

    # Configure Logging
    def __config_logging(self):
        logging.basicConfig(format="%(threadName)s:%(message)s", level=LOGGING_LEVEL)
        return logging

    def get_env_config(self):
        return self.__env_config

    def get_fcd(self):
        return self.__fcd

    def get_logging(self):
        return self.__logging

    def get_max_threads(self):
        return self.__MAX_THREADS

    def get_json_config_path(self):
        return self.__JSON_CONFIG_PATH

    def get_env_map(self):
        return self.__ENV_MAP

    def get_account_denylist(self):
        return self.__ACCOUNT_DENYLIST

    def get_accounts_query(self):
        return self.__ACCOUNTS_QUERY

    def get_single_account_query(self):
        return self.__SINGLE_ACCOUNT_QUERY

    def get_status_query(self):
        return self.__STATUS_QUERY

    def get_fcd_query(self):
        return self.__FCD_QUERY
