import argparse

from baseline_task import baseline_account
from config.config import Config

def parse_args():
    parser = argparse.ArgumentParser(
        description="Script to baseline a single account in a single region"
    )
    parser.add_argument(
        "--env",
        type=str,
        help="The environment you want to submit to",
        choices=[
            "internal-dev",
            "internal-qa",
            "tenant-dev",
            "tenant-qa",
            "tenant-sand",
            "tenant-prod",
        ],
        required=True
    )
    parser.add_argument(
        "--account",
        type=str,
        help="The account id you want to baseline",
        required=True
    )
    parser.add_argument(
        "--account-name",
        type=str,
        help="The account name you want to baseline",
        required=True
    )
    parser.add_argument(
        "--user",
        type=str,
        help="Email for user who triggered pipeline",
        required=True,
    )
    parser.add_argument(
        "--region",
        type=str,
        help="Tenant region to create baseline AWS resources.",
        default="us-east-2"
    )

    return parser.parse_args()

def main(args):
    # Load Configs
    config = Config(args.env)

    # Logging
    logging = config.get_logging()

    user = args.user

    logging.info(
        "Attempting to run baseline account %s(%s) in region %s",
        args.account_name,
        args.account,
        args.region
    )

    baseline_result = baseline_account(
        {
            "account_data": {"id": args.account, "name": args.account_name, "region": args.region},
            "config": config,
            "env": args.env,
            "user": user
        }
    )

    if baseline_result["success"]:
        logging.info(
            "Successfully baselined account %s with result:\n%s\n",
            baseline_result["id"],
            baseline_result["result"],
        )
    else:
        logging.info(
            "Failed to baseline account %s with result:\n%s\n",
            baseline_result["id"],
            baseline_result["result"],
        )
        raise RuntimeError(f"Failed to baseline account {args.account_name}({args.account})")

    return 0

if __name__ == "__main__":
    main(parse_args())
