import argparse


def parse_args():
    parser = argparse.ArgumentParser(
        description="Script to submit baseline for all accounts in an environment"
    )
    parser.add_argument(
        "--env",
        type=str,
        help="The environment you want to submit to",
        choices=[
            "internal-dev",
            "internal-qa",
            "tenant-dev",
            "tenant-qa",
            "tenant-sand",
            "tenant-prod",
        ],
        required=True,
    )
    parser.add_argument("--change-approval", action="store_true")
    parser.add_argument(
        "--end-to-end",
        help="Execute end to end test for the environment.",
        action="store_true"
    )
    parser.add_argument(
        "--user",
        type=str,
        help="Email for user who triggered pipeline",
        required=True,
    )

    return parser.parse_args()
