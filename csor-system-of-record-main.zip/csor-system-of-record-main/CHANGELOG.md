# CSoR System of Record Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to Timestamp Versioning.

## [Unreleased]
-

## [0.2.2](https://github.com/PayPal-Braintree/csor-system-of-record/compare/0.2.1...0.2.2)
- Allow new cagent role assume_scoped_role_base to perform SOR admin operations
- Increase ECS timeouts to avoid intermittent healthcheck failures during task startup
- Update Ruby version from 3.2.1 to 3.2.8

## [0.2.1](https://github.com/PayPal-Braintree/csor-system-of-record/compare/0.2.0...0.2.1)
- Pin provider and module versions
- SOR NAT Gateway to allow outbound traffic to Crowdstrike Falcon

## [0.2.0](https://github.com/PayPal-Braintree/csor-system-of-record/compare/0.1.3...0.2.0)
- Generate Crowdstrike Falcon Container Definitions via Jenkins and store/retrieve to/from S3

## [0.1.3](https://github.com/PayPal-Braintree/csor-system-of-record/compare/0.1.2...0.1.3)
- Updated release script to use semantic versioning (semver) instead of timestamp-based version tags
- SOR S3 KMS key and container definitions S3 bucket

## [0.1.2](https://github.com/PayPal-Braintree/csor-system-of-record/compare/0.1.1...0.1.2)
- Pin Datadog terraform provider version to 3.66.0

## [0.1.1](https://github.com/PayPal-Braintree/csor-system-of-record/compare/0.1.0...0.1.1)
- New regions for Apollo: ap-south-2 and me-central-1

## [0.1.0](https://github.com/PayPal-Braintree/csor-system-of-record/compare/2025-05-30T1728...0.1.0)
- Creating CHANGELOG file and and mandatory check to ensure it is updated during PR build
- Documenting bt-authorize instructions in release section
- Pinning the version for ECS module to ~ 5.12.1
- Updated release script to use semantic versioning (semver) instead of timestamp-based version tags
- New regions for Apollo: ap-south-1 and ap-southeast-1

## [2025-05-30T1728](https://github.com/PayPal-Braintree/csor-system-of-record/compare/2025-05-22T1656...2025-05-30T1728)
- Add apollo to foundation
- Rename pipeline user and related permissions

## [2025-05-22T1656](https://github.com/PayPal-Braintree/csor-system-of-record/compare/2025-05-20T1607...2025-05-22T1656) 
- Extend foundation data to include BU, platform, and state machine specific foundation data

## [2025-05-20T1607](https://github.com/PayPal-Braintree/csor-system-of-record/compare/2025-05-15T1935...2025-05-20T1607) 
- Dockerfiles repo "master" to "main" branch migration
- Fix lastSuccess returned as null
- Add migration to add timestamps to accounts table

## [2025-05-15T1935](https://github.com/PayPal-Braintree/csor-system-of-record/compare/2025-05-09T1657...2025-05-15T1935) 
- Fix aurora engine and disable auto_minor_version_upgrade
- Update Terraform Version to 1.11.3
