#!/bin/bash
#define global variable
docker_compose_directory="`find /home/admin/ -iname 'csor-system-of-record'`/sor"

# Definefunctions
usage() {
    echo "  -h | --help: Display this help message"
	echo "  -i | --integration: run rails test:integration"
	echo "  -mi | --migrate_integration: run rails db:migrate test:integration"
	echo "  -u | -unit: run unit tests"
    exit 1
}

create_postgres_container() {
	cd $docker_compose_directory
	docker-compose up --abort-on-container-exit --force-recreate --build --exit-code-from web
}

start_postgress() {
	docker start sor-db-1
}

check_ruby_ver() {
	export PATH="$HOME/.rbenv/bin:$PATH"
	eval "$(rbenv init -)"
	cd $docker_compose_directory
	ruby_version=`ruby -v | awk '{print $2}'`
	if [[ $ruby_version == 3.2.8 ]]; then
	  echo "You have Ruby version 3.2.8 installed."
	else
	  echo "Your Ruby version is different from 3.2.8."
	  echo "Please Install ruby 3.2.8"
	  exit 1
	fi
}

check_postgres_container() {
	db_exists=`docker ps -a --filter "name=sor-db-1" | grep sor-db-1 | wc -l`
	db_runnuning=`docker ps --filter "name=sor-db-1" | grep sor-db-1 | wc -l`
	if [ $db_exists -eq 1 ]; then
		if [ $db_runnuning -eq 1 ]; then
		  echo "DB is running."
		else
		  echo "DB not running, starting DB."
		  start_postgress
		fi
	else
	  echo "DB do not exists, creating container."
	  create_postgres_container
	  echo "Starting container"
	  start_postgress
	fi  
}

export_variables() {
	export RAILS_ENV="development"
	export DATABASE_USER="sor"
	export DATABASE_PASSWORD="password"
	export DATABASE_NAME="sor"
	export DATABASE_PORT="5432"
	export DATABASE_HOST=`docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' sor-db-1`
	export SECRET_KEY_BASE="demo"
	export RAILS_ENV=test
}

#Tests

#run intergration tests
integration_test() {
  check_ruby_ver
  check_postgres_container	
  export_variables
  cd $docker_compose_directory
  bundle exec rails test:integration
}

#run integration with migrate:db
integration_test_with_migrate_db() {
  check_ruby_ver
  check_postgres_container
  export_variables
  cd $docker_compose_directory
  bundle exec rails db:migrate test:integration
}

#run unit tests
unit_tests() {
	check_ruby_ver
	check_postgres_container
	export_variables
	cd $docker_compose_directory
	bundle exec rspec -P spec/graphql/*
}

while :; do
    case $1 in
        -h|--help )
            usage
            ;;
		-i|--integration )
			integration_test
			;;
		-mi|--migrate_integration )
			integration_test_with_migrate_db
			;;
		-u|--unit )
			unit_tests
			;;	
        \? )
            echo "Invalid option: $OPTARG" 1>&2
            usage
            ;;
		* )
			break	
    esac
	shift
done
