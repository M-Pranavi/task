# frozen_string_literal: true

require 'test_helper'

class SetNetworkFoundationTest < ActionDispatch::IntegrationTest
  test 'should return null when no foundation configuration is set' do
    query_string = <<-GRAPHQL
      {
        foundation {
          network {
            accountId
            privateEksSubnetIds
            privateSubnetIds
            publicSubnetIds
            region
            vpcId
          }
        }
      }
    GRAPHQL
    post '/graphql',
         params: { query: query_string },
         as: :json
    response = get_network_foundation_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'should deny non admins' do
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32', '35.156.23.186/32', '52.8.154.168/32', '52.0.40.220/32']
    response = mutate_network_foundation INVALID_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                                         dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                                         dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                                         efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv

    assert_equal 'Not authorized to perform set_network_foundation mutation', response['errors'][0]['message']
  end

  test 'should allow network hydration role' do
    arn = "#{VALID_ORCHESTRATION_ARN_PREFIX}network-hydrate-execution-role/unit-test"
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    response = mutate_network_foundation arn, account_id, region, vpc_id, [], [], [], '', [], '', '', '', [], [], [], [], [], [], [], [], [], [], [],
                                         [], [], '', ''
    assert_equal account_id, response['data']['setNetworkFoundation']['network'][0]['accountId']
    assert_equal region, response['data']['setNetworkFoundation']['network'][0]['region']
    assert_equal vpc_id, response['data']['setNetworkFoundation']['network'][0]['vpcId']
  end

  test 'should create new key if key does not exist' do
    account_id = '12345'
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      }
    ]

    response = mutate_logging_foundation VALID_SOR_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links

    assert_not_nil response

    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32', '35.156.23.186/32', '52.8.154.168/32', '52.0.40.220/32']
    response = mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                                         dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                                         dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                                         efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv
    assert_equal account_id, response['data']['setNetworkFoundation']['network'][0]['accountId']
    assert_equal region, response['data']['setNetworkFoundation']['network'][0]['region']
    assert_equal vpc_id, response['data']['setNetworkFoundation']['network'][0]['vpcId']
    assert_equal private_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['privateSubnetIds']
    assert_equal private_eks_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['privateEksSubnetIds']
    assert_equal public_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['publicSubnetIds']
    assert_equal vpc_cidr, response['data']['setNetworkFoundation']['network'][0]['vpcCidr']
    assert_equal vpc_cidr_allocation, response['data']['setNetworkFoundation']['network'][0]['vpcCidrAllocation']
    assert_equal private_zone_id, response['data']['setNetworkFoundation']['network'][0]['privateZoneId']
    assert_equal dimension_private_zone_id, response['data']['setNetworkFoundation']['network'][0]['dimensionPrivateZoneId']
    assert_equal braintree_api_com_zone_id, response['data']['setNetworkFoundation']['network'][0]['braintreeApiComZoneId']
    assert_equal fdfg_sftp_whitelist_cidrs, response['data']['setNetworkFoundation']['network'][0]['fdfgSftpWhitelistCidrs']
    assert_equal asm_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['asmEndpointIps']
    assert_equal autoscaling_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['autoscalingEndpointIps']
    assert_equal cloudformation_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['cloudformationEndpointIps']
    assert_equal dynamodb_endpoint_cidr_blocks, response['data']['setNetworkFoundation']['network'][0]['dynamodbEndpointCidrBlocks']
    assert_equal ec2_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['ec2EndpointIps']
    assert_equal elasticloadbalancing_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['elasticloadbalancingEndpointIps']
    assert_equal s3_endpoint_cidr_blocks, response['data']['setNetworkFoundation']['network'][0]['s3EndpointCidrBlocks']
    assert_equal sts_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['stsEndpointIps']
    assert_equal logs_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['logsEndpointIps']
    assert_equal efs_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['efsEndpointIps']
    assert_equal sqs_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['sqsEndpointIps']
    assert_equal public_access_cidrs, response['data']['setNetworkFoundation']['network'][0]['publicAccessCidrs']
    assert_equal vpc_dns_addr, response['data']['setNetworkFoundation']['network'][0]['vpcDnsAddr']
    assert_equal availability_zones_dsv, response['data']['setNetworkFoundation']['network'][0]['availabilityZonesDsv']
  end

  test 'should add new network foundation to SoR' do
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32', '35.156.23.186/32', '52.8.154.168/32', '52.0.40.220/32']
    response = mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                                         dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                                         dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                                         efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv
    assert_equal account_id, response['data']['setNetworkFoundation']['network'][0]['accountId']
    assert_equal region, response['data']['setNetworkFoundation']['network'][0]['region']
    assert_equal vpc_id, response['data']['setNetworkFoundation']['network'][0]['vpcId']
    assert_equal private_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['privateSubnetIds']
    assert_equal private_eks_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['privateEksSubnetIds']
    assert_equal public_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['publicSubnetIds']
    assert_equal vpc_cidr, response['data']['setNetworkFoundation']['network'][0]['vpcCidr']
    assert_equal vpc_cidr_allocation, response['data']['setNetworkFoundation']['network'][0]['vpcCidrAllocation']
    assert_equal private_zone_id, response['data']['setNetworkFoundation']['network'][0]['privateZoneId']
    assert_equal dimension_private_zone_id, response['data']['setNetworkFoundation']['network'][0]['dimensionPrivateZoneId']
    assert_equal braintree_api_com_zone_id, response['data']['setNetworkFoundation']['network'][0]['braintreeApiComZoneId']
    assert_equal fdfg_sftp_whitelist_cidrs, response['data']['setNetworkFoundation']['network'][0]['fdfgSftpWhitelistCidrs']
    assert_equal asm_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['asmEndpointIps']
    assert_equal autoscaling_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['autoscalingEndpointIps']
    assert_equal cloudformation_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['cloudformationEndpointIps']
    assert_equal dynamodb_endpoint_cidr_blocks, response['data']['setNetworkFoundation']['network'][0]['dynamodbEndpointCidrBlocks']
    assert_equal ec2_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['ec2EndpointIps']
    assert_equal elasticloadbalancing_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['elasticloadbalancingEndpointIps']
    assert_equal s3_endpoint_cidr_blocks, response['data']['setNetworkFoundation']['network'][0]['s3EndpointCidrBlocks']
    assert_equal sts_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['stsEndpointIps']
    assert_equal logs_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['logsEndpointIps']
    assert_equal efs_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['efsEndpointIps']
    assert_equal sqs_endpoint_ips, response['data']['setNetworkFoundation']['network'][0]['sqsEndpointIps']
    assert_equal public_access_cidrs, response['data']['setNetworkFoundation']['network'][0]['publicAccessCidrs']
    assert_equal vpc_dns_addr, response['data']['setNetworkFoundation']['network'][0]['vpcDnsAddr']
    assert_equal availability_zones_dsv, response['data']['setNetworkFoundation']['network'][0]['availabilityZonesDsv']
  end

  test 'empty return for network foundation' do
    query_string = <<-GRAPHQL
      {
      foundation {
        network {
          accountId
          ec2EndpointIps
      }
    }
  }
    GRAPHQL
    post '/graphql',
         params: { query: query_string },
         as: :json
    response = JSON.parse(@response.body)
    assert_nil response['data']['foundation']
  end

  test 'return single and a list of items for network foundation' do
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32']
    mutate1 = mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation,
                                        private_zone_id, dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips,
                                        cloudformation_endpoint_ips, dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks,
                                        sts_endpoint_ips, logs_endpoint_ips, efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv
    assert_not_nil mutate1
    response = get_network_foundation_details VALID_SOR_ARN
    assert_nil response['errors']
    assert_equal account_id, response['data']['foundation']['network'][0]['accountId']
    assert_equal region, response['data']['foundation']['network'][0]['region']
    assert_equal public_subnet_ids, response['data']['foundation']['network'][0]['publicSubnetIds']
    assert_equal private_subnet_ids, response['data']['foundation']['network'][0]['privateSubnetIds']
    assert_equal private_eks_subnet_ids, response['data']['foundation']['network'][0]['privateEksSubnetIds']
    assert_equal vpc_cidr_allocation, response['data']['foundation']['network'][0]['vpcCidrAllocation']
    assert_equal fdfg_sftp_whitelist_cidrs[0], response['data']['foundation']['network'][0]['fdfgSftpWhitelistCidrs'][0]
    assert_equal fdfg_sftp_whitelist_cidrs[1], response['data']['foundation']['network'][0]['fdfgSftpWhitelistCidrs'][1]
    assert_equal asm_endpoint_ips[0], response['data']['foundation']['network'][0]['asmEndpointIps'][0]
    assert_equal asm_endpoint_ips[1], response['data']['foundation']['network'][0]['asmEndpointIps'][1]
    assert_equal autoscaling_endpoint_ips[0], response['data']['foundation']['network'][0]['autoscalingEndpointIps'][0]
    assert_equal autoscaling_endpoint_ips[1], response['data']['foundation']['network'][0]['autoscalingEndpointIps'][1]
    assert_equal cloudformation_endpoint_ips[0], response['data']['foundation']['network'][0]['cloudformationEndpointIps'][0]
    assert_equal cloudformation_endpoint_ips[1], response['data']['foundation']['network'][0]['cloudformationEndpointIps'][1]
    assert_equal dynamodb_endpoint_cidr_blocks[0], response['data']['foundation']['network'][0]['dynamodbEndpointCidrBlocks'][0]
    assert_equal dynamodb_endpoint_cidr_blocks[1], response['data']['foundation']['network'][0]['dynamodbEndpointCidrBlocks'][1]
    assert_equal ec2_endpoint_ips[0], response['data']['foundation']['network'][0]['ec2EndpointIps'][0]
    assert_equal ec2_endpoint_ips[1], response['data']['foundation']['network'][0]['ec2EndpointIps'][1]
    assert_equal elasticloadbalancing_endpoint_ips[0], response['data']['foundation']['network'][0]['elasticloadbalancingEndpointIps'][0]
    assert_equal elasticloadbalancing_endpoint_ips[1], response['data']['foundation']['network'][0]['elasticloadbalancingEndpointIps'][1]
    assert_equal s3_endpoint_cidr_blocks[0], response['data']['foundation']['network'][0]['s3EndpointCidrBlocks'][0]
    assert_equal s3_endpoint_cidr_blocks[1], response['data']['foundation']['network'][0]['s3EndpointCidrBlocks'][1]
    assert_equal sts_endpoint_ips[0], response['data']['foundation']['network'][0]['stsEndpointIps'][0]
    assert_equal sts_endpoint_ips[1], response['data']['foundation']['network'][0]['stsEndpointIps'][1]
    assert_equal logs_endpoint_ips[0], response['data']['foundation']['network'][0]['logsEndpointIps'][0]
    assert_equal logs_endpoint_ips[1], response['data']['foundation']['network'][0]['logsEndpointIps'][1]
    assert_equal efs_endpoint_ips[0], response['data']['foundation']['network'][0]['efsEndpointIps'][0]
    assert_equal efs_endpoint_ips[1], response['data']['foundation']['network'][0]['efsEndpointIps'][1]
    assert_equal sqs_endpoint_ips[0], response['data']['foundation']['network'][0]['sqsEndpointIps'][0]
    assert_equal sqs_endpoint_ips[1], response['data']['foundation']['network'][0]['sqsEndpointIps'][1]
    assert_equal public_access_cidrs[0], response['data']['foundation']['network'][0]['publicAccessCidrs'][0]
    assert_equal public_access_cidrs[1], response['data']['foundation']['network'][0]['publicAccessCidrs'][1]
  end

  test 'should update network foundation' do
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    public_access_cidrs = ['public-access-cidr-1']

    response = mutate_network_foundation VALID_SOR_ARN, '999', region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, '',
                                         [], '', '', '', [], [], [], [], [], [], [], [], [], [], [], [], public_access_cidrs, '', ''
    assert_equal '999', response['data']['setNetworkFoundation']['network'][0]['accountId']

    response = mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids,
                                         '', [], '', '', '', [], [], [], [], [], [], [], [], [], [], [], [], public_access_cidrs, '', ''
    assert_equal account_id, response['data']['setNetworkFoundation']['network'][0]['accountId']
    assert_equal region, response['data']['setNetworkFoundation']['network'][0]['region']
    assert_equal vpc_id, response['data']['setNetworkFoundation']['network'][0]['vpcId']
    assert_equal private_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['privateSubnetIds']
    assert_equal private_eks_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['privateEksSubnetIds']
    assert_equal public_subnet_ids, response['data']['setNetworkFoundation']['network'][0]['publicSubnetIds']
    assert_equal public_access_cidrs, response['data']['setNetworkFoundation']['network'][0]['publicAccessCidrs']
  end

  test 'idompotency of network foundation' do
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32', '35.156.23.186/32', '52.8.154.168/32', '52.0.40.220/32']
    mutate1 = mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                                        dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                                        dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                                        efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv
    mutate2 = mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                                        dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                                        dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                                        efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv
    assert_equal mutate1, mutate2
    assert mutate1['data'], mutate2['data']
    assert_equal mutate1['data']['setNetworkFoundation']['network'][0]['accountId'], mutate2['data']['setNetworkFoundation']['network'][0]['accountId']
    assert_nil mutate2['errors']
  end

  test 'dual write to braintree document field' do
    account_id = '12345'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32']

    mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation,
                              private_zone_id, dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips,
                              cloudformation_endpoint_ips, dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks,
                              sts_endpoint_ips, logs_endpoint_ips, efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv

    # Query the foundation and verify data is written to both locations
    query_string = <<-GRAPHQL
      {
        foundation {
          network {
            accountId
            region
            vpcId
            publicSubnetIds
            privateSubnetIds
            privateEksSubnetIds
            vpcCidr
            vpcCidrAllocation
            privateZoneId
            dimensionPrivateZoneId
            braintreeApiComZoneId
            fdfgSftpWhitelistCidrs
            vpcDnsAddr
            availabilityZonesDsv
            asmEndpointIps
            autoscalingEndpointIps
            cloudformationEndpointIps
            dynamodbEndpointCidrBlocks
            ec2EndpointIps
            elasticloadbalancingEndpointIps
            s3EndpointCidrBlocks
            stsEndpointIps
            logsEndpointIps
            efsEndpointIps
            sqsEndpointIps
            publicAccessCidrs
          }
          braintree {
            network {
              accountId
              region
              vpcId
              publicSubnetIds
              privateSubnetIds
              privateEksSubnetIds
              vpcCidr
              vpcCidrAllocation
              privateZoneId
              dimensionPrivateZoneId
              braintreeApiComZoneId
              fdfgSftpWhitelistCidrs
              vpcDnsAddr
              availabilityZonesDsv
              asmEndpointIps
              autoscalingEndpointIps
              cloudformationEndpointIps
              dynamodbEndpointCidrBlocks
              ec2EndpointIps
              elasticloadbalancingEndpointIps
              s3EndpointCidrBlocks
              stsEndpointIps
              logsEndpointIps
              efsEndpointIps
              sqsEndpointIps
              publicAccessCidrs
            }
          }
        }
      }
    GRAPHQL

    post '/graphql',
         params: { query: query_string },
         as: :json
    response = JSON.parse(@response.body)

    # Check direct field access
    assert_equal account_id, response['data']['foundation']['network'][0]['accountId']
    assert_equal region, response['data']['foundation']['network'][0]['region']
    assert_equal vpc_id, response['data']['foundation']['network'][0]['vpcId']

    # Check data in braintree document field
    assert_equal account_id, response['data']['foundation']['braintree']['network'][0]['accountId']
    assert_equal region, response['data']['foundation']['braintree']['network'][0]['region']
    assert_equal vpc_id, response['data']['foundation']['braintree']['network'][0]['vpcId']
    assert_equal public_subnet_ids, response['data']['foundation']['braintree']['network'][0]['publicSubnetIds']
    assert_equal private_subnet_ids, response['data']['foundation']['braintree']['network'][0]['privateSubnetIds']
    assert_equal private_eks_subnet_ids, response['data']['foundation']['braintree']['network'][0]['privateEksSubnetIds']
  end
end
