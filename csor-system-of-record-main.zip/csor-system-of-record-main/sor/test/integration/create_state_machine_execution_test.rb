# frozen_string_literal: true

require 'test_helper'

class CreateStateMachineExecutionTest < ActionDispatch::IntegrationTest
  valid_user_arn = 'arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/unit-test'

  def setup
    @account_id = '123'
    @region = 'us-east-2'
    create_account(
      VALID_SOR_ARN,
      'My Tenant Account',
      'TENANT',
      @account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [@region]
    )
  end

  test 'should create new state machine execution' do
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    response = create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    assert_equal execution_arn, response['data']['createStateMachineExecution']['arn']
    assert_equal @region, response['data']['createStateMachineExecution']['region']
    assert_equal status, response['data']['createStateMachineExecution']['status']
    assert_equal start_time, response['data']['createStateMachineExecution']['startTime']
    assert_equal deployers[0][:name], response['data']['createStateMachineExecution']['deployers'][0]['name']
    assert_equal deployers[0][:version], response['data']['createStateMachineExecution']['deployers'][0]['version']
    assert_equal deployers[0][:status], response['data']['createStateMachineExecution']['deployers'][0]['status']
    assert_nil response['data']['createStateMachineExecution']['deployers'][0]['snowTicket']
    assert_nil deployers[0][:repository], response['data']['createStateMachineExecution']['deployers'][0]['repository']
    assert_equal deployers[0][:outputs], response['data']['createStateMachineExecution']['deployers'][0]['outputs']
    assert_equal deployers[0][:resources], response['data']['createStateMachineExecution']['deployers'][0]['resources']
    assert_equal deployers[1][:name], response['data']['createStateMachineExecution']['deployers'][1]['name']
    assert_equal deployers[1][:version], response['data']['createStateMachineExecution']['deployers'][1]['version']
    assert_equal deployers[1][:status], response['data']['createStateMachineExecution']['deployers'][1]['status']
    assert_nil response['data']['createStateMachineExecution']['deployers'][0]['snowTicket']
    assert_nil deployers[1][:repository]
    assert_equal deployers[1][:outputs], response['data']['createStateMachineExecution']['deployers'][1]['outputs']
    assert_equal deployers[1][:resources], response['data']['createStateMachineExecution']['deployers'][1]['resources']
  end
end
