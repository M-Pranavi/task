# frozen_string_literal: true

require 'test_helper'

class SetBraintreeFoundationTest < ActionDispatch::IntegrationTest
  test 'should return null when no braintree foundation configuration is set' do
    response = get_braintree_foundation_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'should deny non admins' do
    cosmos = {
      accountId: '654321',
      environment: 'DEV',
      cpairAssumeRole: 'arn:aws:iam::654321:role/cpair-assume-role'
    }

    response = mutate_braintree_foundation(
      INVALID_ARN,
      cosmos
    )

    assert_equal 'Not authorized to perform set_braintree_foundation mutation', response['errors'][0]['message']
  end

  test 'should add new braintree cosmos foundation to SoR' do
    cosmos = {
      accountId: '654321',
      environment: 'DEV',
      cpairAssumeRole: 'arn:aws:iam::654321:role/cpair-assume-role'
    }

    response = mutate_braintree_foundation(
      VALID_SOR_ARN,
      cosmos
    )

    # Verify cosmos configuration
    assert_equal cosmos[:accountId], response['data']['setBraintreeFoundation']['braintree']['cosmos']['accountId']
    assert_equal cosmos[:environment], response['data']['setBraintreeFoundation']['braintree']['cosmos']['environment']
    assert_equal cosmos[:cpairAssumeRole], response['data']['setBraintreeFoundation']['braintree']['cosmos']['cpairAssumeRole']
  end

  test 'should update braintree cosmos foundation' do
    # First create cosmos foundation
    cosmos = {
      accountId: '654321',
      environment: 'DEV',
      cpairAssumeRole: 'arn:aws:iam::654321:role/cpair-assume-role'
    }

    mutate_braintree_foundation(
      VALID_SOR_ARN,
      cosmos
    )

    # Now update it with new values
    updated_cosmos = {
      accountId: '098765',
      environment: 'QA',
      cpairAssumeRole: 'arn:aws:iam::098765:role/cpair-assume-role-updated'
    }

    response = mutate_braintree_foundation(
      VALID_SOR_ARN,
      updated_cosmos
    )

    # Verify updated cosmos configuration
    assert_equal updated_cosmos[:accountId], response['data']['setBraintreeFoundation']['braintree']['cosmos']['accountId']
    assert_equal updated_cosmos[:environment], response['data']['setBraintreeFoundation']['braintree']['cosmos']['environment']
    assert_equal updated_cosmos[:cpairAssumeRole], response['data']['setBraintreeFoundation']['braintree']['cosmos']['cpairAssumeRole']
  end

  test 'idempotency of braintree foundation' do
    cosmos = {
      accountId: '654321',
      environment: 'DEV',
      cpairAssumeRole: 'arn:aws:iam::654321:role/cpair-assume-role'
    }

    response1 = mutate_braintree_foundation(
      VALID_SOR_ARN,
      cosmos
    )

    response2 = mutate_braintree_foundation(
      VALID_SOR_ARN,
      cosmos
    )

    assert_equal response1, response2
    assert response1['data'], response2['data']
    assert_equal response1['data']['setBraintreeFoundation']['braintree']['cosmos']['accountId'],
                 response2['data']['setBraintreeFoundation']['braintree']['cosmos']['accountId']
    assert_nil response2['errors']
  end
end
