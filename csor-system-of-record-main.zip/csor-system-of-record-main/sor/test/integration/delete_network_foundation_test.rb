# frozen_string_literal: true

require 'test_helper'

class DeleteNetworkFoundationTest < ActionDispatch::IntegrationTest
  test 'should return null when no foundation configuration is set' do
    query_string = <<-GRAPHQL
      {
        foundation {
          network {
            accountId
            privateEksSubnetIds
            privateSubnetIds
            publicSubnetIds
            region
            vpcId
          }
        }
      }
    GRAPHQL
    post '/graphql',
         params: { query: query_string },
         as: :json
    response = get_network_foundation_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'should deny non admins' do
    account_id = '123'
    region = 'us-east-2'
    response = delete_network_foundation INVALID_ARN, account_id, region
    assert_equal 'Not authorized to perform delete_network_foundation mutation', response['errors'][0]['message']
  end

  test 'should delete network region to empty array' do
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32', '35.156.23.186/32', '52.8.154.168/32', '52.0.40.220/32']
    mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                              dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                              dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                              efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv

    response = delete_network_foundation VALID_SOR_ARN, account_id, region
    assert_equal [], response['data']['deleteNetworkFoundation']['network']
  end

  test 'should delete network region' do
    account_id = '123'
    region = 'us-east-1'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32', '35.156.23.186/32', '52.8.154.168/32', '52.0.40.220/32']
    mutate_network_foundation VALID_SOR_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                              dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                              dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                              efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv

    mutate_network_foundation VALID_SOR_ARN, account_id, 'us-east-2', vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                              dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                              dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                              efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv

    response = delete_network_foundation VALID_SOR_ARN, account_id, 'us-east-2'
    assert_equal 1, response['data']['deleteNetworkFoundation']['network'].length
    assert_equal account_id, response['data']['deleteNetworkFoundation']['network'][0]['accountId']
    assert_equal region, response['data']['deleteNetworkFoundation']['network'][0]['region']
  end
end
