# frozen_string_literal: true

require 'test_helper'

class QueryAccountFlowsTest < ActionDispatch::IntegrationTest
  test 'should not return accounts when there are none' do
    query_string = <<-GRAPHQL
      {
        accounts {
          id
          name
        }
      }
    GRAPHQL
    post '/graphql',
         params: { query: query_string },
         as: :json
    response = JSON.parse(@response.body)
    assert_empty response['data']['accounts']
  end

  test 'should add new account to SoR' do
    response = create_account(
      VALID_SOR_ARN,
      'Logging Account',
      'FOUNDATION',
      'aws_account_number',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    assert_equal 'Logging Account', response['data']['createAccount']['name']
    assert_equal 'FOUNDATION', response['data']['createAccount']['accountType']
    assert_equal 'aws_account_number', response['data']['createAccount']['id']
    assert_equal 'DEV', response['data']['createAccount']['environment']
    assert_equal 'test-owner', response['data']['createAccount']['owner']
    assert_equal 'test-app', response['data']['createAccount']['applicationName']
    assert_equal 'test-dl', response['data']['createAccount']['distributionList']
    assert_equal 'test-channel', response['data']['createAccount']['slackServiceChannel']
    assert_equal 'test-bu', response['data']['createAccount']['businessUnit']
    assert_equal 'CLASS_1', response['data']['createAccount']['dataClassification']
    assert_equal 'STANDARD', response['data']['createAccount']['businessCriticality']
    assert_equal 'INTERNAL', response['data']['createAccount']['connectivity']
    assert_equal true, response['data']['createAccount']['baselineChangeApprovalRequired']
    assert_equal false, response['data']['createAccount']['provisionChangeApprovalRequired']
    assert_equal ['us-east-1'], response['data']['createAccount']['regions']
  end

  test 'should default change approval' do
    name = 'test-account'
    type = 'TENANT'
    id = '1234'
    env = 'DEV'
    owner = 'test-owner'
    app = 'test-app'
    dl = 'test-dl'
    channel = 'test-channel'
    bu = 'test-bu'
    data_class = 'CLASS_1'
    crit = 'STANDARD'
    connectivity = 'INTERNAL'
    b_approval = true
    p_approval = false
    regions = ['us-east-1']

    response = create_account(
      VALID_SOR_ARN,
      name,
      type,
      id,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    assert_equal name, response['data']['createAccount']['name']
    assert_equal type, response['data']['createAccount']['accountType']
    assert_equal id, response['data']['createAccount']['id']
    assert_equal env, response['data']['createAccount']['environment']
    assert_equal owner, response['data']['createAccount']['owner']
    assert_equal app, response['data']['createAccount']['applicationName']
    assert_equal dl, response['data']['createAccount']['distributionList']
    assert_equal channel, response['data']['createAccount']['slackServiceChannel']
    assert_equal bu, response['data']['createAccount']['businessUnit']
    assert_equal data_class, response['data']['createAccount']['dataClassification']
    assert_equal crit, response['data']['createAccount']['businessCriticality']
    assert_equal connectivity, response['data']['createAccount']['connectivity']
    assert_equal true, response['data']['createAccount']['baselineChangeApprovalRequired']
    assert_equal false, response['data']['createAccount']['provisionChangeApprovalRequired']
    assert_equal regions, response['data']['createAccount']['regions']
  end

  test 'should prevent duplicate account creation' do
    name = 'Logging Account'
    id = 'unique_account_number'
    account = create_account(
      VALID_SOR_ARN,
      name,
      'FOUNDATION',
      id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    assert_not_nil account
    assert_equal name, account['data']['createAccount']['name']
    assert_equal id, account['data']['createAccount']['id']
    response = create_account(
      VALID_SOR_ARN,
      name,
      'FOUNDATION',
      id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    assert_nil response['data']
    assert_equal 1, response['errors'].length
  end

  test 'should return the account data' do
    name = 'test-account'
    type = 'TENANT'
    account_id1 = '1234'
    env = 'DEV'
    owner = 'test-owner'
    app = 'test-app'
    dl = 'test-dl'
    channel = 'test-channel'
    bu = 'test-bu'
    data_class = 'CLASS_1'
    crit = 'STANDARD'
    connectivity = 'INTERNAL'
    b_approval = true
    p_approval = true
    regions = ['us-east-1']

    account = create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id1,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    assert_not_nil account
    response = get_account VALID_SOR_ARN
    assert_equal account_id1, response['data']['accounts'][0]['id']
  end

  test 'should return multiple accounts' do
    name = 'test-account'
    type = 'TENANT'
    env = 'DEV'
    owner = 'test-owner'
    app = 'test-app'
    dl = 'test-dl'
    channel = 'test-channel'
    bu = 'test-bu'
    data_class = 'CLASS_1'
    crit = 'STANDARD'
    connectivity = 'INTERNAL'
    b_approval = true
    p_approval = true
    regions = ['us-east-1']

    account_id1 = '1234'
    account1 = create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id1,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    assert_not_nil account1

    account_id2 = '3456'
    account2 = create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id2,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    assert_not_nil account2
    account_response = get_account VALID_SOR_ARN
    assert_nil account_response['errors']
    # Sort the return accounts for deterministic result
    account_data = account_response['data']['accounts'].sort_by { |h| h['id'] }
    assert_equal account_id1, account_data[0]['id']
    assert_equal account_id2, account_data[1]['id']
  end

  test 'should update account metadata' do
    name = 'test-account'
    type = 'TENANT'
    account_id1 = '1234'
    env = 'DEV'
    owner = 'test-owner'
    app = 'test-app'
    dl = 'test-dl'
    channel = 'test-channel'
    bu = 'test-bu'
    data_class = 'CLASS_1'
    crit = 'STANDARD'
    connectivity = 'INTERNAL'
    b_approval = true
    p_approval = true
    regions = ['us-east-1']

    create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id1,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )

    new_owner = 'test-new-owner'
    new_conn = 'EXTERNAL'
    new_b_approval = false
    new_p_approval = false

    response = update_account_metadata(
      VALID_SOR_ARN,
      account_id1,
      new_owner,
      nil,
      nil,
      nil,
      nil,
      nil,
      nil,
      new_conn,
      new_b_approval,
      new_p_approval,
      regions
    )
    assert_equal account_id1, response['data']['updateAccount']['id']
    assert_equal new_owner, response['data']['updateAccount']['owner']
    assert_equal app, response['data']['updateAccount']['applicationName']
    assert_equal dl, response['data']['updateAccount']['distributionList']
    assert_equal channel, response['data']['updateAccount']['slackServiceChannel']
    assert_equal bu, response['data']['updateAccount']['businessUnit']
    assert_equal data_class, response['data']['updateAccount']['dataClassification']
    assert_equal crit, response['data']['updateAccount']['businessCriticality']
    assert_equal new_conn, response['data']['updateAccount']['connectivity']
    assert_equal new_b_approval, response['data']['updateAccount']['baselineChangeApprovalRequired']
    assert_equal new_p_approval, response['data']['updateAccount']['provisionChangeApprovalRequired']
    assert_equal regions, response['data']['updateAccount']['regions']
  end

  test 'should allow request submitter' do
    response = create_account(
      "#{VALID_ORCHESTRATION_ARN_PREFIX}request-submitter-baseline-role/unit-test",
      'Test Account',
      'FOUNDATION',
      '1234',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    assert_equal 'Test Account', response['data']['createAccount']['name']
    assert_equal 'FOUNDATION', response['data']['createAccount']['accountType']
    assert_equal '1234', response['data']['createAccount']['id']
    assert_equal 'DEV', response['data']['createAccount']['environment']
    assert_equal 'test-owner', response['data']['createAccount']['owner']
    assert_equal 'test-app', response['data']['createAccount']['applicationName']
    assert_equal 'test-dl', response['data']['createAccount']['distributionList']
    assert_equal 'test-channel', response['data']['createAccount']['slackServiceChannel']
    assert_equal 'test-bu', response['data']['createAccount']['businessUnit']
    assert_equal 'CLASS_1', response['data']['createAccount']['dataClassification']
    assert_equal 'STANDARD', response['data']['createAccount']['businessCriticality']
    assert_equal 'INTERNAL', response['data']['createAccount']['connectivity']
    assert_equal true, response['data']['createAccount']['baselineChangeApprovalRequired']
    assert_equal false, response['data']['createAccount']['provisionChangeApprovalRequired']
    assert_equal ['us-east-1'], response['data']['createAccount']['regions']
  end

  test 'should allow onboard' do
    response = create_account(
      "#{VALID_ORCHESTRATION_ARN_PREFIX}onboard-role/unit-test",
      'Test Account',
      'FOUNDATION',
      '1234',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    assert_equal 'Test Account', response['data']['createAccount']['name']
    assert_equal 'FOUNDATION', response['data']['createAccount']['accountType']
    assert_equal '1234', response['data']['createAccount']['id']
    assert_equal 'DEV', response['data']['createAccount']['environment']
    assert_equal 'test-owner', response['data']['createAccount']['owner']
    assert_equal 'test-app', response['data']['createAccount']['applicationName']
    assert_equal 'test-dl', response['data']['createAccount']['distributionList']
    assert_equal 'test-channel', response['data']['createAccount']['slackServiceChannel']
    assert_equal 'test-bu', response['data']['createAccount']['businessUnit']
    assert_equal 'CLASS_1', response['data']['createAccount']['dataClassification']
    assert_equal 'STANDARD', response['data']['createAccount']['businessCriticality']
    assert_equal 'INTERNAL', response['data']['createAccount']['connectivity']
    assert_equal true, response['data']['createAccount']['baselineChangeApprovalRequired']
    assert_equal false, response['data']['createAccount']['provisionChangeApprovalRequired']
    assert_equal ['us-east-1'], response['data']['createAccount']['regions']
  end

  test 'should deny create account to not authorized' do
    response = create_account(
      "#{VALID_ORCHESTRATION_ARN_PREFIX}request-submitter-provision-role/unit-test",
      'Test Account',
      'FOUNDATION',
      '1234',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    assert_equal 'Not authorized to perform create_account mutation', response['errors'][0]['message']
  end

  test 'should deny update to not authorized' do
    arn = "#{VALID_ORCHESTRATION_ARN_PREFIX}request-submitter-provision-role/unit-test"
    create_account(
      arn,
      'My Account',
      'TENANT',
      '1234',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    response = update_account_environment arn, '1234', 'QA'
    assert_equal 'Not authorized to perform update_account mutation', response['errors'][0]['message']
  end

  test 'should update account with environment' do
    create_account(
      VALID_SOR_ARN,
      'My Account',
      'TENANT',
      '1234',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    response = update_account_environment VALID_SOR_ARN, '1234', 'QA'
    assert_equal response['data']['updateAccount']['environment'], 'QA'
  end

  test 'idempotency of update account' do
    name = 'test-account'
    type = 'TENANT'
    account_id1 = '1234'
    env = 'DEV'
    owner = 'test-owner'
    app = 'test-app'
    dl = 'test-dl'
    channel = 'test-channel'
    bu = 'test-bu'
    data_class = 'CLASS_1'
    crit = 'STANDARD'
    connectivity = 'INTERNAL'
    b_approval = true
    p_approval = true
    regions = ['us-east-1']

    account = create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id1,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    assert_not_nil account
    new_owner = 'test-new-owner'
    new_conn = 'EXTERNAL'
    new_regions = ['us-east-2']

    update1 = update_account_metadata(
      VALID_SOR_ARN,
      account_id1,
      new_owner,
      nil,
      nil,
      nil,
      nil,
      nil,
      nil,
      new_conn,
      new_b_approval = false,
      new_p_approval = false,
      new_regions
    )
    update2 = update_account_metadata(
      VALID_SOR_ARN,
      account_id1,
      new_owner,
      nil,
      nil,
      nil,
      nil,
      nil,
      nil,
      new_conn,
      new_b_approval,
      new_p_approval,
      new_regions
    )

    assert_equal update1, update2
    assert_nil update2['errors']
    assert update1['data'], update2['data']
  end

  test 'idompotency of create account' do
    name = 'test-account'
    type = 'TENANT'
    env = 'DEV'
    owner = 'test-owner'
    app = 'test-app'
    dl = 'test-dl'
    channel = 'test-channel'
    bu = 'test-bu'
    data_class = 'CLASS_1'
    crit = 'STANDARD'
    connectivity = 'INTERNAL'
    b_approval = true
    p_approval = true
    regions = ['us-east-1']

    account_id1 = '1234'
    account1 = create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id1,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    assert_not_nil account1

    account_id2 = '3456'
    account2 = create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id2,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    response = get_account VALID_SOR_ARN
    assert_equal response['data']['accounts'][0]['name'], response['data']['accounts'][1]['name']
    assert_nil account2['errors']
    assert_nil response['errors']
  end

  test 'region strings create account' do
    name = 'test-account'
    type = 'TENANT'
    env = 'DEV'
    owner = 'test-owner'
    app = 'test-app'
    dl = 'test-dl'
    channel = 'test-channel'
    bu = 'test-bu'
    data_class = 'CLASS_1'
    crit = 'STANDARD'
    connectivity = 'INTERNAL'
    b_approval = true
    p_approval = true
    regions = %w[us-east-1 us-east-2]

    account_id = '1234'
    response = create_account(
      VALID_SOR_ARN,
      name,
      type,
      account_id,
      env,
      owner,
      app,
      dl,
      channel,
      bu,
      data_class,
      crit,
      connectivity,
      b_approval,
      p_approval,
      regions
    )
    assert_not_nil response
    assert_equal account_id, response['data']['createAccount']['id']
    assert_equal regions, response['data']['createAccount']['regions']
  end

  test 'should return executions for a specific region' do
    account_id = '123'
    region1 = 'us-east-1'
    region2 = 'us-east-2'
    create_account(
      VALID_SOR_ARN,
      'Logging Account',
      'FOUNDATION',
      account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [region1, region2]
    )

    region1_execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    region2_execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c8'
    region1_start_time = '2024-05-23T13:37:23Z'
    region2_start_time = '2024-05-23T14:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution VALID_SOR_ARN, account_id, region1_execution_arn, region1, region1_start_time, status, type, deployers, configuration_document
    create_state_machine_execution VALID_SOR_ARN, account_id, region2_execution_arn, region2, region2_start_time, status, type, deployers, configuration_document

    query_string = <<-GRAPHQL
    query($accountId: String!, $region: Region) {
      accounts (id: $accountId, region: $region) {
        id
        name
        regions
        baseline {
          region
          executions {
            arn
          }
        }
      }
    }
    GRAPHQL
    post '/graphql',
         params: {
           query: query_string,
           variables: {
             accountId: account_id,
             region: region2
           }
         },
         headers: { "User-Arn": VALID_SOR_ARN },
         as: :json
    response = JSON.parse(@response.body)
    assert_equal account_id, response['data']['accounts'][0]['id']
    assert_equal 1, response['data']['accounts'][0]['baseline'].length
    assert_equal region2, response['data']['accounts'][0]['baseline'][0]['region']
    assert_equal region2_execution_arn, response['data']['accounts'][0]['baseline'][0]['executions'][0]['arn']
  end

  test 'should return executions for all regions' do
    account_id = '123'
    region1 = 'us-east-1'
    region2 = 'us-east-2'
    create_account(
      VALID_SOR_ARN,
      'Logging Account',
      'FOUNDATION',
      account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [region1, region2]
    )

    region1_execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    region2_execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c8'
    region1_start_time = '2024-05-23T13:37:23Z'
    region2_start_time = '2024-05-23T14:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution VALID_SOR_ARN, account_id, region1_execution_arn, region1, region1_start_time, status, type, deployers, configuration_document
    create_state_machine_execution VALID_SOR_ARN, account_id, region2_execution_arn, region2, region2_start_time, status, type, deployers, configuration_document

    query_string = <<-GRAPHQL
    query($accountId: String!) {
      accounts (id: $accountId) {
        id
        name
        regions
        baseline {
          region
          executions {
            arn
          }
        }
      }
    }
    GRAPHQL
    post '/graphql',
         params: {
           query: query_string,
           variables: {
             accountId: account_id
           }
         },
         headers: { "User-Arn": VALID_SOR_ARN },
         as: :json
    response = JSON.parse(@response.body)
    assert_equal account_id, response['data']['accounts'][0]['id']
    assert_equal 2, response['data']['accounts'][0]['baseline'].length
    assert_equal region2_execution_arn, response['data']['accounts'][0]['baseline'][0]['executions'][0]['arn']
    assert_equal region2, response['data']['accounts'][0]['baseline'][0]['region']
    assert_equal region1_execution_arn, response['data']['accounts'][0]['baseline'][1]['executions'][0]['arn']
    assert_equal region1, response['data']['accounts'][0]['baseline'][1]['region']
  end

  test 'should return latest and lastSuccess for a speciic region' do
    account_id = '123'
    region1 = 'us-east-1'
    create_account(
      VALID_SOR_ARN,
      'Logging Account',
      'FOUNDATION',
      account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [region1]
    )

    execution1_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    execution2_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c8'
    execution1_start_time = '2024-05-23T13:37:23Z'
    execution2_start_time = '2024-05-23T14:37:23Z'
    status = 'SUCCEEDED'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Success',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Success',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution VALID_SOR_ARN, account_id, execution1_arn, region1, execution1_start_time, status, type, deployers, configuration_document
    create_state_machine_execution VALID_SOR_ARN, account_id, execution2_arn, region1, execution2_start_time, status, type, deployers, configuration_document

    query_string = <<-GRAPHQL
    query($accountId: String!, $region: Region) {
      accounts (id: $accountId, region: $region) {
        id
        name
        regions
        baseline {
          region
          latest {
            arn
            startTime
            region
            deployers {
              status
              name
            }
          }
          lastSuccess {
            arn
            startTime
            region
            deployers {
              status
              name
            }
          }
        }
      }
    }
    GRAPHQL
    post '/graphql',
         params: {
           query: query_string,
           variables: {
             accountId: account_id,
             region: region1
           }
         },
         headers: { "User-Arn": VALID_SOR_ARN },
         as: :json
    response = JSON.parse(@response.body)
    assert_equal account_id, response['data']['accounts'][0]['id']
    assert_equal region1, response['data']['accounts'][0]['baseline'][0]['region']
    assert_equal execution2_arn, response['data']['accounts'][0]['baseline'][0]['latest']['arn']
    assert_equal execution2_arn, response['data']['accounts'][0]['baseline'][0]['lastSuccess']['arn']
    assert_equal execution2_start_time, response['data']['accounts'][0]['baseline'][0]['latest']['startTime']
    assert_equal execution2_start_time, response['data']['accounts'][0]['baseline'][0]['lastSuccess']['startTime']
    assert_not_nil response['data']['accounts'][0]['baseline'][0]['latest']['deployers']
    assert_not_nil response['data']['accounts'][0]['baseline'][0]['lastSuccess']['deployers']
  end

  test 'should filter deployers based on deployer name' do
    account_id = '123'
    region1 = 'us-east-1'
    create_account(
      VALID_SOR_ARN,
      'Logging Account',
      'TENANT',
      account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [region1]
    )

    region1_execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    region1_start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'config_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution VALID_SOR_ARN, account_id, region1_execution_arn, region1, region1_start_time, status, type, deployers, configuration_document

    query_string = <<-GRAPHQL
    query($accountId: String!, $deployerName: String) {
      accounts (id: $accountId, deployerName: $deployerName) {
        id
        name
        regions
        baseline {
          region
          latest {
            arn
            deployers {
              status
              name
              outputs
            }
          }
        }
      }
    }
    GRAPHQL
    post '/graphql',
         params: {
           query: query_string,
           variables: {
             accountId: account_id,
             deployerName: deployer_name
           }
         },
         headers: { "User-Arn": VALID_SOR_ARN },
         as: :json
    response = JSON.parse(@response.body)
    assert_equal account_id, response['data']['accounts'][0]['id']
    assert_equal 1, response['data']['accounts'][0]['baseline'][0]['latest']['deployers'].length
    assert_equal deployer_name, response['data']['accounts'][0]['baseline'][0]['latest']['deployers'][0]['name']
  end

  test 'should return no deployers for invalid deployer name' do
    account_id = '123'
    region1 = 'us-east-1'
    create_account(
      VALID_SOR_ARN,
      'Logging Account',
      'TENANT',
      account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [region1]
    )

    region1_execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    region1_start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'foobar'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution VALID_SOR_ARN, account_id, region1_execution_arn, region1, region1_start_time, status, type, deployers, configuration_document

    query_string = <<-GRAPHQL
    query($accountId: String!, $deployerName: String) {
      accounts (id: $accountId, deployerName: $deployerName) {
        id
        name
        regions
        baseline {
          region
          latest {
            arn
            deployers {
              status
              name
              outputs
            }
          }
        }
      }
    }
    GRAPHQL
    post '/graphql',
         params: {
           query: query_string,
           variables: {
             accountId: account_id,
             deployerName: deployer_name
           }
         },
         headers: { "User-Arn": VALID_SOR_ARN },
         as: :json
    response = JSON.parse(@response.body)
    assert_equal account_id, response['data']['accounts'][0]['id']
    assert_equal 0, response['data']['accounts'][0]['baseline'][0]['latest']['deployers'].length
  end

  test 'should filter accounts based on business_unit' do
    create_account(
      VALID_SOR_ARN,
      'Account 123',
      'TENANT',
      '123',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu-1',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )

    create_account(
      VALID_SOR_ARN,
      'Account 456',
      'TENANT',
      '456',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu-1',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )

    create_account(
      VALID_SOR_ARN,
      'Account 789',
      'TENANT',
      '789',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu-2',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )

    query_string = <<-GRAPHQL
    query($business_unit: String) {
      accounts (businessUnit: $business_unit) {
        id
        name
        businessUnit
      }
    }
    GRAPHQL
    post '/graphql',
         params: {
           query: query_string,
           variables: {
             business_unit: 'test-bu-1'
           }
         },
         headers: { "User-Arn": VALID_SOR_ARN },
         as: :json
    response = JSON.parse(@response.body)
    assert_equal 2, response['data']['accounts'].length
    assert_equal true, (response['data']['accounts'].all? { |account| account['businessUnit'] == 'test-bu-1' })
  end

  test 'should return no accounts for invalid business_unit' do
    create_account(
      VALID_SOR_ARN,
      'Account 123',
      'TENANT',
      '123',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu-1',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )

    create_account(
      VALID_SOR_ARN,
      'Account 456',
      'TENANT',
      '456',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu-2',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )

    query_string = <<-GRAPHQL
    query($business_unit: String) {
      accounts (businessUnit: $business_unit) {
        id
        name
        businessUnit
      }
    }
    GRAPHQL
    post '/graphql',
         params: {
           query: query_string,
           variables: {
             business_unit: 'invalid'
           }
         },
         headers: { "User-Arn": VALID_SOR_ARN },
         as: :json
    response = JSON.parse(@response.body)
    assert_equal 0, response['data']['accounts'].length
  end
end
