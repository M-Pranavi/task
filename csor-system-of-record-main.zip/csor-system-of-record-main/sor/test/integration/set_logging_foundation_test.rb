# frozen_string_literal: true

require 'test_helper'

class SetLoggingFoundationTest < ActionDispatch::IntegrationTest
  test 'should return null when no logging configuration is set' do
    response = get_logging_foundation_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'should deny non admins' do
    account_id = '12345'
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      }
    ]

    response = mutate_logging_foundation INVALID_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links

    assert_equal 'Not authorized to perform set_logging_foundation mutation', response['errors'][0]['message']
  end

  test 'should create new key if key does not exist' do
    account_id = '123'
    region = 'us-east-2'
    vpc_id = 'vpc-123'
    public_subnet_ids = ['subnet-public-1']
    private_subnet_ids = ['subnet-private-1']
    private_eks_subnet_ids = ['subnet-eks-private-1']
    vpc_cidr = '0.0.0.0/8'
    vpc_cidr_allocation = ['0.0.0.0/0']
    private_zone_id = 'a'
    dimension_private_zone_id = 'b'
    braintree_api_com_zone_id = 'c'
    fdfg_sftp_whitelist_cidrs = ['1234/12', '5678/12']
    vpc_dns_addr = 'test-addr'
    availability_zones_dsv = 'test-az1,test-az2'
    asm_endpoint_ips = ['123/1', '456/1']
    autoscaling_endpoint_ips = ['123/2', '456/1']
    cloudformation_endpoint_ips = ['123/3', '456/1']
    dynamodb_endpoint_cidr_blocks = ['123/4', '456/1']
    ec2_endpoint_ips = ['123/5', '456/1']
    elasticloadbalancing_endpoint_ips = ['123/6', '456/1']
    s3_endpoint_cidr_blocks = ['123/7', '456/1']
    sts_endpoint_ips = ['123/8', '456/1']
    logs_endpoint_ips = ['123/9', '456/1']
    efs_endpoint_ips = ['123/10', '456/1']
    sqs_endpoint_ips = ['123/11', '456/1']
    public_access_cidrs = ['208.44.152.128/26', '52.15.154.34/32', '35.156.23.186/32', '52.8.154.168/32', '52.0.40.220/32']
    response = mutate_network_foundation INVALID_ARN, account_id, region, vpc_id, public_subnet_ids, private_subnet_ids, private_eks_subnet_ids, vpc_cidr, vpc_cidr_allocation, private_zone_id,
                                         dimension_private_zone_id, braintree_api_com_zone_id, fdfg_sftp_whitelist_cidrs, asm_endpoint_ips, autoscaling_endpoint_ips, cloudformation_endpoint_ips,
                                         dynamodb_endpoint_cidr_blocks, ec2_endpoint_ips, elasticloadbalancing_endpoint_ips, s3_endpoint_cidr_blocks, sts_endpoint_ips, logs_endpoint_ips,
                                         efs_endpoint_ips, sqs_endpoint_ips, public_access_cidrs, vpc_dns_addr, availability_zones_dsv

    assert_not_nil response

    account_id = '12345'
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      }
    ]

    response = mutate_logging_foundation VALID_SOR_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links
    assert_equal account_id, response['data']['setLoggingFoundation']['logging']['accountId']
    assert_equal s3_raw_bucket, response['data']['setLoggingFoundation']['logging']['s3RawBucket']
    assert_equal logging_iam_role, response['data']['setLoggingFoundation']['logging']['loggingIamRole']
    assert_equal cloudtrail_sqs_queue, response['data']['setLoggingFoundation']['logging']['cloudtrailSqsQueue']
    assert_equal vpcflow_sqs_queue, response['data']['setLoggingFoundation']['logging']['vpcflowSqsQueue']
    assert_equal oam_links, response['data']['setLoggingFoundation']['logging']['oamLinks']
  end

  test 'should add new logging foundation to SoR' do
    account_id = '12345'
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      }
    ]

    response = mutate_logging_foundation VALID_SOR_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links
    assert_equal account_id, response['data']['setLoggingFoundation']['logging']['accountId']
    assert_equal s3_raw_bucket, response['data']['setLoggingFoundation']['logging']['s3RawBucket']
    assert_equal logging_iam_role, response['data']['setLoggingFoundation']['logging']['loggingIamRole']
    assert_equal cloudtrail_sqs_queue, response['data']['setLoggingFoundation']['logging']['cloudtrailSqsQueue']
    assert_equal vpcflow_sqs_queue, response['data']['setLoggingFoundation']['logging']['vpcflowSqsQueue']
    assert_equal oam_links, response['data']['setLoggingFoundation']['logging']['oamLinks']
  end

  test 'return empty if there is not data of logging foundation' do
    response = get_logging_foundation_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'return single and a list of logging foundation' do
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      },
      {
        'region' => 'us-east-1',
        'arn' => 'test-arn'
      }
    ]
    account_id1 = '12345'
    mutate1 = mutate_logging_foundation VALID_SOR_ARN, account_id1, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links
    assert_not_nil mutate1

    account_id2 = '5678'
    mutate2 = mutate_logging_foundation VALID_SOR_ARN, account_id2, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links
    assert_not_nil mutate2
    response = get_logging_foundation_details VALID_SOR_ARN
    assert_nil response['errors']
    assert_equal oam_links[0], response['data']['foundation']['logging']['oamLinks'][0]
    assert_equal oam_links[1], response['data']['foundation']['logging']['oamLinks'][1]
  end

  test 'should update logging foundation' do
    account_id = '12345'
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      }
    ]

    response = mutate_logging_foundation VALID_SOR_ARN, '999', 'random', logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, []
    assert_equal '999', response['data']['setLoggingFoundation']['logging']['accountId']

    response = mutate_logging_foundation VALID_SOR_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links
    assert_equal account_id, response['data']['setLoggingFoundation']['logging']['accountId']
    assert_equal s3_raw_bucket, response['data']['setLoggingFoundation']['logging']['s3RawBucket']
    assert_equal logging_iam_role, response['data']['setLoggingFoundation']['logging']['loggingIamRole']
    assert_equal cloudtrail_sqs_queue, response['data']['setLoggingFoundation']['logging']['cloudtrailSqsQueue']
    assert_equal vpcflow_sqs_queue, response['data']['setLoggingFoundation']['logging']['vpcflowSqsQueue']
    assert_equal oam_links, response['data']['setLoggingFoundation']['logging']['oamLinks']
  end

  test 'idompotency of logging foundation' do
    account_id = '12345'
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      }
    ]
    response1 = mutate_logging_foundation VALID_SOR_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links
    response2 = mutate_logging_foundation VALID_SOR_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links
    assert_equal response1, response2
    assert response1['data'], response2['data']
    assert_equal response1['data']['setLoggingFoundation']['logging']['accountId'], response2['data']['setLoggingFoundation']['logging']['accountId']
    assert_nil response2['errors']
  end

  test 'dual write to braintree document field' do
    account_id = '12345'
    s3_raw_bucket = 'test-raw-bucket'
    logging_iam_role = 'test-iam-role'
    cloudtrail_sqs_queue = 'test-cloudtrail-sqs'
    vpcflow_sqs_queue = 'test-vpcflow-sqs'
    oam_links = [
      {
        'region' => 'us-east-2',
        'arn' => 'test-arn'
      },
      {
        'region' => 'us-east-1',
        'arn' => 'test-arn-2'
      }
    ]

    mutate_logging_foundation VALID_SOR_ARN, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links

    # Query the foundation and verify data is written to both locations
    query_string = <<-GRAPHQL
      {
        foundation {
          logging {
            accountId
            s3RawBucket
            loggingIamRole
            cloudtrailSqsQueue
            vpcflowSqsQueue
            oamLinks {
              region
              arn
            }
          }
          braintree {
            logging {
              accountId
              s3RawBucket
              loggingIamRole
              cloudtrailSqsQueue
              vpcflowSqsQueue
              oamLinks {
                region
                arn
              }
            }
          }
        }
      }
    GRAPHQL

    post '/graphql',
         params: { query: query_string },
         as: :json
    response = JSON.parse(@response.body)

    # Check direct field access
    assert_equal account_id, response['data']['foundation']['logging']['accountId']
    assert_equal s3_raw_bucket, response['data']['foundation']['logging']['s3RawBucket']
    assert_equal logging_iam_role, response['data']['foundation']['logging']['loggingIamRole']
    assert_equal cloudtrail_sqs_queue, response['data']['foundation']['logging']['cloudtrailSqsQueue']
    assert_equal vpcflow_sqs_queue, response['data']['foundation']['logging']['vpcflowSqsQueue']
    assert_equal oam_links[0]['region'], response['data']['foundation']['logging']['oamLinks'][0]['region']
    assert_equal oam_links[0]['arn'], response['data']['foundation']['logging']['oamLinks'][0]['arn']

    # Check data in braintree document field
    assert_equal account_id, response['data']['foundation']['braintree']['logging']['accountId']
    assert_equal s3_raw_bucket, response['data']['foundation']['braintree']['logging']['s3RawBucket']
    assert_equal logging_iam_role, response['data']['foundation']['braintree']['logging']['loggingIamRole']
    assert_equal cloudtrail_sqs_queue, response['data']['foundation']['braintree']['logging']['cloudtrailSqsQueue']
    assert_equal vpcflow_sqs_queue, response['data']['foundation']['braintree']['logging']['vpcflowSqsQueue']
    assert_equal oam_links[0]['region'], response['data']['foundation']['braintree']['logging']['oamLinks'][0]['region']
    assert_equal oam_links[0]['arn'], response['data']['foundation']['braintree']['logging']['oamLinks'][0]['arn']
  end
end
