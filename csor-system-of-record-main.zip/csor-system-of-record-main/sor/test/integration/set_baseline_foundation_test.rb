# frozen_string_literal: true

require 'test_helper'

class SetBaselineFoundationTest < ActionDispatch::IntegrationTest
  test 'should return null when no baseline foundation configuration is set' do
    response = get_baseline_foundation_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'should deny non admins' do
    orchestration_account_id = '123456'
    region = 'us-east-2'
    environment = 'dev'
    vpc_id = 'vpc-123'
    private_subnets = ['subnet-private-1']
    public_subnets = ['subnet-public-1']
    terraform_state_key = 'terraform/state/key'
    terraform_dynamodb_lock_table = 'terraform-lock-table'
    dynamodb_global_deployer_lock_table = 'global-deployer-lock-table'

    baseline = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        loggingDeployerArn: 'arn:aws:iam::123456:role/logging-deployer',
        networkDeployerArn: 'arn:aws:iam::123456:role/network-deployer',
        securityShieldDeployerArn: 'arn:aws:iam::123456:role/security-shield-deployer',
        cicdDeployerArn: 'arn:aws:iam::123456:role/cicd-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    response = mutate_baseline_foundation(
      INVALID_ARN,
      orchestration_account_id,
      region,
      environment,
      vpc_id,
      private_subnets,
      public_subnets,
      terraform_state_key,
      terraform_dynamodb_lock_table,
      dynamodb_global_deployer_lock_table,
      baseline
    )

    assert_equal 'Not authorized to perform set_baseline_foundation mutation', response['errors'][0]['message']
  end

  test 'should add new baseline foundation to SoR' do
    orchestration_account_id = '123456'
    region = 'us-east-2'
    environment = 'dev'
    vpc_id = 'vpc-123'
    private_subnets = ['subnet-private-1']
    public_subnets = ['subnet-public-1']
    terraform_state_key = 'terraform/state/key'
    terraform_dynamodb_lock_table = 'terraform-lock-table'
    dynamodb_global_deployer_lock_table = 'global-deployer-lock-table'

    baseline = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        loggingDeployerArn: 'arn:aws:iam::123456:role/logging-deployer',
        networkDeployerArn: 'arn:aws:iam::123456:role/network-deployer',
        securityShieldDeployerArn: 'arn:aws:iam::123456:role/security-shield-deployer',
        cicdDeployerArn: 'arn:aws:iam::123456:role/cicd-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    response = mutate_baseline_foundation(
      VALID_SOR_ARN,
      orchestration_account_id,
      region,
      environment,
      vpc_id,
      private_subnets,
      public_subnets,
      terraform_state_key,
      terraform_dynamodb_lock_table,
      dynamodb_global_deployer_lock_table,
      baseline
    )

    assert_equal orchestration_account_id, response['data']['setBaselineFoundation']['csor']['orchestrationAccountId']
    assert_equal region, response['data']['setBaselineFoundation']['csor']['region']
    assert_equal environment, response['data']['setBaselineFoundation']['csor']['environment']
    assert_equal vpc_id, response['data']['setBaselineFoundation']['csor']['vpcId']
    assert_equal private_subnets, response['data']['setBaselineFoundation']['csor']['privateSubnets']
    assert_equal public_subnets, response['data']['setBaselineFoundation']['csor']['publicSubnets']
    assert_equal terraform_state_key, response['data']['setBaselineFoundation']['csor']['terraformStateKey']
    assert_equal terraform_dynamodb_lock_table, response['data']['setBaselineFoundation']['csor']['terraformDynamodbLockTable']
    assert_equal dynamodb_global_deployer_lock_table, response['data']['setBaselineFoundation']['csor']['dynamodbGlobalDeployerLockTable']

    # Verify baseline configuration
    assert_equal baseline[:terraformStateFileBucket], response['data']['setBaselineFoundation']['csor']['baseline']['terraformStateFileBucket']
    assert_equal baseline[:terraformPlanBucket], response['data']['setBaselineFoundation']['csor']['baseline']['terraformPlanBucket']

    # Verify deployerArns configuration
    assert_equal baseline[:deployerArns][:baseDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['baseDeployerArn']
    assert_equal baseline[:deployerArns][:stacksetDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['stacksetDeployerArn']
    assert_equal baseline[:deployerArns][:loggingDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['loggingDeployerArn']
    assert_equal baseline[:deployerArns][:networkDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['networkDeployerArn']
    assert_equal baseline[:deployerArns][:securityShieldDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['securityShieldDeployerArn']
    assert_equal baseline[:deployerArns][:cicdDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['cicdDeployerArn']

    # Verify stackset configuration
    assert_equal baseline[:stackset][:name], response['data']['setBaselineFoundation']['csor']['baseline']['stackset']['name']
  end

  test 'should update baseline foundation' do
    # First create baseline foundation
    orchestration_account_id = '123456'
    region = 'us-east-2'
    environment = 'DEV'
    vpc_id = 'vpc-123'
    private_subnets = ['subnet-private-1']
    public_subnets = ['subnet-public-1']
    terraform_state_key = 'terraform/state/key'
    terraform_dynamodb_lock_table = 'terraform-lock-table'
    dynamodb_global_deployer_lock_table = 'global-deployer-lock-table'

    baseline = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        loggingDeployerArn: 'arn:aws:iam::123456:role/logging-deployer',
        networkDeployerArn: 'arn:aws:iam::123456:role/network-deployer',
        securityShieldDeployerArn: 'arn:aws:iam::123456:role/security-shield-deployer',
        cicdDeployerArn: 'arn:aws:iam::123456:role/cicd-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    mutate_baseline_foundation(
      VALID_SOR_ARN,
      orchestration_account_id,
      region,
      environment,
      vpc_id,
      private_subnets,
      public_subnets,
      terraform_state_key,
      terraform_dynamodb_lock_table,
      dynamodb_global_deployer_lock_table,
      baseline
    )

    # Now update it with new values
    updated_orchestration_account_id = '789012'
    updated_region = 'us-west-2'
    updated_environment = 'qa'
    updated_vpc_id = 'vpc-456'
    updated_private_subnets = ['subnet-private-2']
    updated_public_subnets = ['subnet-public-2']
    updated_terraform_state_key = 'terraform/state/key/updated'
    updated_terraform_dynamodb_lock_table = 'terraform-lock-table-updated'
    updated_dynamodb_global_deployer_lock_table = 'global-deployer-lock-table-updated'

    updated_baseline = {
      terraformStateFileBucket: 'terraform-state-bucket-updated',
      terraformPlanBucket: 'terraform-plan-bucket-updated',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::789012:role/base-deployer-updated',
        stacksetDeployerArn: 'arn:aws:iam::789012:role/stackset-deployer-updated',
        loggingDeployerArn: 'arn:aws:iam::789012:role/logging-deployer-updated',
        networkDeployerArn: 'arn:aws:iam::789012:role/network-deployer-updated',
        securityShieldDeployerArn: 'arn:aws:iam::789012:role/security-shield-deployer-updated',
        cicdDeployerArn: 'arn:aws:iam::789012:role/cicd-deployer-updated'
      },
      stackset: {
        name: 'stackset-name-updated'
      }
    }

    response = mutate_baseline_foundation(
      VALID_SOR_ARN,
      updated_orchestration_account_id,
      updated_region,
      updated_environment,
      updated_vpc_id,
      updated_private_subnets,
      updated_public_subnets,
      updated_terraform_state_key,
      updated_terraform_dynamodb_lock_table,
      updated_dynamodb_global_deployer_lock_table,
      updated_baseline
    )

    assert_equal updated_orchestration_account_id, response['data']['setBaselineFoundation']['csor']['orchestrationAccountId']
    assert_equal updated_region, response['data']['setBaselineFoundation']['csor']['region']
    assert_equal updated_environment, response['data']['setBaselineFoundation']['csor']['environment']
    assert_equal updated_vpc_id, response['data']['setBaselineFoundation']['csor']['vpcId']
    assert_equal updated_private_subnets, response['data']['setBaselineFoundation']['csor']['privateSubnets']
    assert_equal updated_public_subnets, response['data']['setBaselineFoundation']['csor']['publicSubnets']
    assert_equal updated_terraform_state_key, response['data']['setBaselineFoundation']['csor']['terraformStateKey']
    assert_equal updated_terraform_dynamodb_lock_table, response['data']['setBaselineFoundation']['csor']['terraformDynamodbLockTable']
    assert_equal updated_dynamodb_global_deployer_lock_table, response['data']['setBaselineFoundation']['csor']['dynamodbGlobalDeployerLockTable']

    # Verify updated baseline configuration
    assert_equal updated_baseline[:terraformStateFileBucket], response['data']['setBaselineFoundation']['csor']['baseline']['terraformStateFileBucket']
    assert_equal updated_baseline[:terraformPlanBucket], response['data']['setBaselineFoundation']['csor']['baseline']['terraformPlanBucket']

    # Verify updated deployerArns configuration
    assert_equal updated_baseline[:deployerArns][:baseDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['baseDeployerArn']
    assert_equal updated_baseline[:deployerArns][:stacksetDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['stacksetDeployerArn']
    assert_equal updated_baseline[:deployerArns][:loggingDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['loggingDeployerArn']
    assert_equal updated_baseline[:deployerArns][:networkDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['networkDeployerArn']
    assert_equal updated_baseline[:deployerArns][:securityShieldDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['securityShieldDeployerArn']
    assert_equal updated_baseline[:deployerArns][:cicdDeployerArn], response['data']['setBaselineFoundation']['csor']['baseline']['deployerArns']['cicdDeployerArn']

    # Verify updated stackset configuration
    assert_equal updated_baseline[:stackset][:name], response['data']['setBaselineFoundation']['csor']['baseline']['stackset']['name']
  end

  test 'idempotency of baseline foundation' do
    orchestration_account_id = '123456'
    region = 'us-east-2'
    environment = 'dev'
    vpc_id = 'vpc-123'
    private_subnets = ['subnet-private-1']
    public_subnets = ['subnet-public-1']
    terraform_state_key = 'terraform/state/key'
    terraform_dynamodb_lock_table = 'terraform-lock-table'
    dynamodb_global_deployer_lock_table = 'global-deployer-lock-table'

    baseline = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        loggingDeployerArn: 'arn:aws:iam::123456:role/logging-deployer',
        networkDeployerArn: 'arn:aws:iam::123456:role/network-deployer',
        securityShieldDeployerArn: 'arn:aws:iam::123456:role/security-shield-deployer',
        cicdDeployerArn: 'arn:aws:iam::123456:role/cicd-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    response1 = mutate_baseline_foundation(
      VALID_SOR_ARN,
      orchestration_account_id,
      region,
      environment,
      vpc_id,
      private_subnets,
      public_subnets,
      terraform_state_key,
      terraform_dynamodb_lock_table,
      dynamodb_global_deployer_lock_table,
      baseline
    )

    response2 = mutate_baseline_foundation(
      VALID_SOR_ARN,
      orchestration_account_id,
      region,
      environment,
      vpc_id,
      private_subnets,
      public_subnets,
      terraform_state_key,
      terraform_dynamodb_lock_table,
      dynamodb_global_deployer_lock_table,
      baseline
    )

    assert_equal response1, response2
    assert response1['data'], response2['data']
    assert_equal response1['data']['setBaselineFoundation']['csor']['orchestrationAccountId'], response2['data']['setBaselineFoundation']['csor']['orchestrationAccountId']
    assert_nil response2['errors']
  end
end
