# frozen_string_literal: true

require 'test_helper'

class FCDTest < ActionDispatch::IntegrationTest
  test 'should not return fcd when there are none' do
    query_string = <<-GRAPHQL
      {
        fcd {
          configurationDocument
          createdAt
        }
      }
    GRAPHQL
    post '/graphql',
         params: { query: query_string },
         as: :json
    response = JSON.parse(@response.body)
    assert_nil response['data']['fcd']
  end

  test 'should add new FCD to SOR' do
    test_fcd = { "base_depoyer": '1.1.1', "stackset_deployer": '1.2.3' }

    response = create_fcd(test_fcd, VALID_SOR_ARN)

    assert_equal test_fcd[:base_deployer], response['data']['createFcd']['configurationDocument']['base_deployer']
    assert_equal test_fcd[:stackset_deployer], response['data']['createFcd']['configurationDocument']['stackset_deployer']
    assert_not_nil response['data']['createFcd']['createdAt']
  end

  test 'should return latest valid FCD' do
    first_test_fcd = { "base_depoyer": '1.1.1', "stackset_deployer": '1.2.3' }

    first_response = create_fcd(first_test_fcd, VALID_SOR_ARN)

    assert_equal first_test_fcd[:base_deployer], first_response['data']['createFcd']['configurationDocument']['base_deployer']
    assert_equal first_test_fcd[:stackset_deployer], first_response['data']['createFcd']['configurationDocument']['stackset_deployer']
    assert_not_nil first_response['data']['createFcd']['createdAt']

    # sleep so we ensure the created_ats are different
    sleep(1)

    final_test_fcd = { "base_depoyer": '1.1.2', "stackset_deployer": '1.2.4' }

    final_response = create_fcd(final_test_fcd, VALID_SOR_ARN)

    assert_equal final_test_fcd[:base_deployer], final_response['data']['createFcd']['configurationDocument']['base_deployer']
    assert_equal final_test_fcd[:stackset_deployer], final_response['data']['createFcd']['configurationDocument']['stackset_deployer']
    assert_not_nil final_response['data']['createFcd']['createdAt']

    query_string = <<-GRAPHQL
      {
        fcd {
          configurationDocument
          createdAt
        }
      }
    GRAPHQL
    post '/graphql',
         params: { query: query_string },
         as: :json
    query_response = JSON.parse(@response.body)

    assert_equal final_test_fcd[:base_deployer], query_response['data']['fcd']['configurationDocument']['base_deployer']
    assert_equal final_test_fcd[:stackset_deployer], query_response['data']['fcd']['configurationDocument']['stackset_deployer']
    assert_equal final_response['data']['createFcd']['createdAt'], query_response['data']['fcd']['createdAt']
    assert_not_equal first_response['data']['createFcd']['createdAt'], query_response['data']['fcd']['createdAt']
  end
end
