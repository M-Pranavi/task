# frozen_string_literal: true

require 'test_helper'

class UpdateStateMachineDeployerTest < ActionDispatch::IntegrationTest
  valid_user_arn = 'arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/unit-test'

  def setup
    @account_id = '123'
    @region = 'us-east-1'
    create_account(
      VALID_SOR_ARN,
      'My Tenant Account',
      'TENANT',
      @account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [@region]
    )
  end

  test 'should not create new state machine execution for missing account id' do
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    response = create_state_machine_execution valid_user_arn, '1', execution_arn, @region, start_time, status, type, deployers, configuration_document
    assert_nil response['data']
    assert_equal 1, response['errors'].length
  end

  test 'should update state machine deployer data' do
    arn = 'arn:aws:sts::5678:assumed-role/config_deployer_role_baseline/config_deployer'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'config_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    deployer_status = 'Failed'
    version = '0.0.1'
    outputs = {
      'foo' => 'bar'
    }
    resources = {
      'r1' => 'id1'
    }
    snow_ticket = 'my-ticket'
    response = update_state_machine_deployer arn, execution_arn, deployer_name, deployer_status, version, outputs, resources, snow_ticket, nil
    assert_equal execution_arn, response['data']['updateStateMachineDeployer']['arn']
    assert_equal status, response['data']['updateStateMachineDeployer']['status']
    assert_equal start_time, response['data']['updateStateMachineDeployer']['startTime']
    assert_equal deployers[0][:name], response['data']['updateStateMachineDeployer']['deployers'][0]['name']
    assert_equal deployers[0][:version], response['data']['updateStateMachineDeployer']['deployers'][0]['version']
    assert_equal deployers[0][:status], response['data']['updateStateMachineDeployer']['deployers'][0]['status']
    assert_equal deployers[0][:outputs], response['data']['updateStateMachineDeployer']['deployers'][0]['outputs']
    assert_equal deployers[0][:resources], response['data']['updateStateMachineDeployer']['deployers'][0]['resources']
    assert_equal deployer_name, response['data']['updateStateMachineDeployer']['deployers'][1]['name']
    assert_equal version, response['data']['updateStateMachineDeployer']['deployers'][1]['version']
    assert_equal deployer_status, response['data']['updateStateMachineDeployer']['deployers'][1]['status']
    assert_equal outputs, response['data']['updateStateMachineDeployer']['deployers'][1]['outputs']
    assert_equal resources, response['data']['updateStateMachineDeployer']['deployers'][1]['resources']
    assert_equal snow_ticket, response['data']['updateStateMachineDeployer']['deployers'][1]['snowTicket']
  end

  test 'should deny update if not deployer or admin' do
    arn = 'arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'config_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    deployer_status = 'Success'
    version = '0.0.1'
    outputs = {
      'foo' => 'bar3'
    }
    response = update_state_machine_deployer arn, execution_arn, deployer_name, deployer_status, version, outputs, {}, nil, nil
    assert_equal 'Not authorized to perform update_state_machine_deployer mutation', response['errors'][0]['message']
  end

  test 'should deny update if different deployer' do
    arn = 'arn:aws:sts::5678:assumed-role/base_deployer_role_baseline/base_deployer'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'config_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    deployer_status = 'Success'
    version = '0.0.1'
    outputs = {
      'foo' => 'bar3'
    }
    response = update_state_machine_deployer arn, execution_arn, deployer_name, deployer_status, version, outputs, {}, nil, nil
    assert_equal 'Not authorized: base_deployer attempted to update config_deployer outputs', response['errors'][0]['message']
  end

  test 'should allow eks_deployer role to write to kap deployer' do
    arn = 'arn:aws:sts::5678:assumed-role/eks_deployer_role_provision/eks_deployer'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'kap_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    deployer_status = 'Success'
    version = '0.0.1'
    outputs = {
      'foo' => 'bar3'
    }
    response = update_state_machine_deployer arn, execution_arn, deployer_name, deployer_status, version, outputs, {}, nil, nil
    assert_not_nil response
    assert_equal execution_arn, response['data']['updateStateMachineDeployer']['arn']
    assert_equal @region, response['data']['updateStateMachineDeployer']['region']
    assert_equal status, response['data']['updateStateMachineDeployer']['status']
    assert_equal start_time, response['data']['updateStateMachineDeployer']['startTime']
    assert_equal deployers[0][:name], response['data']['updateStateMachineDeployer']['deployers'][0]['name']
    assert_equal deployers[0][:version], response['data']['updateStateMachineDeployer']['deployers'][0]['version']
    assert_equal deployers[0][:status], response['data']['updateStateMachineDeployer']['deployers'][0]['status']
    assert_equal deployers[0][:outputs], response['data']['updateStateMachineDeployer']['deployers'][0]['outputs']
    assert_equal deployers[0][:resources], response['data']['updateStateMachineDeployer']['deployers'][0]['resources']
  end

  test 'should deny baseline to create provision' do
    invalid_user_arn = 'arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'PROVISION'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    response = create_state_machine_execution invalid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document

    assert_equal 'Baseline attempted to create a non-baseline execution', response['errors'][0]['message']
  end

  test 'should deny provision to create baseline' do
    invalid_user_arn = 'arn:aws:sts::5678:assumed-role/request-submitter-provision-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    response = create_state_machine_execution invalid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document

    assert_equal 'Provision attempted to create a non-provision execution', response['errors'][0]['message']
  end

  test 'should deny provision from updating non-provision execution' do
    invalid_user_arn = 'arn:aws:sts::5678:assumed-role/execution-reporter-provision-role/unit-test'
    user_arn = 'arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document

    new_status = 'FAILED'

    response = update_state_machine invalid_user_arn, { 'executionArn': execution_arn, 'status': new_status }

    assert_equal 'Provision is attempting to update a non-provision execution', response['errors'][0]['message']
  end

  test 'should deny baseline from updating non-baseline execution' do
    invalid_user_arn = 'arn:aws:sts::5678:assumed-role/execution-reporter-baseline-role/unit-test'
    user_arn = 'arn:aws:sts::5678:assumed-role/request-submitter-provision-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'PROVISION'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document

    new_status = 'FAILED'

    response = update_state_machine invalid_user_arn, { 'executionArn': execution_arn, 'status': new_status }

    assert_equal 'Baseline is attempting to update a non-baseline execution', response['errors'][0]['message']
  end

  test 'should update state machine baseline execution data' do
    arn = 'arn:aws:sts::5678:assumed-role/execution-reporter-baseline-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'config_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document

    new_region = 'us-west-2'
    new_status = 'SUCCEEDED'

    response = update_state_machine arn, { 'executionArn': execution_arn, 'region': new_region, 'status': new_status }

    assert_equal execution_arn, response['data']['updateStateMachineExecution']['arn']
    assert_equal new_region, response['data']['updateStateMachineExecution']['region']
    assert_equal new_status, response['data']['updateStateMachineExecution']['status']
  end

  test 'should return empty response on no accounts' do
    execution_arn = 'abc'
    response = query_execution_details valid_user_arn, execution_arn

    # testing empty return
    assert_nil response['data']['statusByExecution']
  end

  test 'should return a single response on an execution' do
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {
          "ips": '192.168.1.1',
          "eips": [
            '192.168.0.1',
            '172.16.0.1'
          ],
          "vpc_id": 'vpc-123456',
          "bucket_name": 'bkt-test-dtbtcops944'
        },
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document

    query_response = query_execution_details valid_user_arn, execution_arn
    # Test specific fields
    assert_equal execution_arn, query_response['data']['statusByExecution']['arn']
    assert_equal status, query_response['data']['statusByExecution']['status']
    assert_equal start_time, query_response['data']['statusByExecution']['startTime']
    assert_equal type, query_response['data']['statusByExecution']['stateMachineType']

    # Tes the  deployer in the 'deployers' array
    first_deployer = query_response['data']['statusByExecution']['deployers'][0]
    assert_equal 'base_deployer', first_deployer['name']
    assert_nil first_deployer['repository']
    assert_equal 'Unknown', first_deployer['version']
    assert_equal 'Not_Started', first_deployer['status']
    assert_equal('192.168.1.1', first_deployer['outputs']['ips'])
    assert_equal({}, first_deployer['resources'])
  end

  test 'should return responses based on execution_arns' do
    account_id = '533266969476'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    create_account(
      valid_user_arn,
      'Test App',
      'TENANT',
      account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [@region]
    )
    configuration_document = { a: 'b' }

    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    response1 = create_state_machine_execution valid_user_arn, account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    assert_not_nil response1

    execution_arn2 = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c8'
    start_time2 = '2024-05-23T13:37:24Z'
    response2 = create_state_machine_execution valid_user_arn, account_id, execution_arn2, @region, start_time2, status, type, deployers, configuration_document
    assert_not_nil response2

    assert_nil response2['errors']
    get_acccount = get_account_details valid_user_arn, account_id
    assert_equal execution_arn2, get_acccount['data']['accounts'][0]['baseline'][0]['executions'][0]['arn']
    assert_equal execution_arn, get_acccount['data']['accounts'][0]['baseline'][0]['executions'][1]['arn']

    # Idompotency test for create state machine execution
    assert_equal get_acccount['data']['accounts'][0]['baseline'][0]['executions'][0]['deployers'], get_acccount['data']['accounts'][0]['baseline'][0]['executions'][1]['deployers']
    assert_nil response2['errors']
  end

  test 'idompotency on update state machine execution' do
    arn = 'arn:aws:sts::5678:assumed-role/execution-reporter-baseline-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'config_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_sme = create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    assert_not_nil create_sme

    new_status = 'SUCCEEDED'
    response1 = update_state_machine arn, { 'executionArn': execution_arn, 'status': new_status }
    response2 = update_state_machine arn, { 'executionArn': execution_arn, 'status': new_status }
    assert_equal response1, response2
    assert response1['data'], response2['data']
    assert_equal response1['data']['updateStateMachineExecution']['arn'], response2['data']['updateStateMachineExecution']['arn']
    assert_nil response2['errors']
  end

  test 'idompotency on update state machine execution deployers' do
    arn = 'arn:aws:sts::5678:assumed-role/base_deployer_role_baseline/base_deployer'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'base_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    deployer_status = 'Not_Started'
    version = '0.0.1'
    outputs = {
      'foo' => 'bar3'
    }
    snow_ticket = 'my-ticket'
    response1 = update_state_machine_deployer arn, execution_arn, deployer_name, deployer_status, version, outputs, {}, snow_ticket, nil
    response2 = update_state_machine_deployer arn, execution_arn, deployer_name, deployer_status, version, outputs, {}, snow_ticket, nil
    assert_not_nil response1
    assert_not_nil response2
    assert_equal response1, response2
    assert response1['data'], response2['data']
    assert_equal response1['data']['updateStateMachineDeployer']['deployers'], response2['data']['updateStateMachineDeployer']['deployers']
    assert_nil response2['errors']
  end

  test 'should update failureReason data if given.' do
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_response = create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    assert_not_nil create_response

    update_response = update_state_machine_deployer VALID_SOR_ARN, execution_arn, 'base_deployer', 'Not_Started', '0.1.0', {}, {}, nil, 'testing failure reason'

    assert_not_nil update_response
    assert_equal 'testing failure reason', update_response['data']['updateStateMachineDeployer']['deployers'][0]['failureReason']
  end

  test 'should default failureReason if nil' do
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_response = create_state_machine_execution valid_user_arn, @account_id, execution_arn, @region, start_time, status, type, deployers, configuration_document
    assert_not_nil create_response

    update_response = update_state_machine_deployer VALID_SOR_ARN, execution_arn, 'base_deployer', 'Not_Started', '0.1.0', {}, {}, nil, nil

    assert_not_nil update_response
    assert_nil update_response['data']['updateStateMachineDeployer']['deployers'][0]['failureReason']
  end
end
