# frozen_string_literal: true

require 'test_helper'

class SetProvisionFoundationTest < ActionDispatch::IntegrationTest
  test 'should return null when no provision foundation configuration is set' do
    response = get_provision_foundation_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'should deny non admins' do
    provision = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        eksDeployerArn: 'arn:aws:iam::123456:role/eks-deployer',
        kapDeployerArn: 'arn:aws:iam::123456:role/kap-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    response = mutate_provision_foundation(INVALID_ARN, provision)

    assert_equal 'Not authorized to perform set_provision_foundation mutation', response['errors'][0]['message']
  end

  test 'should add new provision foundation to SoR' do
    provision = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        eksDeployerArn: 'arn:aws:iam::123456:role/eks-deployer',
        kapDeployerArn: 'arn:aws:iam::123456:role/kap-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    response = mutate_provision_foundation(VALID_SOR_ARN, provision)

    # Verify provision configuration
    assert_equal provision[:terraformStateFileBucket], response['data']['setProvisionFoundation']['csor']['provision']['terraformStateFileBucket']
    assert_equal provision[:terraformPlanBucket], response['data']['setProvisionFoundation']['csor']['provision']['terraformPlanBucket']

    # Verify deployerArns configuration
    assert_equal provision[:deployerArns][:baseDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['baseDeployerArn']
    assert_equal provision[:deployerArns][:stacksetDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['stacksetDeployerArn']
    assert_equal provision[:deployerArns][:eksDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['eksDeployerArn']
    assert_equal provision[:deployerArns][:kapDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['kapDeployerArn']

    # Verify stackset configuration
    assert_equal provision[:stackset][:name], response['data']['setProvisionFoundation']['csor']['provision']['stackset']['name']
  end

  test 'should update provision foundation' do
    # First create provision foundation
    provision = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        eksDeployerArn: 'arn:aws:iam::123456:role/eks-deployer',
        kapDeployerArn: 'arn:aws:iam::123456:role/kap-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    mutate_provision_foundation(VALID_SOR_ARN, provision)

    # Now update it with new values
    updated_provision = {
      terraformStateFileBucket: 'terraform-state-file-bucket-updated',
      terraformPlanBucket: 'terraform-plan-bucket-updated',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::789012:role/base-deployer-updated',
        stacksetDeployerArn: 'arn:aws:iam::789012:role/stackset-deployer-updated',
        eksDeployerArn: 'arn:aws:iam::789012:role/eks-deployer-updated',
        kapDeployerArn: 'arn:aws:iam::789012:role/kap-deployer-updated'
      },
      stackset: {
        name: 'stackset-name-updated'
      }
    }

    response = mutate_provision_foundation(VALID_SOR_ARN, updated_provision)

    # Verify updated provision configuration
    assert_equal updated_provision[:terraformStateFileBucket], response['data']['setProvisionFoundation']['csor']['provision']['terraformStateFileBucket']
    assert_equal updated_provision[:terraformPlanBucket], response['data']['setProvisionFoundation']['csor']['provision']['terraformPlanBucket']

    # Verify updated deployerArns configuration
    assert_equal updated_provision[:deployerArns][:baseDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['baseDeployerArn']
    assert_equal updated_provision[:deployerArns][:stacksetDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['stacksetDeployerArn']
    assert_equal updated_provision[:deployerArns][:eksDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['eksDeployerArn']
    assert_equal updated_provision[:deployerArns][:kapDeployerArn], response['data']['setProvisionFoundation']['csor']['provision']['deployerArns']['kapDeployerArn']

    # Verify updated stackset configuration
    assert_equal updated_provision[:stackset][:name], response['data']['setProvisionFoundation']['csor']['provision']['stackset']['name']
  end

  test 'idempotency of provision foundation' do
    provision = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        eksDeployerArn: 'arn:aws:iam::123456:role/eks-deployer',
        kapDeployerArn: 'arn:aws:iam::123456:role/kap-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    response1 = mutate_provision_foundation(VALID_SOR_ARN, provision)
    response2 = mutate_provision_foundation(VALID_SOR_ARN, provision)

    assert_equal response1, response2
    assert response1['data'], response2['data']
    assert_equal response1['data']['setProvisionFoundation']['csor']['provision']['terraformStateFileBucket'],
                 response2['data']['setProvisionFoundation']['csor']['provision']['terraformStateFileBucket']
    assert_nil response2['errors']
  end

  test 'query retrieves provision foundation details' do
    provision = {
      terraformStateFileBucket: 'terraform-state-bucket',
      terraformPlanBucket: 'terraform-plan-bucket',
      deployerArns: {
        baseDeployerArn: 'arn:aws:iam::123456:role/base-deployer',
        stacksetDeployerArn: 'arn:aws:iam::123456:role/stackset-deployer',
        eksDeployerArn: 'arn:aws:iam::123456:role/eks-deployer',
        kapDeployerArn: 'arn:aws:iam::123456:role/kap-deployer'
      },
      stackset: {
        name: 'stackset-name'
      }
    }

    mutate_provision_foundation(VALID_SOR_ARN, provision)

    # Query the foundation and verify data is correctly returned
    response = get_provision_foundation_details(VALID_SOR_ARN)

    # Check field access for csor provision data
    assert_equal provision[:terraformStateFileBucket], response['data']['foundation']['csor']['provision']['terraformStateFileBucket']
    assert_equal provision[:terraformPlanBucket], response['data']['foundation']['csor']['provision']['terraformPlanBucket']

    # Check deployerArns configuration
    assert_equal provision[:deployerArns][:baseDeployerArn], response['data']['foundation']['csor']['provision']['deployerArns']['baseDeployerArn']
    assert_equal provision[:deployerArns][:stacksetDeployerArn], response['data']['foundation']['csor']['provision']['deployerArns']['stacksetDeployerArn']
    assert_equal provision[:deployerArns][:eksDeployerArn], response['data']['foundation']['csor']['provision']['deployerArns']['eksDeployerArn']
    assert_equal provision[:deployerArns][:kapDeployerArn], response['data']['foundation']['csor']['provision']['deployerArns']['kapDeployerArn']

    # Check stackset configuration
    assert_equal provision[:stackset][:name], response['data']['foundation']['csor']['provision']['stackset']['name']
  end
end
