# frozen_string_literal: true

require 'test_helper'

class AccountTypeTest < ActionDispatch::IntegrationTest
  # This method simulates the deployer filtering that now happens in AccountType instead of QueryType.select_deployer
  def filter_deployers(deployer_name, execution)
    return execution if deployer_name.nil?

    execution_copy = execution.deep_dup
    execution_copy['deployers'] = execution_copy['deployers'].select { |deployer| deployer['name'] == deployer_name }
    execution_copy
  end

  test 'should do nothing when deployer_name is nil' do
    deployer_name = nil
    execution = {
      'arn': 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:9df4ef3f-4717-43fd-83e5-51bdd6a18923',
      'deployers': [
        {
          'name': 'base_deployer',
          'status': 'Success',
          'outputs': { 'key1': 'value1' }
        },
        {
          'name': 'config_deployer',
          'status': 'Success',
          'outputs': { 'key2': 'value2' }
        }
      ]
    }.deep_stringify_keys

    num_deployers_before = execution['deployers'].length
    filtered_execution = filter_deployers(deployer_name, execution)
    assert_equal num_deployers_before, filtered_execution['deployers'].length
  end

  test 'should filter based on deployer name' do
    deployer_name = 'base_deployer'
    execution = {
      'arn': 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:9df4ef3f-4717-43fd-83e5-51bdd6a18923',
      'deployers': [
        {
          'name': 'base_deployer',
          'status': 'Success',
          'outputs': { 'key1': 'value1' }
        },
        {
          'name': 'config_deployer',
          'status': 'Success',
          'outputs': { 'key2': 'value2' }
        }
      ]
    }.deep_stringify_keys

    filtered_execution = filter_deployers(deployer_name, execution)
    assert_equal 1, filtered_execution['deployers'].length
    assert_equal deployer_name, filtered_execution['deployers'][0]['name']
  end

  test 'should return no deployers for invalid deployer name' do
    deployer_name = 'foobar'
    execution = {
      'arn': 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:9df4ef3f-4717-43fd-83e5-51bdd6a18923',
      'deployers': [
        {
          'name': 'base_deployer',
          'status': 'Success',
          'outputs': { 'key1': 'value1' }
        },
        {
          'name': 'config_deployer',
          'status': 'Success',
          'outputs': { 'key2': 'value2' }
        }
      ]
    }.deep_stringify_keys

    filtered_execution = filter_deployers(deployer_name, execution)
    assert_equal 0, filtered_execution['deployers'].length
  end
end
