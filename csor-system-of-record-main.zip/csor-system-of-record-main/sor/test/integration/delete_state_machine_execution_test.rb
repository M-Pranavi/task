# frozen_string_literal: true

require 'test_helper'

class DeleteStateMachineDeployerTest < ActionDispatch::IntegrationTest
  def setup
    @account_id = '123'
    @region = 'us-east-1'
    create_account(
      VALID_SOR_ARN,
      'My Tenant Account',
      'TENANT',
      @account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      [@region]
    )

    @execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployer_name = 'config_deployer'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": deployer_name,
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution VALID_SOR_ARN, @account_id, @execution_arn, @region, start_time, status, type, deployers, configuration_document
  end

  test 'should delete state machine execution' do
    response = delete_state_machine_execution VALID_SOR_ARN, @execution_arn
    assert_equal @execution_arn, response['data']['deleteStateMachineExecution']['arn']

    response = get_account_details(VALID_SOR_ARN, @account_id)
    assert_equal 0, response['data']['accounts'][0]['baseline'].length
  end

  test 'should deny update if not admin' do
    arn = 'arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/unit-test'
    response = delete_state_machine_execution arn, @execution_arn
    assert_equal 'Not authorized to perform deleteStateMachineExecution mutation', response['errors'][0]['message']

    response = get_account_details(VALID_SOR_ARN, @account_id)
    assert_equal 1, response['data']['accounts'][0]['baseline'].length
  end
end
