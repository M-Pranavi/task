# frozen_string_literal: true

require 'test_helper'

class SetApolloFoundationTest < ActionDispatch::IntegrationTest
  test 'should return null when no apollo logging configuration is set' do
    response = get_apollo_details VALID_SOR_ARN
    assert_nil response['data']['foundation']
  end

  test 'should deny non admins' do
    account_id = '12345'
    logging_iam_role = 'apollo-iam-role'

    response = mutate_apollo_foundation INVALID_ARN, account_id, logging_iam_role

    assert_equal 'Not authorized to perform set_apollo_foundation mutation', response['errors'][0]['message']
  end

  test 'should create new foundation if it does not exist' do
    account_id = '12345'
    logging_iam_role = 'apollo-iam-role'

    response = mutate_apollo_foundation VALID_SOR_ARN, account_id, logging_iam_role
    assert_equal account_id, response['data']['setApolloFoundation']['apollo']['logging']['accountId']
    assert_equal logging_iam_role, response['data']['setApolloFoundation']['apollo']['logging']['loggingIamRole']

    # Verify data was persisted
    response = get_apollo_details VALID_SOR_ARN
    assert_equal account_id, response['data']['foundation']['apollo']['logging']['accountId']
    assert_equal logging_iam_role, response['data']['foundation']['apollo']['logging']['loggingIamRole']
  end

  test 'should update existing apollo logging configuration' do
    # First create initial configuration
    initial_account_id = '12345'
    initial_logging_iam_role = 'initial-apollo-iam-role'

    response = mutate_apollo_foundation VALID_SOR_ARN, initial_account_id, initial_logging_iam_role
    assert_equal initial_account_id, response['data']['setApolloFoundation']['apollo']['logging']['accountId']
    assert_equal initial_logging_iam_role, response['data']['setApolloFoundation']['apollo']['logging']['loggingIamRole']

    # Now update with new values
    updated_account_id = '67890'
    updated_logging_iam_role = 'updated-apollo-iam-role'

    response = mutate_apollo_foundation VALID_SOR_ARN, updated_account_id, updated_logging_iam_role
    assert_equal updated_account_id, response['data']['setApolloFoundation']['apollo']['logging']['accountId']
    assert_equal updated_logging_iam_role, response['data']['setApolloFoundation']['apollo']['logging']['loggingIamRole']

    # Verify data was persisted with the updated values
    response = get_apollo_details VALID_SOR_ARN
    assert_equal updated_account_id, response['data']['foundation']['apollo']['logging']['accountId']
    assert_equal updated_logging_iam_role, response['data']['foundation']['apollo']['logging']['loggingIamRole']
  end

  test 'should allow update with null logging_iam_role' do
    account_id = '12345'
    logging_iam_role = nil

    response = mutate_apollo_foundation VALID_SOR_ARN, account_id, logging_iam_role
    assert_equal account_id, response['data']['setApolloFoundation']['apollo']['logging']['accountId']
    assert_nil response['data']['setApolloFoundation']['apollo']['logging']['loggingIamRole']

    # Verify data was persisted
    response = get_apollo_details VALID_SOR_ARN
    assert_equal account_id, response['data']['foundation']['apollo']['logging']['accountId']
    assert_nil response['data']['foundation']['apollo']['logging']['loggingIamRole']
  end
end
