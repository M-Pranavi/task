# frozen_string_literal: true

require 'test_helper'

class CreateAccountRegionValidationTest < ActionDispatch::IntegrationTest
  test 'should allow Apollo BU to use all 7 regions' do
    apollo_regions = %w[us-east-1 us-east-2 us-west-2 eu-central-1 ap-southeast-2 ap-south-1 ap-southeast-1]

    response = create_account(
      VALID_SOR_ARN,
      'Apollo Test Account',
      'TENANT',
      '123456789',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'apollo',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      apollo_regions
    )

    assert_nil response['errors']
    assert_equal apollo_regions.sort, response['data']['createAccount']['regions'].sort
  end

  test 'should allow Apollo BU to use Apollo-only regions' do
    apollo_only_regions = %w[ap-south-1 ap-southeast-1]

    response = create_account(
      VALID_SOR_ARN,
      'Apollo Test Account',
      'TENANT',
      '123456790',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'apollo',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      apollo_only_regions
    )

    assert_nil response['errors']
    assert_equal apollo_only_regions.sort, response['data']['createAccount']['regions'].sort
  end

  test 'should allow Braintree BU to use original 5 regions' do
    braintree_regions = %w[us-east-1 us-east-2 us-west-2 eu-central-1 ap-southeast-2]

    response = create_account(
      VALID_SOR_ARN,
      'Braintree Test Account',
      'TENANT',
      '123456791',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'braintree',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      braintree_regions
    )

    assert_nil response['errors']
    assert_equal braintree_regions.sort, response['data']['createAccount']['regions'].sort
  end

  test 'should reject Apollo-only regions for Braintree BU' do
    response = create_account(
      VALID_SOR_ARN,
      'Braintree Test Account',
      'TENANT',
      '123456792',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'braintree',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['ap-south-1']
    )

    assert_not_nil response['errors']
    assert_includes response['errors'][0]['message'], 'not allowed for business unit'
  end

  test 'should reject mixed regions with Apollo-only for Braintree BU' do
    mixed_regions = %w[us-east-1 ap-south-1]

    response = create_account(
      VALID_SOR_ARN,
      'Braintree Test Account',
      'TENANT',
      '123456793',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'braintree',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      mixed_regions
    )

    assert_not_nil response['errors']
    assert_includes response['errors'][0]['message'], 'not allowed for business unit'
  end

  test 'should default to Braintree regions validation for other business units' do
    response = create_account(
      VALID_SOR_ARN,
      'Chargehound',
      'TENANT',
      '123456794',
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'unknown',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['ap-south-1']
    )

    assert_not_nil response['errors']
    assert_includes response['errors'][0]['message'], 'not allowed for business unit'
  end

  private

  def create_account(arn, name, type, account_id, environment, owner, application_name,
                     distribution_list, slack_service_channel, business_unit, data_classification,
                     business_criticality, connectivity, baseline_change_approval_required,
                     provision_change_approval_required, regions)
    query_string = <<-GRAPHQL
      mutation($name: String!, $type: AccountType!, $accountId: String!, $environment: Environment!, $owner: String!, $applicationName: String!, $distributionList: String!, $slackChannel: String!, $businessUnit: String!, $dataClassification: DataClassification!, $businessCriticality: BusinessCriticality!, $connectivity: AccountConnectivity!, $baselineChangeApprovalRequired: Boolean!, $provisionChangeApprovalRequired: Boolean!, $regions: [Region!]!) {
        createAccount(
          name: $name,
          type: $type,
          accountId: $accountId,
          environment: $environment,
          owner: $owner,
          applicationName: $applicationName,
          distributionList: $distributionList,
          slackServiceChannel: $slackChannel,
          businessUnit: $businessUnit,
          dataClassification: $dataClassification,
          businessCriticality: $businessCriticality,
          connectivity: $connectivity,
          baselineChangeApprovalRequired: $baselineChangeApprovalRequired,
          provisionChangeApprovalRequired: $provisionChangeApprovalRequired,
          regions: $regions
        ) {
          id
          name
          businessUnit
          regions
        }
      }
    GRAPHQL

    post '/graphql',
         params: {
           query: query_string,
           variables: {
             name:,
             type:,
             accountId: account_id,
             environment:,
             owner:,
             applicationName: application_name,
             distributionList: distribution_list,
             slackChannel: slack_service_channel,
             businessUnit: business_unit,
             dataClassification: data_classification,
             businessCriticality: business_criticality,
             connectivity:,
             baselineChangeApprovalRequired: baseline_change_approval_required,
             provisionChangeApprovalRequired: provision_change_approval_required,
             regions:
           }
         },
         headers: { "User-Arn": arn },
         as: :json

    JSON.parse(@response.body)
  end
end
