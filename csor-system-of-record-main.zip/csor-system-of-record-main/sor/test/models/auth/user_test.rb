# frozen_string_literal: true

require 'test_helper'

class UserTest < ActiveSupport::TestCase
  test 'should handle malformed arn' do
    user = Auth::User.new('test-arn')

    assert_not_nil user
    assert_not_empty user.to_s
    assert_equal 'unauthorized', user.to_s
  end

  test 'should handle nil arn' do
    user = Auth::User.new(nil)

    assert_not_nil user
    assert_not_empty user.to_s
    assert_equal 'unauthorized', user.to_s
  end

  test 'should handle missing arn' do
    user = Auth::User.new('')

    assert_not_nil user
    assert_not_empty user.to_s
    assert_equal 'unauthorized', user.to_s
  end

  test 'should handle missing role_name' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role//davcarroll')

    assert_not_nil user
    assert_not_empty user.to_s
    assert_equal 'unauthorized', user.to_s
  end

  test 'should handle missing session' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assumed_scope_role_root/')

    assert_not_nil user
    assert_not_empty user.to_s
    assert_equal 'unauthorized', user.to_s
  end

  test 'should handle missing account' do
    user = Auth::User.new('arn:aws:sts:::assumed-role/assumed_scope_role_root/davcarroll')

    assert_not_nil user
    assert_not_empty user.to_s
    assert_equal 'unauthorized', user.to_s
  end

  test 'should create admin user' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_root/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s
  end

  test 'should create admin user with base role' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_base/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s
  end

  test 'should not create admin for non-admin account' do
    user = Auth::User.new('arn:aws:sts::12345:assumed-role/assume_scoped_role_root/davcarroll')

    assert_not user.admin?
    assert_equal 'unauthorized-davcarroll', user.to_s
  end

  test 'should not create admin for non-admin account with base role' do
    user = Auth::User.new('arn:aws:sts::12345:assumed-role/assume_scoped_role_base/davcarroll')

    assert_not user.admin?
    assert_equal 'unauthorized-davcarroll', user.to_s
  end

  test 'should deny non-orchestration roles' do
    user1 = Auth::User.new('arn:aws:sts::56789:assumed-role/test_deployer_role_baseline/davcarroll')

    assert_not_nil user1
    assert_not_empty user1.to_s
    assert_equal 'unauthorized-davcarroll', user1.to_s

    user2 = Auth::User.new('arn:aws:sts::56789:assumed-role/request-submitter-baseline-role/davcarroll')

    assert_not_nil user2
    assert_not_empty user2.to_s
    assert_equal 'unauthorized-davcarroll', user2.to_s
  end

  test 'should aggregate deployer roles' do
    user1 = Auth::User.new('arn:aws:sts::5678:assumed-role/test_deployer_role_baseline/davcarroll')

    assert_not user1.admin?
    assert_equal 'deployer-test-davcarroll', user1.to_s

    user2 = Auth::User.new('arn:aws:sts::5678:assumed-role/test_deployer_role_provision/davcarroll')

    assert_not user2.admin?
    assert_equal 'deployer-test-davcarroll', user2.to_s
  end

  test 'should parse request submitters' do
    user1 = Auth::User.new('arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/davcarroll')

    assert_not user1.admin?
    assert_equal 'request_submitter_baseline-davcarroll', user1.to_s

    user2 = Auth::User.new('arn:aws:sts::5678:assumed-role/request-submitter-provision-role/davcarroll')

    assert_not user2.admin?
    assert_equal 'request_submitter_provision-davcarroll', user2.to_s
  end

  test 'should parse execution reporters' do
    user1 = Auth::User.new('arn:aws:sts::5678:assumed-role/execution-reporter-baseline-role/davcarroll')

    assert_not user1.admin?
    assert_equal 'execution_reporter_baseline-davcarroll', user1.to_s

    user2 = Auth::User.new('arn:aws:sts::5678:assumed-role/execution-reporter-provision-role/davcarroll')

    assert_not user2.admin?
    assert_equal 'execution_reporter_provision-davcarroll', user2.to_s
  end

  test 'should handle single authorized user' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_root/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s

    assert user.authorized?(Auth::AuthenticatedUser::ADMIN)
  end

  test 'should handle single authorized user with base role' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_base/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s

    assert user.authorized?(Auth::AuthenticatedUser::ADMIN)
  end

  test 'should handle list of authorized user' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_root/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s

    assert user.authorized?([Auth::AuthenticatedUser::ADMIN, Auth::AuthenticatedUser::DEPLOYER])

    user2 = Auth::User.new('arn:aws:sts::5678:assumed-role/test_deployer_role_provision/davcarroll')

    assert_not user2.admin?
    assert_equal 'deployer-test-davcarroll', user2.to_s
    assert user2.authorized?([Auth::AuthenticatedUser::ADMIN, Auth::AuthenticatedUser::DEPLOYER])
  end

  test 'should handle list of authorized user with base role' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_base/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s

    assert user.authorized?([Auth::AuthenticatedUser::ADMIN, Auth::AuthenticatedUser::DEPLOYER])

    user2 = Auth::User.new('arn:aws:sts::5678:assumed-role/test_deployer_role_provision/davcarroll')

    assert_not user2.admin?
    assert_equal 'deployer-test-davcarroll', user2.to_s
    assert user2.authorized?([Auth::AuthenticatedUser::ADMIN, Auth::AuthenticatedUser::DEPLOYER])
  end

  test 'should deny unauthorized user' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_root/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s

    assert_not user.authorized?(Auth::AuthenticatedUser::DEPLOYER)

    user2 = Auth::User.new('arn:aws:sts::5678:assumed-role/test_deployer_role_provision/davcarroll')

    assert_not user2.admin?
    assert_equal 'deployer-test-davcarroll', user2.to_s
    assert_not user2.authorized?([Auth::AuthenticatedUser::ADMIN, Auth::AuthenticatedUser::BASELINE_REQUEST_SUBMITTER])
  end

  test 'should deny unauthorized user with base role' do
    user = Auth::User.new('arn:aws:sts::1234:assumed-role/assume_scoped_role_base/davcarroll')

    assert user.admin?
    assert_equal 'admin-davcarroll', user.to_s

    assert_not user.authorized?(Auth::AuthenticatedUser::DEPLOYER)

    user2 = Auth::User.new('arn:aws:sts::5678:assumed-role/test_deployer_role_provision/davcarroll')

    assert_not user2.admin?
    assert_equal 'deployer-test-davcarroll', user2.to_s
    assert_not user2.authorized?([Auth::AuthenticatedUser::ADMIN, Auth::AuthenticatedUser::BASELINE_REQUEST_SUBMITTER])
  end
end
