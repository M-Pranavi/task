# frozen_string_literal: true

require 'test_helper'
require 'json'

class ErrorHandlerTest < ActionDispatch::IntegrationTest
  valid_user_arn = 'arn:aws:sts::1234:assumed-role/assume_scoped_role_root/unit-test'

  test 'Record Not Unique test' do
    account_id = 'unique_account_number'
    account = create_account(
      valid_user_arn,
      'Logging Account',
      'FOUNDATION',
      account_id,
      'DEV',
      'test-owner',
      'test-app',
      'test-dl',
      'test-channel',
      'test-bu',
      'CLASS_1',
      'STANDARD',
      'INTERNAL',
      true,
      false,
      ['us-east-1']
    )
    assert_not_nil account
    assert_equal account_id, account['data']['createAccount']['id']

    baseline_user_arn = 'arn:aws:sts::5678:assumed-role/request-submitter-baseline-role/unit-test'
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:6c0854f0-7602-4505-b8f1-1bf8b11c45c7'
    region = 'us-east-1'
    start_time = '2024-05-23T13:37:23Z'
    status = 'IN_PROGRESS'
    type = 'BASELINE'
    deployers = [
      {
        "name": 'base_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      },
      {
        "name": 'config_deployer',
        "version": 'Unknown',
        "status": 'Not_Started',
        "repository": nil,
        "snowTicket": nil,
        "outputs": {},
        "resources": {}
      }
    ]
    configuration_document = { a: 'b' }
    create_state_machine_execution(baseline_user_arn,
                                   account_id,
                                   execution_arn,
                                   region,
                                   start_time,
                                   status,
                                   type,
                                   deployers,
                                   configuration_document)
    error = assert_raise(ActiveRecord::RecordNotUnique) do
      create_state_machine_execution(baseline_user_arn,
                                     account_id,
                                     execution_arn,
                                     region,
                                     start_time,
                                     status,
                                     type,
                                     deployers,
                                     configuration_document)
    end

    assert_includes error.message, 'Record already exists'
  end

  test 'account does not exist' do
    error = assert_raise(ActiveRecord::RecordNotFound) do
      delete_account(valid_user_arn, '123456789101')
    end

    assert_includes error.message, 'Record Not Found'
  end

  test 'state_machine_execution does not exist' do
    execution_arn = 'arn:aws:states:us-east-2:614751254790:execution:csor-orchestration-baseline:does-not-exist'
    deployer_name = 'config_deployer'
    deployer_status = 'Failed'
    version = '0.0.1'
    outputs = {
      'foo' => 'bar'
    }
    resources = {
      'r1' => 'id1'
    }
    snow_ticket = 'my-ticket'
    failure_reason = 'random failure'

    error = assert_raise(ActiveRecord::RecordNotFound) do
      update_state_machine_deployer(
        valid_user_arn,
        execution_arn,
        deployer_name,
        deployer_status,
        version,
        outputs,
        resources,
        snow_ticket,
        failure_reason
      )
    end
    assert_includes error.message, 'Record Not Found'
  end
end
