# frozen_string_literal: true

require 'test_helper'

class TypeIntrospectionTest < ActionDispatch::IntegrationTest
  test 'instrospect types' do
    types = [
      {
        "name": 'Account',
        "kind": 'OBJECT'
      },
      {
        "name": 'AccountConnectivity',
        "kind": 'ENUM'
      },
      {
        "name": 'AccountType',
        "kind": 'ENUM'
      },
      {
        "name": 'Apollo',
        "kind": 'OBJECT'
      },
      {
        "name": 'ApolloLogging',
        "kind": 'OBJECT'
      },
      {
        "name": 'BaselineBase',
        "kind": 'OBJECT'
      },
      {
        "name": 'BaselineBaseInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'Boolean',
        "kind": 'SCALAR'
      },
      {
        "name": 'Braintree',
        "kind": 'OBJECT'
      },
      {
        "name": 'BraintreeCosmos',
        "kind": 'OBJECT'
      },
      {
        "name": 'BraintreeCosmosInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'BusinessCriticality',
        "kind": 'ENUM'
      },
      {
        "name": 'Csor',
        "kind": 'OBJECT'
      },
      {
        "name": 'CsorBaseline',
        "kind": 'OBJECT'
      },
      {
        "name": 'CsorBaselineInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'CsorEnvironment',
        "kind": 'SCALAR'
      },
      {
        "name": 'CsorProvision',
        "kind": 'OBJECT'
      },
      {
        "name": 'CsorProvisionInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'DataClassification',
        "kind": 'ENUM'
      },
      {
        "name": 'Deployer',
        "kind": 'OBJECT'
      },
      {
        "name": 'DeployerInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'DeployerStatus',
        "kind": 'ENUM'
      },
      {
        "name": 'Environment',
        "kind": 'ENUM'
      },
      {
        "name": 'ExecutionStatus',
        "kind": 'OBJECT'
      },
      {
        "name": 'Fcd',
        "kind": 'OBJECT'
      },
      {
        "name": 'Foundation',
        "kind": 'OBJECT'
      },
      {
        "name": 'FoundationLogging',
        "kind": 'OBJECT'
      },
      {
        "name": 'FoundationLoggingOamLinks',
        "kind": 'OBJECT'
      },
      {
        "name": 'FoundationLoggingOamLinksInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'FoundationNetwork',
        "kind": 'OBJECT'
      },
      {
        "name": 'ID',
        "kind": 'SCALAR'
      },
      {
        "name": 'ISO8601DateTime',
        "kind": 'SCALAR'
      },
      {
        "name": 'JSON',
        "kind": 'SCALAR'
      },
      {
        "name": 'Mutation',
        "kind": 'OBJECT'
      },
      {
        "name": 'OrchestrationStatus',
        "kind": 'ENUM'
      },
      {
        "name": 'ProvisionBase',
        "kind": 'OBJECT'
      },
      {
        "name": 'ProvisionBaseInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'Query',
        "kind": 'OBJECT'
      },
      {
        "name": 'Region',
        "kind": 'SCALAR'
      },
      {
        "name": 'Stackset',
        "kind": 'OBJECT'
      },
      {
        "name": 'StacksetInput',
        "kind": 'INPUT_OBJECT'
      },
      {
        "name": 'StateMachine',
        "kind": 'ENUM'
      },
      {
        "name": 'StateMachineExecution',
        "kind": 'OBJECT'
      },
      {
        "name": 'StateMachineExecutionSummary',
        "kind": 'OBJECT'
      },
      {
        "name": 'String',
        "kind": 'SCALAR'
      },
      {
        "name": '__Directive',
        "kind": 'OBJECT'
      },
      {
        "name": '__DirectiveLocation',
        "kind": 'ENUM'
      },
      {
        "name": '__EnumValue',
        "kind": 'OBJECT'
      },
      {
        "name": '__Field',
        "kind": 'OBJECT'
      },
      {
        "name": '__InputValue',
        "kind": 'OBJECT'
      },
      {
        "name": '__Schema',
        "kind": 'OBJECT'
      },
      {
        "name": '__Type',
        "kind": 'OBJECT'
      },
      {
        "name": '__TypeKind',
        "kind": 'ENUM'
      }
    ]

    query_string = <<-GRAPHQL
        {
            __schema {
                types {
                    name
                    kind
                }
            }
        }
    GRAPHQL
    post '/graphql',
         params: { query: query_string },
         as: :json
    response = JSON.parse(@response.body)
    types_response = response['data']['__schema']['types']
    types_response.each_with_index do |type_response, index|
      assert_equal types[index][:name], type_response['name']
      assert_equal types[index][:kind], type_response['kind']
    end
  end
end
