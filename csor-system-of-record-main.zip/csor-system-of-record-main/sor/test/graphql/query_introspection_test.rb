# frozen_string_literal: true

require 'test_helper'

class QueryTypeIntrospectionTest < ActionDispatch::IntegrationTest
  valid_user_arn = 'arn:aws:sts::12345:assumed-role/request-submitter-baseline-role/unit-test'

  test 'introspect query types' do
    query_types = {
      "accountExecutions": {
        "name": 'accountExecutions',
        "description": nil,
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "accounts": {
        "name": 'accounts',
        "description": nil,
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "fcd": {
        "name": 'fcd',
        "description": nil,
        "type": [
          {
            "name": 'Fcd',
            "kind": 'OBJECT'
          }
        ]
      },
      "foundation": {
        "name": 'foundation',
        "description": nil,
        "type": [
          {
            "name": 'Foundation',
            "kind": 'OBJECT'
          }
        ]
      },
      "statusByExecution": {
        "name": 'statusByExecution',
        "description": nil,
        "type": [
          {
            "name": 'ExecutionStatus',
            "kind": 'OBJECT'
          }
        ]
      }
    }

    response = get_query_types valid_user_arn
    query_types_response = response['data']['__schema']['queryType']['fields']
    assert_not_nil query_types_response

    query_types_response.each do |query_type_response|
      case query_type_response['name']
      when 'accountExecutions'
        assert_equal query_types[:accountExecutions][:name], query_type_response['name']
        assert_nil query_types[:accountExecutions][:description], query_type_response['description']
        assert_nil query_types[:accountExecutions][:type][0][:name], query_type_response['type']['name']
        assert_equal query_types[:accountExecutions][:type][0][:kind], query_type_response['type']['kind']
      when 'accounts'
        assert_equal query_types[:accounts][:name], query_type_response['name']
        assert_nil query_types[:accounts][:description], query_type_response['description']
        assert_nil query_types[:accounts][:type][0][:name], query_type_response['type']['name']
        assert_equal query_types[:accounts][:type][0][:kind], query_type_response['type']['kind']
      when 'fcd'
        assert_equal query_types[:fcd][:name], query_type_response['name']
        assert_nil query_types[:fcd][:description], query_type_response['description']
        assert_equal query_types[:fcd][:type][0][:name], query_type_response['type']['name']
        assert_equal query_types[:fcd][:type][0][:kind], query_type_response['type']['kind']
      when 'foundation'
        assert_equal query_types[:foundation][:name], query_type_response['name']
        assert_nil query_types[:foundation][:description], query_type_response['description']
        assert_equal query_types[:foundation][:type][0][:name], query_type_response['type']['name']
        assert_equal query_types[:foundation][:type][0][:kind], query_type_response['type']['kind']
      when 'statusByExecution'
        assert_equal query_types[:statusByExecution][:name], query_type_response['name']
        assert_nil query_types[:statusByExecution][:description], query_type_response['description']
        assert_equal query_types[:statusByExecution][:type][0][:name], query_type_response['type']['name']
        assert_equal query_types[:statusByExecution][:type][0][:kind], query_type_response['type']['kind']
      else
        raise "Encountered a different queryType! Available query_types: #{query_types.keys}"
      end
    end
  end
end
