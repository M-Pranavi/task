# frozen_string_literal: true

require 'test_helper'

class DeployerInputFieldsIntrospectionTest < ActionDispatch::IntegrationTest
  valid_user_arn = 'arn:aws:sts::12345:assumed-role/request-submitter-baseline-role/unit-test'

  test 'instrospect DeployerInputFields' do
    deployer_input_fields = {
      "failureReason": {
        "name": 'failureReason',
        "description": 'Reason for the deployers failure',
        "defaultValue": nil
      },
      "name": {
        "name": 'name',
        "description": 'Name of the deployer',
        "defaultValue": nil
      },
      "version": {
        "name": 'version',
        "description": 'Version of the deployer',
        "defaultValue": nil
      },
      "status": {
        "name": 'status',
        "description": 'Status of the deployer',
        "defaultValue": nil
      },
      "repository": {
        "name": 'repository',
        "description": 'GitHub Repository url for the deployer',
        "defaultValue": nil
      },
      "outputs": {
        "name": 'outputs',
        "description": 'Terraform Output in JSON format',
        "defaultValue": nil
      },
      "resources": {
        "name": 'resources',
        "description": 'Terraform Resources in JSON format',
        "defaultValue": nil
      },
      "snowTicket": {
        "name": 'snowTicket',
        "description": 'Snow ticket url',
        "defaultValue": nil
      }
    }

    input_object = 'DeployerInput'
    response = get_input_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'INPUT_OBJECT'

    deployer_input_fields_response = response['data']['__type']['inputFields']
    assert_not_nil deployer_input_fields_response

    deployer_input_fields_response.each do |input_field_response|
      case input_field_response['name']
      when 'failureReason'
        assert_equal deployer_input_fields[:failureReason][:name], input_field_response['name']
        assert_equal deployer_input_fields[:failureReason][:description], input_field_response['description']
        assert_nil deployer_input_fields[:failureReason][:defaultValue], input_field_response['defaultValue']
      when 'name'
        assert_equal deployer_input_fields[:name][:name], input_field_response['name']
        assert_equal deployer_input_fields[:name][:description], input_field_response['description']
        assert_nil deployer_input_fields[:name][:defaultValue], input_field_response['defaultValue']
      when 'version'
        assert_equal deployer_input_fields[:version][:name], input_field_response['name']
        assert_equal deployer_input_fields[:version][:description], input_field_response['description']
        assert_nil deployer_input_fields[:version][:defaultValue], input_field_response['defaultValue']
      when 'status'
        assert_equal deployer_input_fields[:status][:name], input_field_response['name']
        assert_equal deployer_input_fields[:status][:description], input_field_response['description']
        assert_nil deployer_input_fields[:status][:defaultValue], input_field_response['defaultValue']
      when 'repository'
        assert_equal deployer_input_fields[:repository][:name], input_field_response['name']
        assert_equal deployer_input_fields[:repository][:description], input_field_response['description']
        assert_nil deployer_input_fields[:repository][:defaultValue], input_field_response['defaultValue']
      when 'outputs'
        assert_equal deployer_input_fields[:outputs][:name], input_field_response['name']
        assert_equal deployer_input_fields[:outputs][:description], input_field_response['description']
        assert_nil deployer_input_fields[:outputs][:defaultValue], input_field_response['defaultValue']
      when 'resources'
        assert_equal deployer_input_fields[:resources][:name], input_field_response['name']
        assert_equal deployer_input_fields[:resources][:description], input_field_response['description']
        assert_nil deployer_input_fields[:resources][:defaultValue], input_field_response['defaultValue']
      when 'snowTicket'
        assert_equal deployer_input_fields[:snowTicket][:name], input_field_response['name']
        assert_equal deployer_input_fields[:snowTicket][:description], input_field_response['description']
        assert_nil deployer_input_fields[:snowTicket][:defaultValue], input_field_response['defaultValue']
      else
        raise "Encountered a different inputField! Available inputFields: #{deployer_input_fields.keys}"
      end
    end
  end
end
