# frozen_string_literal: true

require 'test_helper'

class TypeIntrospectionTest < ActionDispatch::IntegrationTest
  valid_user_arn = 'arn:aws:sts::12345:assumed-role/request-submitter-baseline-role/unit-test'

  test 'instrospect Account' do
    account_fields = [
      {
        "name": 'accountType'
      },
      {
        "name": 'appInfra'
      },
      {
        "name": 'applicationName'
      },
      {
        "name": 'baseline'
      },
      {
        "name": 'baselineChangeApprovalRequired'
      },
      {
        "name": 'businessCriticality'
      },
      {
        "name": 'businessUnit'
      },
      {
        "name": 'connectivity'
      },
      {
        "name": 'dataClassification'
      },
      {
        "name": 'distributionList'
      },
      {
        "name": 'environment'
      },
      {
        "name": 'id'
      },
      {
        "name": 'name'
      },
      {
        "name": 'owner'
      },
      {
        "name": 'provisionChangeApprovalRequired'
      },
      {
        "name": 'regions'
      },
      {
        "name": 'slackServiceChannel'
      }
    ]

    input_object = 'Account'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    account_fields_response = response['data']['__type']['fields']
    assert_not_nil account_fields_response

    account_fields_response.each_with_index do |field, index|
      assert_equal field['name'], account_fields[index][:name]
    end
  end

  test 'instrospect Deployer' do
    deployer_fields = [
      {
        "name": 'failureReason'
      },
      {
        "name": 'name'
      },
      {
        "name": 'outputs'
      },
      {
        "name": 'repository'
      },
      {
        "name": 'resources'
      },
      {
        "name": 'snowTicket'
      },
      {
        "name": 'status'
      },
      {
        "name": 'version'
      }
    ]

    input_object = 'Deployer'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    deployer_fields_response = response['data']['__type']['fields']
    assert_not_nil deployer_fields_response

    deployer_fields_response.each_with_index do |field, index|
      assert_equal field['name'], deployer_fields[index][:name]
    end
  end

  test 'instrospect ExecutionStatus' do
    exec_status_fields = [
      {
        "name": 'arn'
      },
      {
        "name": 'configurationDocument'
      },
      {
        "name": 'deployers'
      },
      {
        "name": 'startTime'
      },
      {
        "name": 'stateMachineType'
      },
      {
        "name": 'status'
      }
    ]

    input_object = 'ExecutionStatus'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    exec_status_fields_response = response['data']['__type']['fields']
    assert_not_nil exec_status_fields_response

    exec_status_fields_response.each_with_index do |field, index|
      assert_equal field['name'], exec_status_fields[index][:name]
    end
  end

  test 'instrospect Fcd' do
    fcd_fields = [
      {
        "name": 'configurationDocument'
      },
      {
        "name": 'createdAt'
      }
    ]

    input_object = 'Fcd'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    fcd_fields_response = response['data']['__type']['fields']
    assert_not_nil fcd_fields_response

    fcd_fields_response.each_with_index do |field, index|
      assert_equal field['name'], fcd_fields[index][:name]
    end
  end

  test 'instrospect FoundationLogging' do
    foundation_logging_fields = [
      {
        "name": 'accountId'
      },
      {
        "name": 'cloudtrailSqsQueue'
      },
      {
        "name": 'loggingIamRole'
      },
      {
        "name": 'oamLinks'
      },
      {
        "name": 's3RawBucket'
      },
      {
        "name": 'vpcflowSqsQueue'
      }
    ]

    input_object = 'FoundationLogging'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    foundation_logging_fields_response = response['data']['__type']['fields']
    assert_not_nil foundation_logging_fields_response

    foundation_logging_fields_response.each_with_index do |field, index|
      assert_equal field['name'], foundation_logging_fields[index][:name]
    end
  end

  test 'instrospect FoundationLoggingOamLinks' do
    foundation_oam_links_fields = [
      {
        "name": 'arn'
      },
      {
        "name": 'region'
      }
    ]

    input_object = 'FoundationLoggingOamLinks'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    foundation_oam_links_fields_response = response['data']['__type']['fields']
    assert_not_nil foundation_oam_links_fields_response

    foundation_oam_links_fields_response.each_with_index do |field, index|
      assert_equal field['name'], foundation_oam_links_fields[index][:name]
    end
  end

  test 'instrospect FoundationNetwork' do
    foundation_network_fields = [
      {
        "name": 'accountId'
      },
      {
        "name": 'asmEndpointIps'
      },
      {
        "name": 'autoscalingEndpointIps'
      },
      {
        "name": 'availabilityZonesDsv'
      },
      {
        "name": 'braintreeApiComZoneId'
      },
      {
        "name": 'cloudformationEndpointIps'
      },
      {
        "name": 'dimensionPrivateZoneId'
      },
      {
        "name": 'dynamodbEndpointCidrBlocks'
      },
      {
        "name": 'ec2EndpointIps'
      },
      {
        "name": 'efsEndpointIps'
      },
      {
        "name": 'elasticloadbalancingEndpointIps'
      },
      {
        "name": 'fdfgSftpWhitelistCidrs'
      },
      {
        "name": 'logsEndpointIps'
      },
      {
        "name": 'privateEksSubnetIds'
      },
      {
        "name": 'privateSubnetIds'
      },
      {
        "name": 'privateZoneId'
      },
      {
        "name": 'publicAccessCidrs'
      },
      {
        "name": 'publicSubnetIds'
      },
      {
        "name": 'region'
      },
      {
        "name": 's3EndpointCidrBlocks'
      },
      {
        "name": 'sqsEndpointIps'
      },
      {
        "name": 'stsEndpointIps'
      },
      {
        "name": 'vpcCidr'
      },
      {
        "name": 'vpcCidrAllocation'
      },
      {
        "name": 'vpcDnsAddr'
      },
      {
        "name": 'vpcId'
      }
    ]

    input_object = 'FoundationNetwork'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    foundation_network_fields_response = response['data']['__type']['fields']
    assert_not_nil foundation_network_fields_response

    foundation_network_fields_response.each_with_index do |field, index|
      assert_equal field['name'], foundation_network_fields[index][:name]
    end
  end

  test 'instrospect StateMachineExecution' do
    state_machine_execution_fields = [
      {
        "name": 'arn'
      },
      {
        "name": 'configurationDocument'
      },
      {
        "name": 'deployers'
      },
      {
        "name": 'region'
      },
      {
        "name": 'startTime'
      },
      {
        "name": 'status'
      }
    ]

    input_object = 'StateMachineExecution'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    state_machine_execution_fields_response = response['data']['__type']['fields']
    assert_not_nil state_machine_execution_fields_response

    state_machine_execution_fields_response.each_with_index do |field, index|
      assert_equal field['name'], state_machine_execution_fields[index][:name]
    end
  end

  test 'instrospect StateMachineExecutionSummary' do
    state_machine_exec_summary_fields = [
      {
        "name": 'executions'
      },
      {
        "name": 'lastSuccess'
      },
      {
        "name": 'latest'
      },
      {
        "name": 'region'
      }
    ]

    input_object = 'StateMachineExecutionSummary'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    state_machine_exec_summary_fields_response = response['data']['__type']['fields']
    assert_not_nil state_machine_exec_summary_fields_response

    state_machine_exec_summary_fields_response.each_with_index do |field, index|
      assert_equal field['name'], state_machine_exec_summary_fields[index][:name]
    end
  end

  test 'instrospect Foundation' do
    foundation_fields = [
      {
        "name": 'apollo'
      },
      {
        "name": 'braintree'
      },
      {
        "name": 'csor'
      },
      {
        "name": 'logging'
      },
      {
        "name": 'network'
      }
    ]

    input_object = 'Foundation'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    foundation_fields_response = response['data']['__type']['fields']
    assert_not_nil foundation_fields_response

    foundation_fields_response.each_with_index do |field, index|
      assert_equal field['name'], foundation_fields[index][:name]
    end
  end

  test 'instrospect Braintree' do
    braintree_fields = [
      {
        "name": 'cosmos'
      },
      {
        "name": 'logging'
      },
      {
        "name": 'network'
      }
    ]

    input_object = 'Braintree'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    braintree_fields_response = response['data']['__type']['fields']
    assert_not_nil braintree_fields_response

    braintree_fields_response.each_with_index do |field, index|
      assert_equal field['name'], braintree_fields[index][:name]
    end
  end

  test 'instrospect BraintreeCosmos' do
    braintree_cosmos_fields = [
      {
        "name": 'accountId'
      },
      {
        "name": 'cpairAssumeRole'
      },
      {
        "name": 'environment'
      }
    ]

    input_object = 'BraintreeCosmos'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    braintree_cosmos_fields_response = response['data']['__type']['fields']
    assert_not_nil braintree_cosmos_fields_response

    braintree_cosmos_fields_response.each_with_index do |field, index|
      assert_equal field['name'], braintree_cosmos_fields[index][:name]
    end
  end

  test 'instrospect Csor' do
    csor_fields = [
      {
        "name": 'baseline'
      },
      {
        "name": 'dynamodbGlobalDeployerLockTable'
      },
      {
        "name": 'environment'
      },
      {
        "name": 'orchestrationAccountId'
      },
      {
        "name": 'privateSubnets'
      },
      {
        "name": 'provision'
      },
      {
        "name": 'publicSubnets'
      },
      {
        "name": 'region'
      },
      {
        "name": 'terraformDynamodbLockTable'
      },
      {
        "name": 'terraformStateKey'
      },
      {
        "name": 'vpcId'
      }
    ]

    input_object = 'Csor'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    csor_fields_response = response['data']['__type']['fields']
    assert_not_nil csor_fields_response

    csor_fields_response.each_with_index do |field, index|
      assert_equal field['name'], csor_fields[index][:name]
    end
  end

  test 'instrospect CsorBaseline' do
    csor_baseline_fields = [
      {
        "name": 'deployerArns'
      },
      {
        "name": 'stackset'
      },
      {
        "name": 'terraformPlanBucket'
      },
      {
        "name": 'terraformStateFileBucket'
      }
    ]

    input_object = 'CsorBaseline'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    csor_baseline_fields_response = response['data']['__type']['fields']
    assert_not_nil csor_baseline_fields_response

    csor_baseline_fields_response.each_with_index do |field, index|
      assert_equal field['name'], csor_baseline_fields[index][:name]
    end
  end

  test 'instrospect BaselineBase' do
    baseline_base_fields = [
      {
        "name": 'baseDeployerArn'
      },
      {
        "name": 'cicdDeployerArn'
      },
      {
        "name": 'loggingDeployerArn'
      },
      {
        "name": 'networkDeployerArn'
      },
      {
        "name": 'securityShieldDeployerArn'
      },
      {
        "name": 'stacksetDeployerArn'
      }
    ]

    input_object = 'BaselineBase'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    baseline_base_fields_response = response['data']['__type']['fields']
    assert_not_nil baseline_base_fields_response

    baseline_base_fields_response.each_with_index do |field, index|
      assert_equal field['name'], baseline_base_fields[index][:name]
    end
  end

  test 'instrospect CsorProvision' do
    csor_provision_fields = [
      {
        "name": 'deployerArns'
      },
      {
        "name": 'stackset'
      },
      {
        "name": 'terraformPlanBucket'
      },
      {
        "name": 'terraformStateFileBucket'
      }
    ]

    input_object = 'CsorProvision'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    csor_provision_fields_response = response['data']['__type']['fields']
    assert_not_nil csor_provision_fields_response

    csor_provision_fields_response.each_with_index do |field, index|
      assert_equal field['name'], csor_provision_fields[index][:name]
    end
  end

  test 'instrospect ProvisionBase' do
    provision_base_fields = [
      {
        "name": 'baseDeployerArn'
      },
      {
        "name": 'eksDeployerArn'
      },
      {
        "name": 'kapDeployerArn'
      },
      {
        "name": 'stacksetDeployerArn'
      }
    ]

    input_object = 'ProvisionBase'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    provision_base_fields_response = response['data']['__type']['fields']
    assert_not_nil provision_base_fields_response

    provision_base_fields_response.each_with_index do |field, index|
      assert_equal field['name'], provision_base_fields[index][:name]
    end
  end

  test 'instrospect Stackset' do
    stackset_fields = [
      {
        "name": 'name'
      }
    ]

    input_object = 'Stackset'
    response = get_object_fields valid_user_arn, input_object
    assert_equal response['data']['__type']['kind'], 'OBJECT'

    stackset_fields_response = response['data']['__type']['fields']
    assert_not_nil stackset_fields_response

    stackset_fields_response.each_with_index do |field, index|
      assert_equal field['name'], stackset_fields[index][:name]
    end
  end
end
