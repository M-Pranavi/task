# frozen_string_literal: true

require 'test_helper'

class SchemaValidationTest < Minitest::Test
  def test_schema_is_up_to_date
    current_defn = SorSchema.to_definition
    printout_defn = File.read(Rails.root.join('app/graphql/schema.graphql'))
    assert_equal(current_defn, printout_defn, 'GraphQL Schema is out of date. Please run `bundle exec rake graphql:schema:dump`')
  end
end
