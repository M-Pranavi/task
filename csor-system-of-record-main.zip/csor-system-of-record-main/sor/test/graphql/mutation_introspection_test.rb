# frozen_string_literal: true

require 'test_helper'

class MutationIntrospectionTest < ActionDispatch::IntegrationTest
  valid_user_arn = 'arn:aws:sts::12345:assumed-role/request-submitter-baseline-role/unit-test'

  test 'introspect mutation types' do
    mutation_types = {
      "createAccount": {
        "name": 'createAccount',
        "description": 'Create a new account',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "createFcd": {
        "name": 'createFcd',
        "description": 'Create a new valid FCD',
        type: [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "createStateMachineExecution": {
        "name": 'createStateMachineExecution',
        "description": 'Create State Machine with Execution details',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "deleteAccount": {
        "name": 'deleteAccount',
        "description": 'Delete account',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "deleteStateMachineExecution": {
        "name": 'deleteStateMachineExecution',
        "description": 'Delete state machine execution',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "setLoggingFoundation": {
        "name": 'setLoggingFoundation',
        "description": nil,
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "deleteNetworkFoundation": {
        "name": 'deleteNetworkFoundation',
        "description": nil,
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "setNetworkFoundation": {
        "name": 'setNetworkFoundation',
        "description": nil,
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "setBaselineFoundation": {
        "name": 'setBaselineFoundation',
        "description": 'Configure CSOR baseline foundation settings',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "setApolloFoundation": {
        "name": 'setApolloFoundation',
        "description": 'Configure Apollo foundation settings',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "setBraintreeFoundation": {
        "name": 'setBraintreeFoundation',
        "description": 'Configure Braintree cosmos foundation settings',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "setProvisionFoundation": {
        "name": 'setProvisionFoundation',
        "description": 'Configure CSOR provision foundation settings',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "updateAccount": {
        "name": 'updateAccount',
        "description": 'Update account with details',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "updateStateMachineDeployer": {
        "name": 'updateStateMachineDeployer',
        "description": 'Update deployer status',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      },
      "updateStateMachineExecution": {
        "name": 'updateStateMachineExecution',
        "description": 'Update the Execution details for the account',
        "type": [
          {
            "name": nil,
            "kind": 'NON_NULL'
          }
        ]
      }
    }

    response = get_mutation_types valid_user_arn
    mutation_types_response = response['data']['__schema']['mutationType']['fields']
    assert_not_nil mutation_types_response

    mutation_types_response.each do |mutation_type_response|
      case mutation_type_response['name']
      when 'createAccount'
        assert_equal mutation_types[:createAccount][:name], mutation_type_response['name']
        assert_equal mutation_types[:createAccount][:description], mutation_type_response['description']
        assert_nil mutation_types[:createAccount][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:createAccount][:type][0][:kind], mutation_type_response['type']['kind']
      when 'createFcd'
        assert_equal mutation_types[:createFcd][:name], mutation_type_response['name']
        assert_equal mutation_types[:createFcd][:description], mutation_type_response['description']
        assert_nil mutation_types[:createFcd][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:createFcd][:type][0][:kind], mutation_type_response['type']['kind']
      when 'createStateMachineExecution'
        assert_equal mutation_types[:createStateMachineExecution][:name], mutation_type_response['name']
        assert_equal mutation_types[:createStateMachineExecution][:description], mutation_type_response['description']
        assert_nil mutation_types[:createStateMachineExecution][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:createStateMachineExecution][:type][0][:kind], mutation_type_response['type']['kind']
      when 'deleteAccount'
        assert_equal mutation_types[:deleteAccount][:name], mutation_type_response['name']
        assert_equal mutation_types[:deleteAccount][:description], mutation_type_response['description']
        assert_nil mutation_types[:deleteAccount][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:deleteAccount][:type][0][:kind], mutation_type_response['type']['kind']
      when 'deleteNetworkFoundation'
        assert_equal mutation_types[:deleteNetworkFoundation][:name], mutation_type_response['name']
        assert_equal mutation_types[:deleteNetworkFoundation][:description], mutation_type_response['description']
        assert_nil mutation_types[:deleteNetworkFoundation][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:deleteNetworkFoundation][:type][0][:kind], mutation_type_response['type']['kind']
      when 'deleteStateMachineExecution'
        assert_equal mutation_types[:deleteStateMachineExecution][:name], mutation_type_response['name']
        assert_equal mutation_types[:deleteStateMachineExecution][:description], mutation_type_response['description']
        assert_nil mutation_types[:deleteStateMachineExecution][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:deleteStateMachineExecution][:type][0][:kind], mutation_type_response['type']['kind']
      when 'setLoggingFoundation'
        assert_equal mutation_types[:setLoggingFoundation][:name], mutation_type_response['name']
        assert_nil mutation_types[:setLoggingFoundation][:description], mutation_type_response['description']
        assert_nil mutation_types[:setLoggingFoundation][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:setLoggingFoundation][:type][0][:kind], mutation_type_response['type']['kind']
      when 'setNetworkFoundation'
        assert_equal mutation_types[:setNetworkFoundation][:name], mutation_type_response['name']
        assert_nil mutation_types[:setNetworkFoundation][:description], mutation_type_response['description']
        assert_nil mutation_types[:setNetworkFoundation][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:setNetworkFoundation][:type][0][:kind], mutation_type_response['type']['kind']
      when 'setBaselineFoundation'
        assert_equal mutation_types[:setBaselineFoundation][:name], mutation_type_response['name']
        assert_equal mutation_types[:setBaselineFoundation][:description], mutation_type_response['description']
        assert_nil mutation_types[:setBaselineFoundation][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:setBaselineFoundation][:type][0][:kind], mutation_type_response['type']['kind']
      when 'setApolloFoundation'
        assert_equal mutation_types[:setApolloFoundation][:name], mutation_type_response['name']
        assert_equal mutation_types[:setApolloFoundation][:description], mutation_type_response['description']
        assert_nil mutation_types[:setApolloFoundation][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:setApolloFoundation][:type][0][:kind], mutation_type_response['type']['kind']
      when 'setBraintreeFoundation'
        assert_equal mutation_types[:setBraintreeFoundation][:name], mutation_type_response['name']
        assert_equal mutation_types[:setBraintreeFoundation][:description], mutation_type_response['description']
        assert_nil mutation_types[:setBraintreeFoundation][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:setBraintreeFoundation][:type][0][:kind], mutation_type_response['type']['kind']
      when 'setProvisionFoundation'
        assert_equal mutation_types[:setProvisionFoundation][:name], mutation_type_response['name']
        assert_equal mutation_types[:setProvisionFoundation][:description], mutation_type_response['description']
        assert_nil mutation_types[:setProvisionFoundation][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:setProvisionFoundation][:type][0][:kind], mutation_type_response['type']['kind']
      when 'updateAccount'
        assert_equal mutation_types[:updateAccount][:name], mutation_type_response['name']
        assert_equal mutation_types[:updateAccount][:description], mutation_type_response['description']
        assert_nil mutation_types[:updateAccount][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:updateAccount][:type][0][:kind], mutation_type_response['type']['kind']
      when 'updateStateMachineDeployer'
        assert_equal mutation_types[:updateStateMachineDeployer][:name], mutation_type_response['name']
        assert_equal mutation_types[:updateStateMachineDeployer][:description], mutation_type_response['description']
        assert_nil mutation_types[:updateStateMachineDeployer][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:updateStateMachineDeployer][:type][0][:kind], mutation_type_response['type']['kind']
      when 'updateStateMachineExecution'
        assert_equal mutation_types[:updateStateMachineExecution][:name], mutation_type_response['name']
        assert_equal mutation_types[:updateStateMachineExecution][:description], mutation_type_response['description']
        assert_nil mutation_types[:updateStateMachineExecution][:type][0][:name], mutation_type_response['type']['name']
        assert_equal mutation_types[:updateStateMachineExecution][:type][0][:kind], mutation_type_response['type']['kind']
      else
        raise "Encountered a different mutationType! Available mutation_types: #{mutation_types.keys}"
      end
    end
  end
end
