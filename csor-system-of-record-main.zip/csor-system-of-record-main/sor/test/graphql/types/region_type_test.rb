# frozen_string_literal: true

require 'test_helper'

class RegionTypeTest < ActiveSupport::TestCase
  test 'should validate Braintree regions correctly' do
    braintree_regions = %w[us-east-1 us-east-2 us-west-2 eu-central-1 ap-southeast-2]

    braintree_regions.each do |region|
      assert_nothing_raised do
        Types::RegionType.validate_regions_for_business_unit([region], 'braintree')
      end
    end
  end

  test 'should validate Apollo regions correctly' do
    apollo_regions = %w[us-east-1 us-east-2 us-west-2 eu-central-1 ap-southeast-2 ap-south-1 ap-southeast-1]

    apollo_regions.each do |region|
      assert_nothing_raised do
        Types::RegionType.validate_regions_for_business_unit([region], 'apollo')
      end
    end
  end

  test 'should reject Apollo-only regions for Braintree' do
    apollo_only_regions = %w[ap-south-1 ap-southeast-1]

    apollo_only_regions.each do |region|
      assert_raises(GraphQL::CoercionError) do
        Types::RegionType.validate_regions_for_business_unit([region], 'braintree')
      end
    end
  end

  test 'should accept Apollo-only regions for Apollo' do
    apollo_only_regions = %w[ap-south-1 ap-southeast-1]

    apollo_only_regions.each do |region|
      assert_nothing_raised do
        Types::RegionType.validate_regions_for_business_unit([region], 'apollo')
      end
    end
  end

  test 'should default to Braintree regions for unknown business unit' do
    # Should accept Braintree regions
    assert_nothing_raised do
      Types::RegionType.validate_regions_for_business_unit(['us-east-1'], 'unknown')
    end

    # Should reject Apollo-only regions
    assert_raises(GraphQL::CoercionError) do
      Types::RegionType.validate_regions_for_business_unit(['ap-south-1'], 'unknown')
    end
  end

  test 'should default to Braintree regions for nil business unit' do
    # Should accept Braintree regions
    assert_nothing_raised do
      Types::RegionType.validate_regions_for_business_unit(['us-east-1'], nil)
    end

    # Should reject Apollo-only regions
    assert_raises(GraphQL::CoercionError) do
      Types::RegionType.validate_regions_for_business_unit(['ap-south-1'], nil)
    end
  end

  test 'should handle multiple regions correctly' do
    # All Braintree regions for Braintree BU
    assert_nothing_raised do
      Types::RegionType.validate_regions_for_business_unit(
        %w[us-east-1 us-east-2 us-west-2 eu-central-1 ap-southeast-2],
        'braintree'
      )
    end

    # All Apollo regions for Apollo BU
    assert_nothing_raised do
      Types::RegionType.validate_regions_for_business_unit(
        %w[us-east-1 us-east-2 us-west-2 eu-central-1 ap-southeast-2 ap-south-1 ap-southeast-1],
        'apollo'
      )
    end

    # Mixed regions with Apollo-only for Braintree should fail
    assert_raises(GraphQL::CoercionError) do
      Types::RegionType.validate_regions_for_business_unit(
        %w[us-east-1 ap-south-1],
        'braintree'
      )
    end
  end

  test 'should be case insensitive for business unit' do
    # Test Apollo in different cases
    %w[apollo Apollo APOLLO].each do |bu|
      assert_nothing_raised do
        Types::RegionType.validate_regions_for_business_unit(['ap-south-1'], bu)
      end
    end

    # Test Braintree in different cases
    %w[braintree Braintree BRAINTREE].each do |bu|
      assert_raises(GraphQL::CoercionError) do
        Types::RegionType.validate_regions_for_business_unit(['ap-south-1'], bu)
      end
    end
  end
end
