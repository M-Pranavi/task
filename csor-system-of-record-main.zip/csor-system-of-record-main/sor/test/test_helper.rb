# frozen_string_literal: true

require 'simplecov'

ENV['RAILS_ENV'] ||= 'test'
require_relative '../config/environment'
require 'rails/test_help'

module ActiveSupport
  class TestCase
    # Using parallelize here will break SimpleCov functionality.
    # If we need to parallelize in the future, there is a hack we can try below.
    # https://github.com/simplecov-ruby/simplecov/issues/718#issuecomment-538201587

    # Setup all fixtures in test/fixtures/*.yml for all tests in alphabetical order.
    fixtures :all

    VALID_SOR_ARN = 'arn:aws:sts::1234:assumed-role/assume_scoped_role_root/unit-test'
    VALID_ORCHESTRATION_ARN_PREFIX = 'arn:aws:sts::5678:assumed-role/'
    INVALID_ARN = 'arn:aws:sts::12345678:assumed-role/assumed_scoped_role_root/unit-test'

    # Add more helper methods to be used by all tests here...
    def create_account(
      user_arn,
      name,
      type,
      id,
      environment,
      owner,
      application_name,
      distribution_list,
      slack_service_channel,
      business_unit,
      data_classification,
      business_criticality,
      connectivity,
      baseline_change_approval,
      provision_change_approval,
      regions
    )
      mutation_query = <<-GRAPHQL
      mutation ($n: String!, $t: AccountType!, $i: String!, $e: Environment!, $owner: String!, $app_name: String!, $dl: String!, $channel: String!, $bu: String!, $class: DataClassification!, $crit: BusinessCriticality!, $connectivity: AccountConnectivity!, $b_approval: Boolean!, $p_approval: Boolean!, $regs: [Region!]!) {
        createAccount(name: $n, type: $t, accountId: $i, environment: $e, owner: $owner, applicationName: $app_name, distributionList: $dl, slackServiceChannel: $channel, businessUnit: $bu, dataClassification: $class, businessCriticality: $crit, connectivity: $connectivity, baselineChangeApprovalRequired: $b_approval, provisionChangeApprovalRequired: $p_approval, regions: $regs) {
          name
          accountType
          id
          environment
          owner
          applicationName
          distributionList
          slackServiceChannel
          businessUnit
          dataClassification
          businessCriticality
          connectivity
          baselineChangeApprovalRequired
          provisionChangeApprovalRequired
          regions
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               n: name,
               t: type,
               i: id,
               e: environment,
               owner:,
               app_name: application_name,
               dl: distribution_list,
               channel: slack_service_channel,
               bu: business_unit,
               class: data_classification,
               crit: business_criticality,
               connectivity:,
               b_approval: baseline_change_approval,
               p_approval: provision_change_approval,
               regs: regions
             }
           },
           headers: {
             "User-Arn": user_arn
           },
           as: :json
      JSON.decode(@response.body)
    end

    def delete_account(user_arn, account_id)
      mutation_query = <<-GRAPHQL
      mutation($id: ID!) {
        deleteAccount(id: $id) {
          id
        }
      }
      GRAPHQL
      post '/graphql',
           params: { query: mutation_query,
                     variables: {
                       id: account_id
                     } },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def update_account_metadata(
      user_arn,
      id,
      owner,
      application_name,
      distribution_list,
      slack_service_channel,
      business_unit,
      data_classification,
      business_criticality,
      connectivity,
      baseline_change_approval,
      provision_change_approval,
      regions
    )
      mutation_query = <<-GRAPHQL
      mutation($id: ID!, $owner: String, $app: String, $dl: String, $channel: String, $bu: String, $class: DataClassification, $crit: BusinessCriticality, $conn: AccountConnectivity, $b_approval: Boolean, $p_approval: Boolean, $regs: [Region!]!) {
        updateAccount(id: $id, owner: $owner, applicationName: $app, distributionList: $dl, slackServiceChannel: $channel, businessUnit: $bu, dataClassification: $class, businessCriticality: $crit, connectivity: $conn, baselineChangeApprovalRequired: $b_approval, provisionChangeApprovalRequired: $p_approval, regions: $regs) {
          id
          owner
          applicationName
          distributionList
          slackServiceChannel
          businessUnit
          dataClassification
          businessCriticality
          connectivity
          baselineChangeApprovalRequired
          provisionChangeApprovalRequired
          regions
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               id:,
               owner:,
               app: application_name,
               dl: distribution_list,
               channel: slack_service_channel,
               bu: business_unit,
               class: data_classification,
               crit: business_criticality,
               conn: connectivity,
               b_approval: baseline_change_approval,
               p_approval: provision_change_approval,
               regs: regions
             }
           },
           headers: {
             "User-Arn": user_arn
           },
           as: :json
      JSON.decode(@response.body)
    end

    def update_account_environment(user_arn, id, value)
      mutation_query = <<-GRAPHQL
      mutation($id: ID!, $environment: Environment!) {
        updateAccount(id: $id, environment: $environment) {
          id
          environment
        }
      }
      GRAPHQL
      post '/graphql',
           params: { query: mutation_query, variables: { id:, environment: value } },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def mutate_logging_foundation(user_arn, account_id, s3_raw_bucket, logging_iam_role, cloudtrail_sqs_queue, vpcflow_sqs_queue, oam_links)
      mutation_query = <<-GRAPHQL
      mutation ($id: String!, $s3RawBucket: String, $cloudtrailSqsQueue: String, $vpcflowSqsQueue: String, $loggingIamRole: String, $oamLinks: [FoundationLoggingOamLinksInput!]) {
        setLoggingFoundation(accountId: $id, s3RawBucket: $s3RawBucket, loggingIamRole: $loggingIamRole, cloudtrailSqsQueue: $cloudtrailSqsQueue, vpcflowSqsQueue: $vpcflowSqsQueue, oamLinks: $oamLinks) {
          logging {
            accountId
            s3RawBucket
            loggingIamRole
            cloudtrailSqsQueue
            vpcflowSqsQueue
            oamLinks {
              region
              arn
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               id: account_id,
               s3RawBucket: s3_raw_bucket,
               loggingIamRole: logging_iam_role,
               cloudtrailSqsQueue: cloudtrail_sqs_queue,
               vpcflowSqsQueue: vpcflow_sqs_queue,
               oamLinks: oam_links
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def mutate_network_foundation(
      user_arn,
      account_id,
      region,
      vpc_id,
      public_subnet_ids,
      private_subnet_ids,
      private_eks_subnet_ids,
      vpc_cidr,
      vpc_cidr_allocation,
      private_zone_id,
      dimension_private_zone_id,
      braintree_api_com_zone_id,
      fdfg_sftp_whitelist_cidrs,
      asm_endpoint_ips,
      autoscaling_endpoint_ips,
      cloudformation_endpoint_ips,
      dynamodb_endpoint_cidr_blocks,
      ec2_endpoint_ips,
      elasticloadbalancing_endpoint_ips,
      s3_endpoint_cidr_blocks,
      sts_endpoint_ips,
      logs_endpoint_ips,
      efs_endpoint_ips,
      sqs_endpoint_ips,
      public_access_cidrs,
      vpc_dns_addr,
      availability_zones_dsv
    )
      mutation_query = <<-GRAPHQL
      mutation ($id: String!, $region: Region!, $vpcId: String, $publicSubnetIds: [String!], $privateSubnetIds: [String!], $privateEksSubnetIds: [String!], $vpcCidr: String!, $vpcCidrAllocation: [String!], $privateZoneId: String, $dimensionPrivateZoneId: String, $braintreeApiComZoneId: String, $fdfgSftpWhitelistCidrs: [String!], $vpcDnsAddr: String, $availabilityZonesDsv: String, $asmEndpointIps: [String!], $autoscalingEndpointIps: [String!], $cloudformationEndpointIps: [String!], $dynamodbEndpointCidrBlocks: [String!], $ec2EndpointIps: [String!], $elasticloadbalancingEndpointIps: [String!], $s3EndpointCidrBlocks: [String!], $stsEndpointIps: [String!], $logsEndpointIps: [String!], $efsEndpointIps: [String!], $sqsEndpointIps: [String!], $publicAccessCidrs: [String!]) {
        setNetworkFoundation(accountId: $id, region: $region, vpcId: $vpcId, publicSubnetIds: $publicSubnetIds, privateSubnetIds: $privateSubnetIds, privateEksSubnetIds: $privateEksSubnetIds, vpcCidr: $vpcCidr, vpcCidrAllocation: $vpcCidrAllocation, privateZoneId: $privateZoneId, dimensionPrivateZoneId: $dimensionPrivateZoneId, braintreeApiComZoneId: $braintreeApiComZoneId, fdfgSftpWhitelistCidrs: $fdfgSftpWhitelistCidrs, vpcDnsAddr: $vpcDnsAddr, availabilityZonesDsv: $availabilityZonesDsv, asmEndpointIps: $asmEndpointIps, autoscalingEndpointIps: $autoscalingEndpointIps, cloudformationEndpointIps: $cloudformationEndpointIps, dynamodbEndpointCidrBlocks: $dynamodbEndpointCidrBlocks, ec2EndpointIps: $ec2EndpointIps, elasticloadbalancingEndpointIps: $elasticloadbalancingEndpointIps, s3EndpointCidrBlocks: $s3EndpointCidrBlocks, stsEndpointIps: $stsEndpointIps, logsEndpointIps: $logsEndpointIps, efsEndpointIps: $efsEndpointIps, sqsEndpointIps: $sqsEndpointIps, publicAccessCidrs: $publicAccessCidrs) {
          network {
            accountId
            region
            vpcId
            publicSubnetIds
            privateSubnetIds
            privateEksSubnetIds
            vpcCidr
            vpcCidrAllocation
            privateZoneId
            dimensionPrivateZoneId
            braintreeApiComZoneId
            fdfgSftpWhitelistCidrs
            vpcDnsAddr
            availabilityZonesDsv
            asmEndpointIps
            autoscalingEndpointIps
            cloudformationEndpointIps
            dynamodbEndpointCidrBlocks
            ec2EndpointIps
            elasticloadbalancingEndpointIps
            s3EndpointCidrBlocks
            stsEndpointIps
            logsEndpointIps
            efsEndpointIps
            sqsEndpointIps
            publicAccessCidrs
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               id: account_id,
               region:,
               vpcId: vpc_id,
               publicSubnetIds: public_subnet_ids,
               privateSubnetIds: private_subnet_ids,
               privateEksSubnetIds: private_eks_subnet_ids,
               vpcCidr: vpc_cidr,
               vpcCidrAllocation: vpc_cidr_allocation,
               privateZoneId: private_zone_id,
               dimensionPrivateZoneId: dimension_private_zone_id,
               braintreeApiComZoneId: braintree_api_com_zone_id,
               fdfgSftpWhitelistCidrs: fdfg_sftp_whitelist_cidrs,
               vpcDnsAddr: vpc_dns_addr,
               availabilityZonesDsv: availability_zones_dsv,
               asmEndpointIps: asm_endpoint_ips,
               autoscalingEndpointIps: autoscaling_endpoint_ips,
               cloudformationEndpointIps: cloudformation_endpoint_ips,
               dynamodbEndpointCidrBlocks: dynamodb_endpoint_cidr_blocks,
               ec2EndpointIps: ec2_endpoint_ips,
               elasticloadbalancingEndpointIps: elasticloadbalancing_endpoint_ips,
               s3EndpointCidrBlocks: s3_endpoint_cidr_blocks,
               stsEndpointIps: sts_endpoint_ips,
               logsEndpointIps: logs_endpoint_ips,
               efsEndpointIps: efs_endpoint_ips,
               sqsEndpointIps: sqs_endpoint_ips,
               publicAccessCidrs: public_access_cidrs
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def delete_network_foundation(
      user_arn,
      account_id,
      region
    )
      mutation_query = <<-GRAPHQL
      mutation ($accountId: String!, $region: Region!) {
        deleteNetworkFoundation(accountId: $accountId, region: $region) {
          network {
            accountId
            region
            vpcId
            publicSubnetIds
            privateSubnetIds
            privateEksSubnetIds
            vpcCidr
            vpcCidrAllocation
            privateZoneId
            dimensionPrivateZoneId
            braintreeApiComZoneId
            fdfgSftpWhitelistCidrs
            vpcDnsAddr
            availabilityZonesDsv
            asmEndpointIps
            autoscalingEndpointIps
            cloudformationEndpointIps
            dynamodbEndpointCidrBlocks
            ec2EndpointIps
            elasticloadbalancingEndpointIps
            s3EndpointCidrBlocks
            stsEndpointIps
            logsEndpointIps
            efsEndpointIps
            sqsEndpointIps
            publicAccessCidrs
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               accountId: account_id,
               region:
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def create_state_machine_execution(user_arn, account_id, execution_arn, region, start_time, status, type, deployers, configuration_document)
      mutation_query = <<-GRAPHQL
      mutation ($arn: String!, $region: Region!, $accountId: String!, $type: StateMachine!, $status: OrchestrationStatus!, $startTime: ISO8601DateTime!, $deployers: [DeployerInput!]!, $configurationDocument: JSON!) {
        createStateMachineExecution(accountId: $accountId, executionArn: $arn, region: $region, type: $type, startTime: $startTime, status: $status, deployers: $deployers, configurationDocument: $configurationDocument) {
          arn
          region
          startTime
          status
          deployers {
            name
            repository
            version
            status
            outputs
            resources
            snowTicket
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               accountId: account_id,
               arn: execution_arn,
               region:,
               type:,
               startTime: start_time,
               status:,
               deployers:,
               configurationDocument: configuration_document
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def delete_state_machine_execution(user_arn, execution_arn)
      mutation_query = <<-GRAPHQL
      mutation ($arn: String!) {
        deleteStateMachineExecution(arn: $arn) {
          arn
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               arn: execution_arn
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def update_state_machine(user_arn, argument_values)
      # mapping of mutation argument name to argument type
      argument_type_mapping = {
        'executionArn': 'String!',
        'region': 'Region',
        'status': 'OrchestrationStatus'
      }

      # check if provided arguments are expected values
      argument_values.each_key do |argument_name|
        next if argument_type_mapping.key?(argument_name)

        raise ArgumentError, "Unexpected argument: #{argument_name}, valid varaibles are #{argument_type_mapping.keys}"
      end

      # remove keys that aren't specified
      argument_type_mapping.each_key do |argument_name|
        argument_type_mapping.delete(argument_name) unless argument_values.key?(argument_name)
      end

      variable_type_declaration = argument_type_mapping.map { |name, t| "$#{name}: #{t}" }.join(', ')
      argument_assignment = argument_type_mapping.map { |name, _| "#{name}: $#{name}" }.join(', ')
      mutation_query = <<-GRAPHQL
      mutation (#{variable_type_declaration}) {
        updateStateMachineExecution(#{argument_assignment}) {
          arn
          region
          status
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: argument_values
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def update_state_machine_deployer(user_arn, execution_arn, deployer_name, deployer_status, version, outputs, resources, snow_ticket, failure_reason)
      mutation_query = <<-GRAPHQL
      mutation ($executionArn: String!, $name: String!, $status: DeployerStatus!, $version: String!, $outputs: JSON!, $resources: JSON!, $ticket: String, $failureReason: String){
        updateStateMachineDeployer(executionArn: $executionArn, name: $name, status: $status, version: $version, outputs: $outputs, resources: $resources, snowTicket: $ticket, failureReason: $failureReason) {
          arn
          status
          startTime
          region
          deployers {
            name
            status
            version
            outputs
            resources
            snowTicket
            failureReason
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               executionArn: execution_arn,
               name: deployer_name,
               status: deployer_status,
               version:,
               outputs:,
               resources:,
               ticket: snow_ticket,
               failureReason: failure_reason
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_query_types(user_arn)
      query_string = <<-GRAPHQL
    {
      __schema {
          queryType {
              fields {
                  name
                  description
                  type{
                    name
                    kind
                  }
              }
          }
      }
    }
      GRAPHQL
      post '/graphql',
           params: {
             query: query_string
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_mutation_types(user_arn)
      query_string = <<-GRAPHQL
    {
    __schema {
        mutationType {
          fields {
            name
            description
            type{
            name
            kind
            }
          }
        }
      }
    }
      GRAPHQL
      post '/graphql',
           params: {
             query: query_string
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_input_object_fields(user_arn, input_object)
      query_string = <<-GRAPHQL
    query ($name: String!){
        __type(name: $name) {
            name
            kind
            inputFields {
                name
                description
                defaultValue
            }
        }
    }
      GRAPHQL
      post '/graphql',
           params: {
             query: query_string,
             variables: {
               name: input_object
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_object_fields(user_arn, object)
      query_string = <<-GRAPHQL
    query ($name: String!){
      __type(name: $name) {
          name
          kind
          fields {
            name
          }
      }}
      GRAPHQL
      post '/graphql',
           params: {
             query: query_string,
             variables: {
               name: object
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def query_execution_details(user_arn, execution_arn)
      query_string = <<-GRAPHQL
      query($executionArn: String!) {
        statusByExecution(executionArn: $executionArn) {
          arn
          stateMachineType
          status
          startTime
          deployers {
            name
            status
            version
            outputs
            resources
            repository
          }}}
      GRAPHQL

      post '/graphql',
           params: {
             query: query_string,
             variables: {
               executionArn: execution_arn
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json

      JSON.decode(@response.body)
    end

    def get_account_details(user_arn, account_id)
      query_string = <<-GRAPHQL
      query($accountId: String!) {
        accounts (id: $accountId) {
          id
          accountType
          name
          environment
          baseline {
            executions {
              arn
              startTime
              status
              configurationDocument
              deployers {
                name
                status
                version
                outputs
                resources
                repository
              }}}}}
      GRAPHQL
      post '/graphql',
           params: {
             query: query_string,
             variables: {
               accountId: account_id
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_account(user_arn)
      query_string = <<-GRAPHQL
      query{
        accounts{
          id
          name
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: query_string
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_logging_foundation_details(user_arn)
      query_string = <<-GRAPHQL
      {
      foundation {
        logging {
          accountId
          s3RawBucket
          loggingIamRole
          cloudtrailSqsQueue
          vpcflowSqsQueue
          oamLinks {
            region
            arn
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: { query: query_string },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_apollo_details(user_arn)
      query_string = <<-GRAPHQL
      {
      foundation {
        apollo {
          logging {
            accountId
            loggingIamRole
          }
        }
      }
      }
      GRAPHQL
      post '/graphql',
           params: { query: query_string },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def mutate_apollo_foundation(user_arn, account_id, logging_iam_role)
      mutation_query = <<-GRAPHQL
      mutation ($id: String!, $loggingIamRole: String) {
        setApolloFoundation(accountId: $id, loggingIamRole: $loggingIamRole) {
          apollo {
            logging {
              accountId
              loggingIamRole
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               id: account_id,
               loggingIamRole: logging_iam_role
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_network_foundation_details(user_arn)
      query_string = <<-GRAPHQL
      {
      foundation {
        network {
          accountId
          asmEndpointIps
          autoscalingEndpointIps
          availabilityZonesDsv
          braintreeApiComZoneId
          cloudformationEndpointIps
          dimensionPrivateZoneId
          dynamodbEndpointCidrBlocks
          ec2EndpointIps
          efsEndpointIps
          elasticloadbalancingEndpointIps
          fdfgSftpWhitelistCidrs
          logsEndpointIps
          privateEksSubnetIds
          privateSubnetIds
          privateZoneId
          publicSubnetIds
          region
          s3EndpointCidrBlocks
          sqsEndpointIps
          stsEndpointIps
          vpcCidrAllocation
          vpcDnsAddr
          vpcId
          publicAccessCidrs
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: { query: query_string },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def mutate_baseline_foundation(
      user_arn,
      orchestration_account_id,
      region,
      environment,
      vpc_id,
      private_subnets,
      public_subnets,
      terraform_state_key,
      terraform_dynamodb_lock_table,
      dynamodb_global_deployer_lock_table,
      baseline
    )
      mutation_query = <<-GRAPHQL
      mutation (
        $orchestrationAccountId: String!,
        $region: Region!,
        $environment: CsorEnvironment!,
        $vpcId: String!,
        $privateSubnets: [String!]!,
        $publicSubnets: [String!]!,
        $terraformStateKey: String!,
        $terraformDynamodbLockTable: String!,
        $dynamodbGlobalDeployerLockTable: String!,
        $baseline: CsorBaselineInput!
      ) {
        setBaselineFoundation(
          orchestrationAccountId: $orchestrationAccountId,
          region: $region,
          environment: $environment,
          vpcId: $vpcId,
          privateSubnets: $privateSubnets,
          publicSubnets: $publicSubnets,
          terraformStateKey: $terraformStateKey,
          terraformDynamodbLockTable: $terraformDynamodbLockTable,
          dynamodbGlobalDeployerLockTable: $dynamodbGlobalDeployerLockTable,
          baseline: $baseline
        ) {
          csor {
            orchestrationAccountId
            region
            environment
            vpcId
            privateSubnets
            publicSubnets
            terraformStateKey
            terraformDynamodbLockTable
            dynamodbGlobalDeployerLockTable
            baseline {
              terraformStateFileBucket
              terraformPlanBucket
              deployerArns {
                baseDeployerArn
                stacksetDeployerArn
                loggingDeployerArn
                networkDeployerArn
                securityShieldDeployerArn
                cicdDeployerArn
              }
              stackset {
                name
              }
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               orchestrationAccountId: orchestration_account_id,
               region:,
               environment:,
               vpcId: vpc_id,
               privateSubnets: private_subnets,
               publicSubnets: public_subnets,
               terraformStateKey: terraform_state_key,
               terraformDynamodbLockTable: terraform_dynamodb_lock_table,
               dynamodbGlobalDeployerLockTable: dynamodb_global_deployer_lock_table,
               baseline:
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def mutate_braintree_foundation(
      user_arn,
      cosmos
    )
      mutation_query = <<-GRAPHQL
      mutation (
        $cosmos: BraintreeCosmosInput!
      ) {
        setBraintreeFoundation(
          cosmos: $cosmos
        ) {
          braintree {
            cosmos {
              accountId
              environment
              cpairAssumeRole
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               cosmos:
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def mutate_provision_foundation(
      user_arn,
      provision
    )
      mutation_query = <<-GRAPHQL
      mutation ($provision: CsorProvisionInput!) {
        setProvisionFoundation(provision: $provision) {
          csor {
            provision {
              terraformStateFileBucket
              terraformPlanBucket
              deployerArns {
                baseDeployerArn
                stacksetDeployerArn
                eksDeployerArn
                kapDeployerArn
              }
              stackset {
                name
              }
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: {
               provision:
             }
           },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_baseline_foundation_details(user_arn)
      query_string = <<-GRAPHQL
      {
        foundation {
          csor {
            orchestrationAccountId
            region
            environment
            vpcId
            privateSubnets
            publicSubnets
            terraformStateKey
            terraformDynamodbLockTable
            dynamodbGlobalDeployerLockTable
            baseline {
              terraformStateFileBucket
              terraformPlanBucket
              deployerArns {
                baseDeployerArn
                stacksetDeployerArn
                loggingDeployerArn
                networkDeployerArn
                securityShieldDeployerArn
                cicdDeployerArn
              }
              stackset {
                name
              }
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: { query: query_string },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def get_provision_foundation_details(user_arn)
      query_string = <<-GRAPHQL
      {
        foundation {
          csor {
            provision {
              terraformStateFileBucket
              terraformPlanBucket
              deployerArns {
                baseDeployerArn
                stacksetDeployerArn
                eksDeployerArn
                kapDeployerArn
              }
              stackset {
                name
              }
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: { query: query_string },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end

    def create_fcd(fcd, user_arn)
      mutation_query = <<-GRAPHQL
      mutation ($fcd: JSON!) {
        createFcd(fcd: $fcd) {
          configurationDocument
          createdAt
        }
      }
      GRAPHQL
      post '/graphql',
           params: {
             query: mutation_query,
             variables: { fcd: }
           },
           headers: {
             "User-Arn": user_arn
           },
           as: :json
      JSON.decode(@response.body)
    end

    def get_braintree_foundation_details(user_arn)
      query_string = <<-GRAPHQL
      {
        foundation {
          braintree {
            cosmos {
              accountId
              environment
              cpairAssumeRole
            }
          }
        }
      }
      GRAPHQL
      post '/graphql',
           params: { query: query_string },
           headers: { "User-Arn": user_arn },
           as: :json
      JSON.decode(@response.body)
    end
  end
end
