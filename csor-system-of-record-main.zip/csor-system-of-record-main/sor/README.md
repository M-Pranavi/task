# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version

* System dependencies

* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...

### Interacting with GraphQL

To send a query or mutation to the GraphQL server:

```bash
curl --location -k --request POST 'http://localhost:3000/graphql' \
--header 'Content-Type: application/json' \
-d "@query.graphql" | jq
```

Sample content for `query.graphql` to get logical data centers

```js
{"query":"{
  logicalDataCenters {
    id
    environment
    cloudProvider
  }
}","variables":{}}
```

Sample content for `query.graphql` to create a logical data center
```js
{"query":"mutation {
    createLogicalDataCenter(logicalDataCenterId: \"us-west-2\", environment: DEV, cloudProvider: AWS) {
        id
        environment
        cloudProvider
    }
}
","variables":{}}
```

Sample content for `query.graphql` to update a logical data center
```js
{"query":"mutation {
    updateLogicalDataCenter(id: \"us-west-2\", environment: QA) {
        id
        environment
        cloudProvider
    }
}
","variables":{}}
```

## Local Development

```
docker-compose -f docker-compose-local.yml up
```

To send a generic mutation to GraphQL
```
curl --location --request POST 'http://localhost:3000/graphql' \
--header 'Content-Type: application/json' \
--header 'User-Arn: arn:aws:sts::1234:assumed-role/assume_scoped_role_root/*' \
--no-progress-meter \
-d "@mutation.graphql" | jq
```

where `mutation.graphql` is a local file with the following contents:

To create an account:
```
{"query":"mutation ($name: String!, $type: String!, $account: String!) {
  createAccount(name: $name, type: $type, accountId: $account) {
    id
    name
    accountType
  }
}
","variables":{"name":"dev-bt-app3","type":"Tenant Account","account":"283271371363"}}
```

To query all accounts:
```
{"query":"{
  accounts {
    id
    name
    accountType
  }
}
","variables":{}}
```

To delete an account:
```
{"query":"mutation ($id: ID!) {
  deleteAccount(id: $id) {
    id
    name
    accountType
  }
}
","variables":{"id":"283271371363"}}
```
