# frozen_string_literal: true

require 'logger'

module CustomLogger
  class CustomLogger < Logger
    def initialize(logdev, shift_age = 0, shift_size = 1_048_576)
      super
      self.formatter = CustomFormatter.new
    end

    def add(severity, message = nil, progname = nil, &block)
      message = (message || (block && yield) || progname).to_s
      api_gw_request_id = Thread.current[:custom_request_id]
      message = "[ API GW RequestID: #{api_gw_request_id} ] - #{message}" unless api_gw_request_id.nil? || api_gw_request_id.empty? || message.include?('/health')
      super(severity, message, progname, &block)
    end
  end

  class CustomFormatter < Logger::Formatter
    def call(severity, time, _progname, msg)
      formatted_time = time.strftime('%Y-%m-%d %H:%M:%S%L')
      "[#{formatted_time}] #{severity} #{msg}\n"
    end
  end
end
