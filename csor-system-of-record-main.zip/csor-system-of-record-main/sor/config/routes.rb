# frozen_string_literal: true

Rails.application.routes.draw do
  # Commenting the below line so that UI is no longer accessible
  mount GraphiQL::Rails::Engine, at: '/ui', graphql_path: 'graphql#execute'
  mount HealthBit.rack => '/health'
  post '/graphql', to: 'graphql#execute'
  get '/docs', to: redirect('/docs/welcome')
end
