# frozen_string_literal: true

require 'rails_helper'

RSpec.describe SorSchema do
  it 'has expected types' do
    expect(SorSchema.types.keys).to include('Query', 'Mutation')
  end
end
