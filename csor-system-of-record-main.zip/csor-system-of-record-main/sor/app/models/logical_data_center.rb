# frozen_string_literal: true

class LogicalDataCenter < ApplicationRecord
  scope :id, ->(id) { where("document->>'id' = ?", id) if id.present? }
  scope :logical_data_center_name, ->(name) { where("document->>'name' = ?", name) if name.present? }
end
