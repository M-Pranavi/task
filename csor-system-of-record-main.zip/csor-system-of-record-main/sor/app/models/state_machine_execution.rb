# frozen_string_literal: true

class StateMachineExecution < ApplicationRecord
  scope :arn, ->(arn) { find_sole_by(['arn = ?', arn]) if arn.present? }
end
