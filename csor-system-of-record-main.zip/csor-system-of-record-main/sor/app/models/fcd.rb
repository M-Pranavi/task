# frozen_string_literal: true

class Fcd < ApplicationRecord
  self.table_name = 'fcd'
end
