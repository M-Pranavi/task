# frozen_string_literal: true

class Account < ApplicationRecord
  scope :id, ->(id) { where('account_id = ?', id) if id.present? }
  scope :account_name, ->(name) { where("document->>'name' = ?", name) if name.present? }
  scope :account_type, ->(type) { where("document->>'accountType' = ?", type) if type.present? }
  scope :cloudTrail, ->(status) { where("document->'security'->>'cloudTrail' = ?", status) if status.present? }

  has_many :state_machine_executions, foreign_key: :account_id, primary_key: :account_id
end
