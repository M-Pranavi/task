# frozen_string_literal: true

module Auth
  class AuthenticatedUser
    ADMIN = 'admin'
    UNAUTHORIZED = 'unauthorized'
    DEPLOYER = 'deployer'
    ONBOARD = 'onboard'
    BASELINE_REQUEST_SUBMITTER = 'request_submitter_baseline'
    PROVISION_REQUEST_SUBMITTER = 'request_submitter_provision'
    BASELINE_EXECUTION_REPORTER = 'execution_reporter_baseline'
    PROVISION_EXECUTION_REPORTER = 'execution_reporter_provision'
    NETWORK_HYDRATION_EXECUTOR = 'network_hydration_executor'
    CSOR_JENKINS_PIPELINE = 'csor_jenkins_pipeline'
  end
end
