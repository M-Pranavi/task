# frozen_string_literal: true

module Auth
  class User
    attr_reader :user, :prefix, :deployer_name

    def initialize(user_arn)
      @permissions = {
        'admin' => AuthenticatedUser::ADMIN,
        'deployer' => AuthenticatedUser::DEPLOYER,
        'onboard-role' => AuthenticatedUser::ONBOARD,
        'request-submitter-baseline-role' => AuthenticatedUser::BASELINE_REQUEST_SUBMITTER,
        'request-submitter-provision-role' => AuthenticatedUser::PROVISION_REQUEST_SUBMITTER,
        'execution-reporter-baseline-role' => AuthenticatedUser::BASELINE_EXECUTION_REPORTER,
        'execution-reporter-provision-role' => AuthenticatedUser::PROVISION_EXECUTION_REPORTER,
        'network-hydrate-execution-role' => AuthenticatedUser::NETWORK_HYDRATION_EXECUTOR,
        'csor-jenkins-pipeline-role' => AuthenticatedUser::CSOR_JENKINS_PIPELINE
      }
      @prefix, @user, @deployer_name = parse_user_arn(user_arn)
    end

    def admin?
      @user.eql?(AuthenticatedUser::ADMIN)
    end

    def authorized?(allowed_users)
      if allowed_users.instance_of?(String)
        @user.eql?(allowed_users)
      else
        allowed_users.include?(@user)
      end
    end

    def to_s
      name = if @deployer_name.nil?
               ''
             else
               "-#{deployer_name}"
             end
      "#{user}#{name}#{@prefix}"
    end

    def is?(authenticated_user)
      @user.eql?(authenticated_user)
    end

    private

    def parse_user_arn(arn)
      return nil, AuthenticatedUser::UNAUTHORIZED, nil if arn.blank?

      account, role_name, session = begin
        arn.match(%r{arn:aws:sts::([0-9]+):assumed-role/(.*)/(.*)}).captures
      rescue StandardError
        nil
      end
      return nil, AuthenticatedUser::UNAUTHORIZED, nil if account.blank? || role_name.blank? || session.blank?

      # Check if they are admin
      return "-#{session}", @permissions['admin'], nil if account.eql?(ENV['ADMIN_ACCOUNT']) && (role_name.eql?('assume_scoped_role_root') || role_name.eql?('assume_scoped_role_base'))

      # If they are not part of the orchestration account for this SOR they should not go past this point
      return "-#{session}", AuthenticatedUser::UNAUTHORIZED, nil unless account.eql?(ENV['ORCHESTRATION_ACCOUNT'])

      # Check if they are the fcd pipeline
      return "-#{session}", AuthenticatedUser::CSOR_JENKINS_PIPELINE, nil if role_name.match(/^csor-(nonprod|orchestration)-([a-zA-Z]+|[a-zA-Z]+-[a-zA-Z]+)-jenkins-service-account-role$/)

      # Check if they are a deployer
      if role_name.match?(/deployer_role/)
        deployer_name = begin
          role_name.match(/(.*)_deployer_role_*/).captures[0]
        rescue StandardError
          nil
        end
        return "-#{session}", @permissions['deployer'], deployer_name
      end

      # Anything else has an explicit mapping to a permission
      ["-#{session}", @permissions.fetch(role_name, AuthenticatedUser::UNAUTHORIZED), nil]
    end
  end
end
