# frozen_string_literal: true

class Foundation < ApplicationRecord
  self.table_name = 'foundation'
end
