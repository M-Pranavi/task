# frozen_string_literal: true

require 'active_support'

module Error
  class ErrorFormatter
    def initialize
      @backtrace_cleaner = configure_backtrace_cleaner
    end

    def format(exception)
      cleaned_backtrace = @backtrace_cleaner.clean(exception.backtrace)
      path = format_backtrace(cleaned_backtrace) # example: "{\"create_account.rb\"=>\"Line 51\"}"
      [exception.message.to_s, cleaned_backtrace, path.to_s]
    end

    private

    def configure_backtrace_cleaner
      backtrace_cleaner = ActiveSupport::BacktraceCleaner.new
      root = "#{Rails.root}/"
      backtrace_cleaner.add_filter { |line| line.start_with?(root) ? line.from(root.size) : line }
      backtrace_cleaner.add_silencer { |line| /puma|rubygems/.match?(line) }

      backtrace_cleaner
    end

    def format_backtrace(backtrace)
      lines = backtrace.flat_map { |str| str.split("\n") }
      # Map will get rid of duplicate traces
      path = {}

      lines.each_with_index do |line, _index|
        error_file, error_line = line.split(':')
        filename = error_file.strip.split('/').last
        path[filename] = "Line #{error_line.strip}"
      end

      path
    end
  end
end
