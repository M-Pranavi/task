# frozen_string_literal: true

require 'active_support/concern'

module Error
  module ErrorHandler
    extend ActiveSupport::Concern
    # initialize the ErrorFormatter
    ERROR_FORMATTER = Error::ErrorFormatter.new

    included do
      rescue_from StandardError, with: :handle_error
    end

    private

    # Handle all errors here
    def handle_error(exception)
      error_message, cleaned_backtrace, path = Error::ErrorHandler::ERROR_FORMATTER.format(exception)
      logger.error "Reporting Exception: #{error_message} Cleaned Backtrace: #{cleaned_backtrace}"
      case exception
      when ActiveRecord::RecordNotUnique
        render_error("Record Not Unique: #{error_message}", path, ErrorCodes::BAD_REQUEST, ActiveRecord::RecordNotUnique.new('Record already exists'))
      when ActionDispatch::Http::Parameters::ParseError
        render_error("Cannot parse payload based on Content-Type header: #{error_message}", path, ErrorCodes::BAD_REQUEST, exception)
      when ActiveRecord::RecordNotFound
        render_error("Record Not Found: #{error_message}", path, ErrorCodes::BAD_REQUEST, ActiveRecord::RecordNotFound.new('Record Not Found'))
      when ActiveRecord::SoleRecordExceeded
        render_error("More than one record found: #{error_message}", path, ErrorCodes::BAD_REQUEST, exception)
      else
        logger.error "Unhandled exception: #{exception.class}, please consider updating error handler for better user experience.\nBacktrace: #{exception.backtrace.join("\n")}"
        render_error("Internal Server Error: #{error_message}", path, ErrorCodes::INTERNAL_SERVER_ERROR, exception)
      end
    end

    def render_error(message, path, status, exception)
      render(json: { errors: [{ message:, path: }], data: nil }, status:)
      raise exception if Rails.env.test?
    end
  end
end
