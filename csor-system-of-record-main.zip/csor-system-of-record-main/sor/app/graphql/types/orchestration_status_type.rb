# frozen_string_literal: true

module Types
  class OrchestrationStatusType < Types::BaseEnum
    value 'SUCCEEDED', 'Status indicating a successful execution of the orchestration pipeline'
    value 'FAILED', 'Status indicating a failed execution of the orchestration pipeline'
    value 'TIMED_OUT', 'Status indicating a timed out execution of the orchestration pipeline'
    value 'ABORTED', 'Status indicating an aborted execution of the orchestration pipeline'
    value 'IN_PROGRESS', 'Status indicating an in progress execution of the orchestration pipeline'
  end
end
