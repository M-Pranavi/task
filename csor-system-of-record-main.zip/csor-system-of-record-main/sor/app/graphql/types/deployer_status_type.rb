# frozen_string_literal: true

module Types
  class DeployerStatusType < Types::BaseEnum
    value 'Success', 'Status indicating a successful execution of deployer'
    value 'Failed', 'Status indicating a failed execution of deployer'
    value 'Skipped', 'Status indicating a skipped execution of deployer'
    value 'Not_Started', 'Status indicating a deployer that has not yet started'
    value 'In_Progress', 'Status indicating that a deployer execution is in progress'
    value 'Waiting_For_Approval', 'Status indicating the deployer is waiting for approval'
  end
end
