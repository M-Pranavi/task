# frozen_string_literal: true

module Types
  class CsorProvisionType < Types::BaseObject
    field :terraform_state_file_bucket, String, 'Terraform state file bucket', null: true
    field :terraform_plan_bucket, String, 'Terraform plan bucket', null: true
    field :deployer_arns, Types::ProvisionBaseType, 'Deployer ARNs for provision', null: true
    field :stackset, Types::StacksetType, 'Stackset configuration for provision', null: true
  end
end
