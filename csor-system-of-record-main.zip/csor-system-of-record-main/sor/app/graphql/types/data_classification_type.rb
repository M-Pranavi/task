# frozen_string_literal: true

module Types
  class DataClassificationType < Types::BaseEnum
    value 'CLASS_1', 'Class 1 data classification'
    value 'CLASS_2', 'Class 2 data classification'
    value 'CLASS_3', 'Class 3 data classification'
    value 'CLASS_4', 'Class 4 data classification'
    value 'CLASS_5', 'Class 5 data classification'
  end
end
