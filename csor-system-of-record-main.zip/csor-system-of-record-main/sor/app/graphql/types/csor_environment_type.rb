# frozen_string_literal: true

module Types
  class CsorEnvironmentType < Types::BaseScalar
    description 'String representation of CSOR environments'

    def self.coerce_input(input_value, _context)
      raise GraphQL::CoercionError, "#{input_value.inspect} must be a string" unless input_value.is_a?(String)

      valid_environments = %w[
        internal-dev
        internal-qa
        dev
        qa
        sand
        prod
      ]
      raise GraphQL::CoercionError, "#{input_value.inspect} must be one of #{valid_environments}" unless valid_environments.include?(input_value)

      input_value
    end

    def self.coerce_result(ruby_value, _context)
      ruby_value.to_s
    end
  end
end
