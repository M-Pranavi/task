# frozen_string_literal: true

module Types
  class StateMachineExecutionSummaryType < Types::BaseObject
    field :region, RegionType, 'Region in which the state machine is running', null: false
    field :latest, Types::StateMachineExecutionType, 'Latest version of the state machine', null: false
    field :last_success, Types::StateMachineExecutionType, 'Last time the state machine ran with success', null: true
    field :executions, [Types::StateMachineExecutionType], 'List of all executions on the account', null: true
  end
end
