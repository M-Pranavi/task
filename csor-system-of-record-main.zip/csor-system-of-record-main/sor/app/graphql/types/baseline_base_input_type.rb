# frozen_string_literal: true

module Types
  class BaselineBaseInputType < Types::BaseInputObject
    description 'Input type for baseline base configuration'

    argument :base_deployer_arn, String, 'Base deployer IAM role ARN', required: true
    argument :stackset_deployer_arn, String, 'Stackset deployer IAM role ARN', required: true
    argument :logging_deployer_arn, String, 'Logging deployer IAM role ARN', required: true
    argument :network_deployer_arn, String, 'Network deployer IAM role ARN', required: true
    argument :security_shield_deployer_arn, String, 'Security shield deployer IAM role ARN', required: true
    argument :cicd_deployer_arn, String, 'CICD deployer IAM role ARN', required: true
  end
end
