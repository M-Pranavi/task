# frozen_string_literal: true

module Types
  class StacksetInputType < Types::BaseInputObject
    description 'Input type for stackset configuration'

    argument :name, String, 'Name of the stackset', required: true
  end
end
