# frozen_string_literal: true

module Types
  class EnvironmentType < Types::BaseEnum
    value 'DEV', 'Dev environment'
    value 'QA', 'QA environment'
    value 'SAND', 'Sand environment'
    value 'PROD', 'Prod environment'
  end
end
