# frozen_string_literal: true

module Types
  class MutationType < Types::BaseObject
    field :update_account, 'Update account with details', mutation: Mutations::UpdateAccount

    field :create_account, 'Create a new account', mutation: Mutations::CreateAccount
    field :delete_account, 'Delete account', mutation: Mutations::DeleteAccount

    field :create_state_machine_execution, 'Create State Machine with Execution details', mutation: Mutations::CreateStateMachineExecution
    field :delete_state_machine_execution, 'Delete state machine execution', mutation: Mutations::DeleteStateMachineExecution
    field :update_state_machine_execution, 'Update the Execution details for the account', mutation: Mutations::UpdateStateMachineExecution
    field :update_state_machine_deployer, 'Update deployer status', mutation: Mutations::UpdateStateMachineDeployer

    field :delete_network_foundation, mutation: Mutations::DeleteNetworkFoundation
    field :set_network_foundation, mutation: Mutations::SetNetworkFoundation
    field :set_logging_foundation, mutation: Mutations::SetLoggingFoundation
    field :set_apollo_foundation, 'Configure Apollo foundation settings', mutation: Mutations::SetApolloFoundation
    field :set_baseline_foundation, 'Configure CSOR baseline foundation settings', mutation: Mutations::SetBaselineFoundation
    field :set_braintree_foundation, 'Configure Braintree cosmos foundation settings', mutation: Mutations::SetBraintreeFoundation
    field :set_provision_foundation, 'Configure CSOR provision foundation settings', mutation: Mutations::SetProvisionFoundation

    field :create_fcd, 'Create a new valid FCD', mutation: Mutations::CreateFcd
  end
end
