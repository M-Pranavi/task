# frozen_string_literal: true

module Types
  class ApolloLoggingType < Types::BaseObject
    description 'Apollo logging configuration'

    field :account_id, String, 'Account ID of the foundation Account', null: false
    field :logging_iam_role, String, 'IAM role for Apollo logging', null: true
  end
end
