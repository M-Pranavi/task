# frozen_string_literal: true

module Types
  class FcdType < Types::BaseObject
    description 'Type that represents active FCD in CSoR'

    field :configuration_document, GraphQL::Types::JSON, 'Active FCD JSON'
    field :created_at, GraphQL::Types::ISO8601DateTime, 'Time of FCD creation'
  end
end
