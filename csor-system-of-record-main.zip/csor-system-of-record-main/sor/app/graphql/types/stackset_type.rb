# frozen_string_literal: true

module Types
  class StacksetType < Types::BaseObject
    field :name, String, 'Name of the stackset', null: true
  end
end
