# frozen_string_literal: true

module Types
  class BraintreeCosmosInputType < Types::BaseInputObject
    description 'Input type for Braintree Cosmos configuration'

    argument :account_id, String, 'Account ID of the Cosmos account', required: true
    argument :environment, Types::EnvironmentType, 'Environment of the Cosmos account', required: true
    argument :cpair_assume_role, String, 'CPAIR assume role principal', required: true
  end
end
