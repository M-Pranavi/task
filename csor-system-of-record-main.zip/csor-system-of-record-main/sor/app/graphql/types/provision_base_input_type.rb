# frozen_string_literal: true

module Types
  class ProvisionBaseInputType < Types::BaseInputObject
    description 'Input type for provision base configuration'

    argument :base_deployer_arn, String, 'Base deployer role ARN', required: true
    argument :stackset_deployer_arn, String, 'Stackset deployer role ARN', required: true
    argument :eks_deployer_arn, String, 'EKS deployer role ARN', required: true
    argument :kap_deployer_arn, String, 'KAP deployer role ARN', required: true
  end
end
