# frozen_string_literal: true

module Types
  class StateMachineExecutionType < Types::BaseObject
    field :arn, String, 'ARN for the state machine', null: false
    field :region, RegionType, 'Region of target account'
    field :status, Types::OrchestrationStatusType, 'Status of the state machine'
    field :start_time, GraphQL::Types::ISO8601DateTime, 'Start Time of the State Machine'
    field :deployers, [Types::DeployerType], 'List of the deployers of the state machine'
    field :configuration_document, GraphQL::Types::JSON, 'Name of the configuration document of the state machine'
  end
end
