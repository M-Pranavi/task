# frozen_string_literal: true

module Types
  class ProvisionBaseType < Types::BaseObject
    field :base_deployer_arn, String, 'Base deployer ARN', null: true
    field :stackset_deployer_arn, String, 'Stackset deployer ARN', null: true
    field :eks_deployer_arn, String, 'EKS deployer ARN', null: true
    field :kap_deployer_arn, String, 'KAP deployer ARN', null: true
  end
end
