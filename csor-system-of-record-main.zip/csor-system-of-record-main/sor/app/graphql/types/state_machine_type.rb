# frozen_string_literal: true

module Types
  class StateMachineType < Types::BaseEnum
    value 'BASELINE'
    value 'PROVISION'
  end
end
