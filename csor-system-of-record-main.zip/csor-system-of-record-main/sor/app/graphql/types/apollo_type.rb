# frozen_string_literal: true

module Types
  class ApolloType < Types::BaseObject
    description 'Apollo configuration'

    field :logging, Types::ApolloLoggingType, 'Apollo logging configuration', null: true
  end
end
