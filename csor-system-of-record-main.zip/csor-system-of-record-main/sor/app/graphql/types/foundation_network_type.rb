# frozen_string_literal: true

module Types
  class FoundationNetworkType < Types::BaseObject
    field :region, Types::RegionType, 'Region of the Foundation Account', null: false
    field :account_id, String, 'Account ID of the foundation Account', null: false
    field :vpc_id, String, 'Shared/runtime VPC ID of the account'
    field :public_subnet_ids, [String], 'Public subnet ids of the account'
    field :private_subnet_ids, [String], 'Private subnet ids of the account'
    field :private_eks_subnet_ids, [String], 'Private eks subnet ids of the account'
    field :vpc_cidr, String, 'CIDR block for runtime VPC'
    field :vpc_cidr_allocation, [String], 'CIDR blocks for primary runtime VPC and EKS VPCs'
    field :private_zone_id, String, 'Hosted zone ID for bt.local'
    field :dimension_private_zone_id, String, 'Hosted zone for internal dimension'
    field :braintree_api_com_zone_id, String, 'Hosted zone for braintree-api.com'
    field :fdfg_sftp_whitelist_cidrs, [String], 'SFTP whitelisted CIDRs'
    field :vpc_dns_addr, String, 'Address for vpc DNS'
    field :availability_zones_dsv, String, 'Comma separated string of AZs'

    # AWS service IP fields. In the future might want to make this a subtype.
    field :asm_endpoint_ips, [String], 'IPs for ASM service'
    field :autoscaling_endpoint_ips, [String], 'IPs for AutoScaling service'
    field :cloudformation_endpoint_ips, [String], 'IPs for CloudFormation service'
    field :dynamodb_endpoint_cidr_blocks, [String], 'CIDRs for DynamoDB service'
    field :ec2_endpoint_ips, [String], 'IPs for EC2 service'
    field :elasticloadbalancing_endpoint_ips, [String], 'IPs for ELB service'
    field :s3_endpoint_cidr_blocks, [String], 'CIDRs for S3 service'
    field :sts_endpoint_ips, [String], 'IPs for STS service'
    field :logs_endpoint_ips, [String], 'IPs for logs service'
    field :efs_endpoint_ips, [String], 'IPs for EFS service'
    field :sqs_endpoint_ips, [String], 'IPs for SQS service'
    field :public_access_cidrs, [String], 'CIDRs for public access'
  end
end
