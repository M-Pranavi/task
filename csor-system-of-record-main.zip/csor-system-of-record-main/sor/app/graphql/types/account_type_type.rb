# frozen_string_literal: true

module Types
  class AccountTypeType < Types::BaseEnum
    value 'FOUNDATION', 'FOUNDATION'
    value 'TENANT', 'TENANT'
  end
end
