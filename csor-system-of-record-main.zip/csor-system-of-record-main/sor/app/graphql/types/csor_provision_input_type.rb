# frozen_string_literal: true

module Types
  class CsorProvisionInputType < Types::BaseInputObject
    description 'Input type for CSOR provision configuration'

    argument :terraform_state_file_bucket, String, 'Terraform state file bucket', required: true
    argument :terraform_plan_bucket, String, 'Terraform plan bucket', required: true
    argument :deployer_arns, Types::ProvisionBaseInputType, 'Deployer role ARNs for provision', required: true
    argument :stackset, Types::StacksetInputType, 'Stackset configuration for provision', required: true
  end
end
