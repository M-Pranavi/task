# frozen_string_literal: true

module Types
  class FoundationType < Types::BaseObject
    # Existing network and logging fields
    field :network, [Types::FoundationNetworkType]
    field :logging, Types::FoundationLoggingType

    # Apollo configuration
    field :apollo, Types::ApolloType, 'Apollo configuration', null: true

    # Adding new top-level types
    field :braintree, Types::BraintreeType, 'Braintree configuration', null: true
    field :csor, Types::CsorType, 'CSOR configuration', null: true
  end
end
