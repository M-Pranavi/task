# frozen_string_literal: true

module Types
  class ExecutionStatusType < Types::BaseObject
    field :arn, String, 'Execution ID of the state machine', null: false
    field :state_machine_type, Types::StateMachineType, 'Type of State Machine: Baseline or Provision', null: false
    field :status, Types::OrchestrationStatusType, 'Status of State Machine', null: false
    field :start_time, GraphQL::Types::ISO8601DateTime, 'start_date of the state machine', null: false
    field :deployers, [Types::DeployerType], 'Name of the deployers'
    field :configuration_document, GraphQL::Types::JSON, 'BOM information'
  end
end
