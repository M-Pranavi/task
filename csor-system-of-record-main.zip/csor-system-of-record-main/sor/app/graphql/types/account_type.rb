# frozen_string_literal: true

module Types
  class AccountType < Types::BaseObject
    description 'This is my Account Class'

    field :id, ID, 'AWS Account ID for tenant or foundation account', null: false, method: :account_id
    field :name, String, 'AWS Account Name', null: false
    field :account_type, Types::AccountTypeType, 'Account Type: Foundation or Tenant', null: false
    field :environment, Types::EnvironmentType, 'Environment for which the account is used for', null: false
    field :owner, String, 'LDAP username of AWS account owner'
    field :application_name, String, 'Name of application running inside the account'
    field :distribution_list, String, 'Team distribution list of account owners'
    field :slack_service_channel, String, 'Slack service channel for the account owners team'
    field :business_unit, String, 'Business Unit for the account owners team'
    field :data_classification, Types::DataClassificationType, 'Classification type of data managed or used by account applications'
    field :business_criticality, Types::BusinessCriticalityType, 'Business criticality of applications within the account'
    field :connectivity, Types::AccountConnectivityType, 'Networking facing type for the applications inside the account'
    field :baseline, [Types::StateMachineExecutionSummaryType], 'Baseline state machine executions'
    field :app_infra, [Types::StateMachineExecutionSummaryType], 'Provision state machine executions'
    field :baseline_change_approval_required, Boolean, 'Whether the account requires change approval for baseline operations', fallback_value: false
    field :provision_change_approval_required, Boolean, 'Whether the account requires change approval for provision operations', fallback_value: false
    field :regions, [Types::RegionType], 'List of AWS regions associated with the account', null: false

    def baseline
      query = StateMachineExecution.where(account_id: object[:account_id], state_machine_type: 'BASELINE')
      query = query.where(region: context[:region]) if context[:region]
      executions = query.order(start_time: :desc)
      regions = executions.map(&:region).uniq
      deployer_name = context[:deployer_name]

      regions.map do |region|
        region_executions = executions.select { |exec| exec.region == region }
        if deployer_name
          region_executions.each do |exec|
            exec.deployers = exec.deployers.is_a?(Array) ? exec.deployers.select { |d| d['name'] == deployer_name } : []
          end
        end
        {
          region:,
          executions: region_executions,
          last_success: region_executions.find { |execution| execution.status == 'SUCCEEDED' },
          latest: region_executions.first
        }
      end
    end

    def app_infra
      query = StateMachineExecution.where(account_id: object[:account_id], state_machine_type: 'PROVISION')
      query = query.where(region: context[:region]) if context[:region]
      executions = query.order(start_time: :desc)
      regions = executions.map(&:region).uniq
      deployer_name = context[:deployer_name]

      regions.map do |region|
        region_executions = executions.select { |exec| exec.region == region }
        if deployer_name
          region_executions.each do |exec|
            exec.deployers = exec.deployers.is_a?(Array) ? exec.deployers.select { |d| d['name'] == deployer_name } : []
          end
        end
        {
          region:,
          executions: region_executions,
          last_success: region_executions.find { |execution| execution.status == 'SUCCEEDED' },
          latest: region_executions.first
        }
      end
    end
  end
end
