# frozen_string_literal: true

module Types
  class RegionType < Types::BaseScalar
    description 'String representation of AWS regions'

    # Common regions for all business units
    BRAINTREE_REGIONS = %w[
      us-east-1
      us-east-2
      us-west-2
      eu-central-1
      ap-southeast-2
    ].freeze

    # Additional regions only for Apollo BU
    APOLLO_ADDITIONAL_REGIONS = %w[
      ap-south-1
      ap-south-2
      ap-southeast-1
      me-central-1
    ].freeze

    # All regions for Apollo BU
    APOLLO_REGIONS = (BRAINTREE_REGIONS + APOLLO_ADDITIONAL_REGIONS).freeze

    def self.coerce_input(input_value, _context)
      raise GraphQL::CoercionError, "#{input_value.inspect} must be a string" unless input_value.is_a?(String)

      # Accept all valid AWS region formats for schema-level validation
      # Business unit-specific validation will happen in the mutation
      all_supported_regions = APOLLO_REGIONS

      # Basic format validation only at schema level
      raise GraphQL::CoercionError, "#{input_value.inspect} is not a supported AWS region. Valid regions: #{all_supported_regions}" unless all_supported_regions.include?(input_value)

      input_value
    end

    def self.coerce_result(ruby_value, _context)
      ruby_value.to_s
    end

    # Helper method to validate regions for a specific business unit
    def self.validate_regions_for_business_unit(regions, business_unit)
      valid_regions = case business_unit&.downcase
                      when 'apollo'
                        APOLLO_REGIONS
                      else
                        BRAINTREE_REGIONS
                      end

      invalid_regions = regions - valid_regions
      return true if invalid_regions.empty?

      raise GraphQL::CoercionError, "Regions #{invalid_regions} are not allowed for business unit '#{business_unit}'. Valid regions: #{valid_regions}"
    end
  end
end
