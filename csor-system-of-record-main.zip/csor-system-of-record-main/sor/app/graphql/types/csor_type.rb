# frozen_string_literal: true

module Types
  class CsorType < Types::BaseObject
    field :orchestration_account_id, String, 'Orchestration Account ID for the CSOR Account', null: false
    field :region, Types::RegionType, 'Region of the CSOR Account', null: false
    field :environment, Types::CsorEnvironmentType, 'Environment of the CSOR Account', null: false
    field :vpc_id, String, 'VPC ID of the CSOR Account', null: false
    field :private_subnets, [String], 'Private subnets of the CSOR Account', null: false
    field :public_subnets, [String], 'Public subnets of the CSOR Account', null: false
    field :terraform_state_key, String, 'Terraform state key', null: false
    field :terraform_dynamodb_lock_table, String, 'Terraform DynamoDB lock table', null: false
    field :dynamodb_global_deployer_lock_table, String, 'DynamoDB global deployer lock table', null: false
    field :baseline, Types::CsorBaselineType, 'Baseline configuration for CSOR', null: false
    field :provision, Types::CsorProvisionType, 'Provision configuration for CSOR', null: false
  end
end
