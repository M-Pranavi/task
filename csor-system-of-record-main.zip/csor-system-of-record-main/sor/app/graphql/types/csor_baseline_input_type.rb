# frozen_string_literal: true

module Types
  class CsorBaselineInputType < Types::BaseInputObject
    description 'Input type for CSOR baseline configuration'

    argument :terraform_state_file_bucket, String, 'Terraform state file bucket', required: true
    argument :terraform_plan_bucket, String, 'Terraform plan bucket', required: true
    argument :deployer_arns, Types::BaselineBaseInputType, 'Deployer role ARNs for baseline', required: true
    argument :stackset, Types::StacksetInputType, 'Stackset configuration for baseline', required: true
  end
end
