# frozen_string_literal: true

module Types
  class SubnetTypeType < Types::BaseEnum
    value 'PUBLIC'
    value 'PRIVATE'
  end
end
