# frozen_string_literal: true

require 'json'

module Types
  class QueryType < Types::BaseObject
    field :accounts, [Types::AccountType], null: false do
      argument :id, String, 'Id of account the query', required: false
      argument :business_unit, String, 'Filter by business unit', required: false
      argument :deployer_name, String, 'Filter by deployer name', required: false
      argument :name, String, 'Name of the account of the query', required: false
      argument :region, Types::RegionType, 'Deployer regions related to account', required: false
      argument :type, String, 'Type of the account of the query', required: false
    end

    def accounts(id: nil, business_unit: nil, deployer_name: nil, name: nil, region: nil, type: nil)
      accounts = Account.id(id).account_name(name).account_type(type).all

      accounts = accounts.select { |account| account.business_unit == business_unit } unless business_unit.nil?

      # Region filtering should be done at the application level, not via database query
      if region
        accounts = accounts.select do |account|
          account.regions&.include?(region)
        end
        # Set the region in the context to use in the AccountType resolver
        context[:region] = region
      end

      # Only set context for deployer_name, do not filter accounts here
      context[:deployer_name] = deployer_name if deployer_name

      accounts
    end

    field :foundation, Types::FoundationType do
    end

    def foundation
      foundation = Foundation.first
      return nil if foundation.nil?

      foundation.document
    end

    # Query to get a single execution status
    field :status_by_execution, Types::ExecutionStatusType do
      argument :execution_arn, String, required: true
    end

    def status_by_execution(execution_arn:)
      StateMachineExecution.arn(execution_arn)
    rescue ActiveRecord::RecordNotFound
      nil
    end

    # Provide the currently active FCD
    field :fcd, Types::FcdType do
    end

    def fcd
      Fcd.last
    rescue ActiveRecord::RecordNotFound
      nil
    end
  end
end
