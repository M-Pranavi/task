# frozen_string_literal: true

module Types
  class DeployerType < Types::BaseObject
    field :name, String, 'Name of the Deployer', null: false
    field :status, Types::DeployerStatusType, 'Status of the Deployer', null: false
    field :version, String, 'Version of the Deployer'
    field :outputs, GraphQL::Types::JSON, 'Terraform Output in JSON Format'
    field :resources, GraphQL::Types::JSON, 'Terraform Resources in JSON format'
    field :repository, String, 'GitHub Repository url for the deployer'
    field :snow_ticket, String, 'Snow ticket link for approval'
    field :failure_reason, String, 'Reason for the deployers failure'
  end
end
