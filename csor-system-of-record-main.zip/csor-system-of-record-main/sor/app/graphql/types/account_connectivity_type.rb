# frozen_string_literal: true

module Types
  class AccountConnectivityType < Types::BaseEnum
    value 'INTERNAL', 'Internal network connectivity for the account'
    value 'EXTERNAL', 'External network connectivity for the account'
  end
end
