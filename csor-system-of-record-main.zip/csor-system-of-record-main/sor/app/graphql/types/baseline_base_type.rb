# frozen_string_literal: true

module Types
  class BaselineBaseType < Types::BaseObject
    field :base_deployer_arn, String, 'Base deployer ARN', null: true
    field :stackset_deployer_arn, String, 'Stackset deployer ARN', null: true
    field :logging_deployer_arn, String, 'Logging deployer ARN', null: true
    field :network_deployer_arn, String, 'Network deployer ARN', null: true
    field :security_shield_deployer_arn, String, 'Security shield deployer ARN', null: true
    field :cicd_deployer_arn, String, 'CICD deployer ARN', null: true
  end
end
