# frozen_string_literal: true

module Types
  class CsorBaselineType < Types::BaseObject
    field :terraform_state_file_bucket, String, 'Terraform state file bucket', null: true
    field :terraform_plan_bucket, String, 'Terraform plan bucket', null: true
    field :deployer_arns, Types::BaselineBaseType, 'Deployer ARNs for baseline', null: true
    field :stackset, Types::StacksetType, 'Stackset configuration for baseline', null: true
  end
end
