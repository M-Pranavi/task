# frozen_string_literal: true

module Types
  class BusinessCriticalityType < Types::BaseEnum
    value 'LOW', 'Low business criticality for the company'
    value 'STANDARD', 'Standard business criticality for the company'
    value 'CRITICAL', 'Critical business criticality for the company'
    value 'BUSINESS_CRITICAL', 'Business critical business criticality for the company'
    value 'MISSION_CRITICAL', 'Mission critical business criticality for the company'
  end
end
