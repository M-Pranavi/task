# frozen_string_literal: true

module Types
  class BraintreeType < Types::BaseObject
    field :cosmos, Types::BraintreeCosmosType, 'Cosmos configuration for Braintree', null: true
    field :network, [Types::FoundationNetworkType], 'Network configuration for Braintree', null: true
    field :logging, Types::FoundationLoggingType, 'Logging configuration for Braintree', null: true
  end
end
