# frozen_string_literal: true

module Types
  class FoundationLoggingOamLinksInputType < Types::BaseInputObject
    argument :region, RegionType, required: true
    argument :arn, String, required: true
  end
end
