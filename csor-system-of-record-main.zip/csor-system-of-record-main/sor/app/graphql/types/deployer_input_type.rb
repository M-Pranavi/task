# frozen_string_literal: true

module Types
  class DeployerInputType < Types::BaseInputObject
    argument :name, String, 'Name of the deployer', required: true
    argument :version, String, 'Version of the deployer', required: false
    argument :status, Types::DeployerStatusType, 'Status of the deployer', required: true
    argument :repository, String, 'GitHub Repository url for the deployer', required: false
    argument :outputs, GraphQL::Types::JSON, 'Terraform Output in JSON format', required: false
    argument :resources, GraphQL::Types::JSON, 'Terraform Resources in JSON format', required: false
    argument :snow_ticket, String, 'Snow ticket url', required: false
    argument :failure_reason, String, 'Reason for the deployers failure', required: false
  end
end
