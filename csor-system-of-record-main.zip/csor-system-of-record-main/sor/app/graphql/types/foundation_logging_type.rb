# frozen_string_literal: true

module Types
  class FoundationLoggingOamLinksType < Types::BaseObject
    field :region, RegionType, null: false
    field :arn, String, null: false
  end

  class FoundationLoggingType < Types::BaseObject
    field :account_id, String, 'Account ID of the foundation Account', null: false
    field :s3_raw_bucket, String, 'S3 bucket for raw logs', null: true
    field :logging_iam_role, String, 'IAM role', null: true
    field :cloudtrail_sqs_queue, String, 'SQS Queue for Cloudtrail logs', null: true
    field :vpcflow_sqs_queue, String, 'SQS Queue for Vpcflow logs', null: true
    field :oam_links, [Types::FoundationLoggingOamLinksType], 'List of regional ARNs for collecting observability matrix', null: true
  end
end
