# frozen_string_literal: true

module Types
  class OrchestrationMetadataType < Types::BaseObject
    field :timestamp, GraphQL::Types::ISO8601DateTime, 'State machine execution start time', null: false
    field :execution_arn, String, 'State machine execution ARN', null: false
    field :log_link, String, 'Logs of the execution', null: true
    field :status, Types::OrchestrationStatusType, 'Overall execution status of the state machine', null: false
    field :deployers, [Types::DeployerType], 'List of deployers used in state machine', null: true
  end
end
