# frozen_string_literal: true

module Types
  class BraintreeCosmosType < Types::BaseObject
    field :account_id, String, 'Account ID of the cosmos Account', null: true
    field :environment, Types::EnvironmentType, 'Environment for cosmos', null: true
    field :cpair_assume_role, String, 'CPAIR assume role for cosmos', null: true
  end
end
