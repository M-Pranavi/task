# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class CreateFcd < BaseMutation
    argument :fcd, GraphQL::Types::JSON, 'FCD document', required: true

    type Types::FcdType

    def authorized?(_obj)
      allowed_users = [Auth::AuthenticatedUser::ADMIN, Auth::AuthenticatedUser::CSOR_JENKINS_PIPELINE]
      return true if context[:authenticated_user].authorized?(allowed_users)

      raise GraphQL::ExecutionError, 'Not authorized to perform create_fcd mutation'
    end

    def resolve(fcd: nil)
      Fcd.create!(configuration_document: fcd)
    end
  end
end
