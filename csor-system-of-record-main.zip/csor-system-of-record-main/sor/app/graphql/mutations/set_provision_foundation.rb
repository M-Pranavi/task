# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class SetProvisionFoundation < BaseMutation
    # arguments for provision configuration
    argument :provision, Types::CsorProvisionInputType, 'Provision configuration for CSOR', required: true

    # return type from the mutation
    type Types::FoundationType

    def authorized?(_obj)
      allowed_users = [
        Auth::AuthenticatedUser::CSOR_JENKINS_PIPELINE,
        Auth::AuthenticatedUser::ADMIN
      ]
      user = context[:authenticated_user]
      return true if user.authorized?(allowed_users)

      raise GraphQL::ExecutionError, 'Not authorized to perform set_provision_foundation mutation'
    end

    def resolve(provision:)
      foundation = Foundation.first

      if foundation.nil?
        # Create a new foundation with all provision fields populated
        foundation = Foundation.create!(
          document: {
            csor: {
              provision: {
                terraform_state_file_bucket: provision.terraform_state_file_bucket,
                terraform_plan_bucket: provision.terraform_plan_bucket,
                deployer_arns: {
                  base_deployer_arn: provision.deployer_arns.base_deployer_arn,
                  stackset_deployer_arn: provision.deployer_arns.stackset_deployer_arn,
                  eks_deployer_arn: provision.deployer_arns.eks_deployer_arn,
                  kap_deployer_arn: provision.deployer_arns.kap_deployer_arn
                },
                stackset: {
                  name: provision.stackset.name
                }
              }
            }
          }
        )
        return foundation.document
      end

      foundation.with_lock do
        # Ensure the top-level csor key exists
        foundation.document['csor'] = {} unless foundation.document.key?('csor')

        # Ensure the provision key exists in csor
        foundation.document['csor']['provision'] = {} unless foundation.document['csor'].key?('provision')

        # Update csor.provision properties
        prov = foundation.document['csor']['provision']
        prov['terraform_state_file_bucket'] = provision.terraform_state_file_bucket
        prov['terraform_plan_bucket'] = provision.terraform_plan_bucket

        # Update deployer_arns configuration
        prov['deployer_arns'] = {} unless prov.key?('deployer_arns')
        deployer_arns = prov['deployer_arns']
        deployer_arns['base_deployer_arn'] = provision.deployer_arns.base_deployer_arn
        deployer_arns['stackset_deployer_arn'] = provision.deployer_arns.stackset_deployer_arn
        deployer_arns['eks_deployer_arn'] = provision.deployer_arns.eks_deployer_arn
        deployer_arns['kap_deployer_arn'] = provision.deployer_arns.kap_deployer_arn

        # Update stackset configuration
        prov['stackset'] = {} unless prov.key?('stackset')
        prov['stackset']['name'] = provision.stackset.name

        foundation.save
      end

      foundation.document
    end
  end
end
