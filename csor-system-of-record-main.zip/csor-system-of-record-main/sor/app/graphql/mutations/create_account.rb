# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class CreateAccount < BaseMutation
    # arguments passed to the `resolve` method
    argument :name, String, 'Name of the Account', required: true
    argument :type, Types::AccountTypeType, 'Account Type', required: true
    argument :account_id, String, 'ID of the Account', required: true
    argument :environment, Types::EnvironmentType, 'Environment of the Account', required: true
    argument :owner, String, 'Owner of the account', required: true
    argument :application_name, String, 'Name of application running inside the account', required: true
    argument :distribution_list, String, 'Team distribution list of account owners', required: true
    argument :slack_service_channel, String, 'Slack service channel for the account owners team', required: true
    argument :business_unit, String, 'Business Unitt for the account owners team', required: true
    argument :data_classification, Types::DataClassificationType, 'Classification of data managed or used by the account', required: true
    argument :business_criticality, Types::BusinessCriticalityType, 'Business criticality of application within the account', required: true
    argument :connectivity, Types::AccountConnectivityType, 'Network facing type for the account', required: true
    argument :baseline_change_approval_required, Boolean, 'Whether the account requires change approval for baseline operations', required: true
    argument :provision_change_approval_required, Boolean, 'Whether the account requires change approval for provision operations', required: true
    argument :regions, [Types::RegionType], 'List of AWS regions associated with the account', required: true

    # return type from the mutation
    type Types::AccountType

    def authorized?(_obj)
      allowed_users = [Auth::AuthenticatedUser::ONBOARD, Auth::AuthenticatedUser::BASELINE_REQUEST_SUBMITTER, Auth::AuthenticatedUser::ADMIN]
      return true if context[:authenticated_user].authorized?(allowed_users)

      raise GraphQL::ExecutionError, 'Not authorized to perform create_account mutation'
    end

    def resolve(
      name: nil,
      type: nil,
      account_id: nil,
      environment: nil,
      owner: nil,
      application_name: nil,
      distribution_list: nil,
      slack_service_channel: nil,
      business_unit: nil,
      data_classification: nil,
      business_criticality: nil,
      connectivity: nil,
      baseline_change_approval_required: false,
      provision_change_approval_required: false,
      regions: nil
    )
      count = Account.id(account_id).count

      raise GraphQL::ExecutionError, "Account with ID '#{account_id}' already exists (found #{count} #{'account'.pluralize(count)} with matching ID)" if count > 0

      # Validate regions against business unit
      Types::RegionType.validate_regions_for_business_unit(regions, business_unit)

      # Write to both old and new columns to ensure data is not lost during cutover
      Account.create!(
        account_id:,
        name:,
        account_type: type,
        environment:,
        owner:,
        application_name:,
        distribution_list:,
        slack_service_channel:,
        business_unit:,
        data_classification:,
        business_criticality:,
        connectivity:,
        document: {
          id: account_id,
          name:,
          account_type: type,
          environment:,
          owner:,
          application_name:,
          distribution_list:,
          slack_service_channel:,
          business_unit:,
          data_classification:,
          business_criticality:,
          connectivity:,
          baseline_change_approval_required:,
          provision_change_approval_required:,
          regions:
        },
        baseline_change_approval_required:,
        provision_change_approval_required:,
        regions:
      )
    end
  end
end
