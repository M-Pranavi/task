# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class DeleteNetworkFoundation < BaseMutation
    # arguments passed to the `resolve` method
    argument :account_id, String, 'Account ID of the Foundation Account', required: true
    argument :region, Types::RegionType, 'Region', required: true

    # return type from the mutation
    type Types::FoundationType

    # TODO: Add network account when automatic hydration is set up.
    def authorized?(_obj)
      return true if context[:authenticated_user].admin?

      raise GraphQL::ExecutionError, 'Not authorized to perform delete_network_foundation mutation'
    end

    def resolve(account_id: nil,
                region: nil)
      foundation = Foundation.first

      raise GraphQL::ExecutionError, 'No network foundation configured' unless foundation.document.key?('network')

      foundation.with_lock do
        foundation.document['network'].delete_if { |network_config| network_config['account_id'] == account_id && network_config['region'] == region }
        foundation.save
      end

      foundation.document
    end
  end
end
