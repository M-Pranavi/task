# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class CreateStateMachineExecution < BaseMutation
    # arguments passed to the `resolve` method
    argument :account_id, String, 'Account ID of the StateMachine', required: true
    argument :execution_arn, String, 'Execution ARN of the state machine', required: true
    argument :region, Types::RegionType, 'Region of target account', required: true
    argument :start_time, GraphQL::Types::ISO8601DateTime, 'Start time of the State Machine', required: true
    argument :status, Types::OrchestrationStatusType, 'Execution_status of the State Machine', required: true
    argument :type, Types::StateMachineType, 'State Machine type: Baseline or Provision', required: true
    argument :deployers, [Types::DeployerInputType], 'Deployers Information', required: true
    argument :configuration_document, GraphQL::Types::JSON, 'BOM Information', required: true

    # return type from the mutation
    type Types::StateMachineExecutionType

    def authorized?(obj)
      allowed_users = [
        Auth::AuthenticatedUser::BASELINE_REQUEST_SUBMITTER,
        Auth::AuthenticatedUser::PROVISION_REQUEST_SUBMITTER,
        Auth::AuthenticatedUser::ADMIN
      ]
      user = context[:authenticated_user]
      if user.authorized?(allowed_users)
        # Ensure the request submitters are only operating on their state machine types
        unless user.admin?
          raise GraphQL::ExecutionError, 'Baseline attempted to create a non-baseline execution' if user.is?(Auth::AuthenticatedUser::BASELINE_REQUEST_SUBMITTER) && !obj[:type].eql?('BASELINE')

          raise GraphQL::ExecutionError, 'Provision attempted to create a non-provision execution' if user.is?(Auth::AuthenticatedUser::PROVISION_REQUEST_SUBMITTER) && !obj[:type].eql?('PROVISION')
        end
        return true
      end
      raise GraphQL::ExecutionError, 'Not authorized to perform create_account mutation'
    end

    def resolve(account_id:, execution_arn:, region:, start_time:, status:, type:, deployers:, configuration_document:)
      begin
        Account.find_sole_by(['account_id = ?', account_id])
      rescue ActiveRecord::RecordNotFound
        raise GraphQL::ExecutionError, "Account with ID '#{account_id}' not found"
      rescue ActiveRecord::SoleRecordExceeded
        raise GraphQL::ExecutionError, "Found multiple accounts with ID: #{account_id}"
      end

      state_machine_execution = StateMachineExecution.create!(
        account_id:,
        arn: execution_arn,
        region:,
        status:,
        start_time:,
        state_machine_type: type,
        deployers:,
        configuration_document:
      )

      {
        arn: state_machine_execution.arn,
        status: state_machine_execution.status,
        start_time: state_machine_execution.start_time,
        deployers: state_machine_execution.deployers,
        region: state_machine_execution.region
      }
    end
  end
end
