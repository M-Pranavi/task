# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class UpdateStateMachineDeployer < BaseMutation
    # arguments passed to the `resolve` method
    argument :execution_arn, String, 'Execution ARN of the state machine', required: true
    argument :name, String, 'Name of the deployer', required: true
    argument :status, Types::DeployerStatusType, 'Status of the Deployer', required: true
    argument :version, String, 'Deployer version', required: true
    argument :outputs, GraphQL::Types::JSON, 'Terraform Output in JSON format', required: false
    argument :resources, GraphQL::Types::JSON, 'Terraform Resources in JSON format', required: false
    argument :snow_ticket, String, 'Snow ticket link', required: false
    argument :failure_reason, String, 'Reason for the deployers failure', required: false
    # return type from the mutation
    type Types::StateMachineExecutionType

    def authorized?(obj)
      allowed_users = [
        Auth::AuthenticatedUser::DEPLOYER,
        Auth::AuthenticatedUser::ADMIN
      ]
      user = context[:authenticated_user]
      if user.authorized?(allowed_users)
        unless user.deployer_name.nil?
          # If its a deployer, ensure its allowed to update the deployer entry
          target_name = obj[:name]
          source_name = "#{user.deployer_name}_deployer"
          unless target_name.eql?(source_name) || (target_name.eql?('kap_deployer') && source_name.eql?('eks_deployer'))
            raise GraphQL::ExecutionError,
                  "Not authorized: #{source_name} attempted to update #{target_name} outputs"
          end
        end
        return true
      end
      raise GraphQL::ExecutionError, 'Not authorized to perform update_state_machine_deployer mutation'
    end

    def resolve(execution_arn:, name:, status:, version:, outputs: nil, resources: nil, snow_ticket: nil, failure_reason: nil)
      state_machine_execution = StateMachineExecution.arn(execution_arn)

      state_machine_execution.with_lock do
        deployer_found = false
        state_machine_execution['deployers'].each do |deployer|
          next unless deployer['name'] == name

          deployer['status'] = status
          deployer['version'] = version
          deployer['outputs'] = outputs unless outputs.nil?
          deployer['resources'] = resources unless resources.nil?
          deployer['snow_ticket'] = snow_ticket unless snow_ticket.nil?
          deployer['failure_reason'] = failure_reason unless failure_reason.nil?
          deployer_found = true
        end

        unless deployer_found
          state_machine_execution['deployers'].push(
            {
              name:,
              status:,
              version:,
              outputs:,
              resources:,
              snow_ticket:,
              failure_reason:
            }
          )
        end

        state_machine_execution.save
      end

      {
        arn: state_machine_execution.arn,
        status: state_machine_execution.status,
        start_time: state_machine_execution.start_time,
        deployers: state_machine_execution.deployers,
        region: state_machine_execution.region
      }
    end
  end
end
