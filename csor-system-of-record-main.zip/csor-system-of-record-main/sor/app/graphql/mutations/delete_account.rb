# frozen_string_literal: true

require 'json'

module Mutations
  class DeleteAccount < BaseMutation
    argument :id, ID, required: true

    type Types::AccountType

    def authorized?(_obj)
      return true if context[:authenticated_user].admin?

      raise GraphQL::ExecutionError, 'Not authorized to perform delete_account mutation'
    end

    def resolve(id:)
      account = Account.find_sole_by(['account_id = ?', id])

      account.destroy
      {
        id: account.account_id,
        name: account.name,
        account_type: account.account_type,
        environment: account.environment,
        owner: account.owner,
        application_name: account.application_name,
        distribution_list: account.distribution_list,
        slack_service_channel: account.slack_service_channel,
        business_unit: account.business_unit,
        data_classification: account.data_classification,
        business_criticality: account.business_criticality,
        connectivity: account.connectivity,
        regions: account.regions,
        baseline_change_approval_required: account.baseline_change_approval_required,
        provision_change_approval_required: account.provision_change_approval_required
      }
    end
  end
end
