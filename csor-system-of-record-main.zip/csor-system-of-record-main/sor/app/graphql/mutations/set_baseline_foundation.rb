# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class SetBaselineFoundation < BaseMutation
    # arguments for top-level CSOR properties
    argument :orchestration_account_id, String, 'Orchestration Account ID for the CSOR Account', required: true
    argument :region, Types::RegionType, 'Region of the CSOR control plane account', required: true
    argument :environment, Types::CsorEnvironmentType, 'Environment of the CSOR control plane account', required: true
    argument :vpc_id, String, 'VPC ID of the CSOR Account', required: true
    argument :private_subnets, [String], 'Private subnets of the CSOR Account VPC', required: true
    argument :public_subnets, [String], 'Public subnets of the CSOR Account VPC', required: true
    argument :terraform_state_key, String, 'Terraform state key', required: true
    argument :terraform_dynamodb_lock_table, String, 'Terraform DynamoDB lock table', required: true
    argument :dynamodb_global_deployer_lock_table, String, 'DynamoDB global deployer lock table', required: true

    # arguments for CSOR baseline
    argument :baseline, Types::CsorBaselineInputType, 'Baseline configuration for CSOR', required: true

    # return type from the mutation
    type Types::FoundationType

    def authorized?(_obj)
      allowed_users = [
        Auth::AuthenticatedUser::CSOR_JENKINS_PIPELINE,
        Auth::AuthenticatedUser::ADMIN
      ]
      user = context[:authenticated_user]
      return true if user.authorized?(allowed_users)

      raise GraphQL::ExecutionError, 'Not authorized to perform set_baseline_foundation mutation'
    end

    def resolve(orchestration_account_id:,
                region:,
                environment:,
                vpc_id:,
                private_subnets:,
                public_subnets:,
                terraform_state_key:,
                terraform_dynamodb_lock_table:,
                dynamodb_global_deployer_lock_table:,
                baseline:)
      foundation = Foundation.first

      if foundation.nil?
        foundation = Foundation.create!(
          document: {
            csor: {
              orchestration_account_id:,
              region:,
              environment:,
              vpc_id:,
              private_subnets:,
              public_subnets:,
              terraform_state_key:,
              terraform_dynamodb_lock_table:,
              dynamodb_global_deployer_lock_table:,
              baseline: {
                terraform_state_file_bucket: baseline.terraform_state_file_bucket,
                terraform_plan_bucket: baseline.terraform_plan_bucket,
                deployer_arns: {
                  base_deployer_arn: baseline.deployer_arns.base_deployer_arn,
                  stackset_deployer_arn: baseline.deployer_arns.stackset_deployer_arn,
                  logging_deployer_arn: baseline.deployer_arns.logging_deployer_arn,
                  network_deployer_arn: baseline.deployer_arns.network_deployer_arn,
                  security_shield_deployer_arn: baseline.deployer_arns.security_shield_deployer_arn,
                  cicd_deployer_arn: baseline.deployer_arns.cicd_deployer_arn
                },
                stackset: {
                  name: baseline.stackset.name
                }
              }
            }
          }
        )
        return foundation.document
      end

      foundation.with_lock do
        # Ensure the top-level csor key exists
        foundation.document['csor'] = {} unless foundation.document.key?('csor')

        # Update top-level csor properties
        csor = foundation.document['csor']
        csor['orchestration_account_id'] = orchestration_account_id
        csor['region'] = region
        csor['environment'] = environment
        csor['vpc_id'] = vpc_id
        csor['private_subnets'] = private_subnets
        csor['public_subnets'] = public_subnets
        csor['terraform_state_key'] = terraform_state_key
        csor['terraform_dynamodb_lock_table'] = terraform_dynamodb_lock_table
        csor['dynamodb_global_deployer_lock_table'] = dynamodb_global_deployer_lock_table

        # Ensure the baseline key exists in csor
        csor['baseline'] = {} unless csor.key?('baseline')

        # Update csor.baseline properties
        bl = csor['baseline']
        bl['terraform_state_file_bucket'] = baseline.terraform_state_file_bucket
        bl['terraform_plan_bucket'] = baseline.terraform_plan_bucket

        # Update deployer_arns configuration
        bl['deployer_arns'] = {} unless bl.key?('deployer_arns')
        deployer_arns = bl['deployer_arns']
        deployer_arns['base_deployer_arn'] = baseline.deployer_arns.base_deployer_arn
        deployer_arns['stackset_deployer_arn'] = baseline.deployer_arns.stackset_deployer_arn
        deployer_arns['logging_deployer_arn'] = baseline.deployer_arns.logging_deployer_arn
        deployer_arns['network_deployer_arn'] = baseline.deployer_arns.network_deployer_arn
        deployer_arns['security_shield_deployer_arn'] = baseline.deployer_arns.security_shield_deployer_arn
        deployer_arns['cicd_deployer_arn'] = baseline.deployer_arns.cicd_deployer_arn

        # Update stackset configuration
        bl['stackset'] = {} unless bl.key?('stackset')
        bl['stackset']['name'] = baseline.stackset.name

        foundation.save
      end

      foundation.document
    end
  end
end
