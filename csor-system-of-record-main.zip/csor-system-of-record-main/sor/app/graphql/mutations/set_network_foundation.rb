# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class SetNetworkFoundation < BaseMutation
    # arguments passed to the `resolve` method
    argument :account_id, String, 'Account ID of the Foundation Account', required: true
    argument :region, Types::RegionType, 'Region', required: true
    argument :vpc_id, String, 'Shared/runtime VPC ID of the Foundation Account', required: false
    argument :public_subnet_ids, [String], 'Public subnet IDs of the Foundation Account', required: false
    argument :private_subnet_ids, [String], 'Private subnet IDs of the Foundation Account', required: false
    argument :private_eks_subnet_ids, [String], 'Private EKS subnet IDs of the Foundation Account', required: false
    argument :vpc_cidr, String, 'CIDR block for runtime VPC', required: false
    argument :vpc_cidr_allocation, [String], 'CIDR blocks for primary runtime VPC and EKS VPCs', required: false
    argument :private_zone_id, String, 'Hosted zone ID for bt.local', required: false
    argument :dimension_private_zone_id, String, 'Hosted zone for internal dimension', required: false
    argument :braintree_api_com_zone_id, String, 'Hosted zone for braintree-api.com', required: false
    argument :fdfg_sftp_whitelist_cidrs, [String], 'SFTP whitelisted CIDRs', required: false
    argument :vpc_dns_addr, String, 'DNS Addrs for VPC', required: false
    argument :availability_zones_dsv, String, 'Comma separated string of AZs', required: false
    argument :asm_endpoint_ips, [String], 'IPs for ASM service', required: false
    argument :autoscaling_endpoint_ips, [String], 'IPs for AutoScaling service', required: false
    argument :cloudformation_endpoint_ips, [String], 'IPs for CloudFormation service', required: false
    argument :dynamodb_endpoint_cidr_blocks, [String], 'CIDRs for DynamoDB service', required: false
    argument :ec2_endpoint_ips, [String], 'IPs for EC2 service', required: false
    argument :elasticloadbalancing_endpoint_ips, [String], 'IPs for ELB service', required: false
    argument :s3_endpoint_cidr_blocks, [String], 'CIDRs for S3 service', required: false
    argument :sts_endpoint_ips, [String], 'IPs for STS service', required: false
    argument :logs_endpoint_ips, [String], 'IPs for logs service', required: false
    argument :efs_endpoint_ips, [String], 'IPs for EFS service', required: false
    argument :sqs_endpoint_ips, [String], 'IPs for SQS service', required: false
    argument :public_access_cidrs, [String], 'CIDRs for public access', required: false

    # return type from the mutation
    type Types::FoundationType

    # TODO: Add network account when automatic hydration is set up.
    def authorized?(_obj)
      allowed_users = [
        Auth::AuthenticatedUser::NETWORK_HYDRATION_EXECUTOR,
        Auth::AuthenticatedUser::ADMIN
      ]
      user = context[:authenticated_user]
      return true if user.authorized?(allowed_users)

      raise GraphQL::ExecutionError, 'Not authorized to perform set_network_foundation mutation'
    end

    def resolve(account_id: nil,
                region: nil,
                vpc_id: nil,
                public_subnet_ids: nil,
                private_subnet_ids: nil,
                private_eks_subnet_ids: nil,
                vpc_cidr: nil,
                vpc_cidr_allocation: nil,
                private_zone_id: nil,
                dimension_private_zone_id: nil,
                braintree_api_com_zone_id: nil,
                fdfg_sftp_whitelist_cidrs: nil,
                vpc_dns_addr: nil,
                availability_zones_dsv: nil,
                asm_endpoint_ips: nil,
                autoscaling_endpoint_ips: nil,
                cloudformation_endpoint_ips: nil,
                dynamodb_endpoint_cidr_blocks: nil,
                ec2_endpoint_ips: nil,
                elasticloadbalancing_endpoint_ips: nil,
                s3_endpoint_cidr_blocks: nil,
                sts_endpoint_ips: nil,
                logs_endpoint_ips: nil,
                efs_endpoint_ips: nil,
                sqs_endpoint_ips: nil,
                public_access_cidrs: nil)
      foundation = Foundation.first

      # Create a new network foundation data hash that will be used for both locations
      network_data = {
        region:,
        account_id:,
        vpc_id:,
        public_subnet_ids:,
        private_subnet_ids:,
        private_eks_subnet_ids:,
        vpc_cidr:,
        vpc_cidr_allocation:,
        private_zone_id:,
        dimension_private_zone_id:,
        braintree_api_com_zone_id:,
        fdfg_sftp_whitelist_cidrs:,
        vpc_dns_addr:,
        availability_zones_dsv:,
        asm_endpoint_ips:,
        autoscaling_endpoint_ips:,
        cloudformation_endpoint_ips:,
        dynamodb_endpoint_cidr_blocks:,
        ec2_endpoint_ips:,
        elasticloadbalancing_endpoint_ips:,
        s3_endpoint_cidr_blocks:,
        sts_endpoint_ips:,
        logs_endpoint_ips:,
        efs_endpoint_ips:,
        sqs_endpoint_ips:,
        public_access_cidrs:
      }

      if foundation.nil?
        foundation = Foundation.create!(
          document: {
            network: [network_data.dup],
            braintree: {
              network: [network_data.dup]
            }
          }
        )
        return foundation.document
      end

      foundation.with_lock do
        # Ensure the top-level network array exists
        foundation.document['network'] = [] unless foundation.document.key?('network')

        # Ensure the braintree key and its network array exists
        foundation.document['braintree'] = {} unless foundation.document.key?('braintree')
        foundation.document['braintree']['network'] = [] unless foundation.document['braintree'].key?('network')

        # Update top-level network
        update_network_data(foundation.document['network'], region, network_data)

        # Update braintree.network
        update_network_data(foundation.document['braintree']['network'], region, network_data)

        foundation.save
      end

      foundation.document
    end

    private

    # Updates network data in a given array
    def update_network_data(network_array, region, network_data)
      found_region = false

      network_array.each do |x|
        next if x['region'] != region

        # Update each property from network_data
        network_data.each do |key, value|
          x[key.to_s] = value unless value.nil?
        end

        found_region = true
      end

      # Add to array if it doesn't exist
      network_array.push(network_data.dup) unless found_region
    end
  end
end
