# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class UpdateStateMachineExecution < BaseMutation
    # arguments passed to the `resolve` method
    argument :execution_arn, String, 'Execution ARN of the state machine', required: true
    argument :region, Types::RegionType, 'Region of tenant account', required: false
    argument :status, Types::OrchestrationStatusType, 'Execution Status of the State Machine', required: false

    # return type from the mutation
    type Types::StateMachineExecutionType

    def authorized?(obj)
      allowed_users = [
        Auth::AuthenticatedUser::BASELINE_EXECUTION_REPORTER,
        Auth::AuthenticatedUser::PROVISION_EXECUTION_REPORTER,
        Auth::AuthenticatedUser::ADMIN
      ]
      user = context[:authenticated_user]
      if user.authorized?(allowed_users)
        unless user.admin?
          # We might need to figure out a way to do this that does not query the DB.
          execution = StateMachineExecution.arn(obj[:execution_arn])
          # Ensure state machine types do not cross
          if user.is?(Auth::AuthenticatedUser::BASELINE_EXECUTION_REPORTER) && !execution['state_machine_type'].eql?('BASELINE')
            raise GraphQL::ExecutionError, 'Baseline is attempting to update a non-baseline execution'
          end

          if user.is?(Auth::AuthenticatedUser::PROVISION_EXECUTION_REPORTER) && !execution['state_machine_type'].eql?('PROVISION')
            raise GraphQL::ExecutionError, 'Provision is attempting to update a non-provision execution'
          end
        end
        return true
      end
      raise GraphQL::ExecutionError, 'Not authorized to perform update_state_machine_execution mutation'
    end

    def resolve(execution_arn:, region: '', status: nil)
      state_machine_execution = StateMachineExecution.arn(execution_arn)

      state_machine_execution.with_lock do
        state_machine_execution['region'] = region if region != ''
        state_machine_execution['status'] = status if status
        state_machine_execution.save
      end

      {
        arn: state_machine_execution.arn,
        status: state_machine_execution.status,
        start_time: state_machine_execution.start_time,
        deployers: state_machine_execution.deployers,
        region: state_machine_execution.region
      }
    end
  end
end
