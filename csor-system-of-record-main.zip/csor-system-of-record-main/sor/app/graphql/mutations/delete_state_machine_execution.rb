# frozen_string_literal: true

require 'json'

module Mutations
  class DeleteStateMachineExecution < BaseMutation
    argument :arn, String, required: true

    type Types::StateMachineExecutionType

    def authorized?(_obj)
      return true if context[:authenticated_user].admin?

      raise GraphQL::ExecutionError, 'Not authorized to perform deleteStateMachineExecution mutation'
    end

    def resolve(arn:)
      state_machine_execution = StateMachineExecution.arn(arn)
      state_machine_execution.destroy

      state_machine_execution
    end
  end
end
