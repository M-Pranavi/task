# frozen_string_literal: true

require 'json'

module Mutations
  class SetLoggingFoundation < BaseMutation
    argument :account_id, String, 'Account ID of the Logging Foundation Account', required: true
    argument :s3_raw_bucket, String, 'S3 bucket for raw logs', required: false
    argument :logging_iam_role, String, 'Logging foundation IAM Role', required: false
    argument :cloudtrail_sqs_queue, String, 'SQS Queue for Cloudtrail logs', required: false
    argument :vpcflow_sqs_queue, String, 'SQS Queue for Vpcflow logs', required: false
    argument :oam_links, [Types::FoundationLoggingOamLinksInputType], 'List of OAM links', required: false

    type Types::FoundationType

    # TODO: Add logging account when automatic hydration is set up.
    def authorized?(_obj)
      return true if context[:authenticated_user].admin?

      raise GraphQL::ExecutionError, 'Not authorized to perform set_logging_foundation mutation'
    end

    def resolve(account_id: nil,
                s3_raw_bucket: nil,
                logging_iam_role: nil,
                cloudtrail_sqs_queue: nil,
                vpcflow_sqs_queue: nil,
                oam_links: nil)
      foundation = Foundation.first

      # Create a logging data hash that will be used for both locations
      logging_data = {
        account_id:,
        s3_raw_bucket:,
        logging_iam_role:,
        cloudtrail_sqs_queue:,
        vpcflow_sqs_queue:,
        oam_links:
      }

      if foundation.nil?
        foundation = Foundation.create!(
          document: {
            logging: logging_data.dup,
            braintree: {
              logging: logging_data.dup
            }
          }
        )
        return foundation.document
      end

      foundation.with_lock do
        # Ensure the top-level logging key exists
        foundation.document['logging'] = {} unless foundation.document.key?('logging')

        # Ensure the braintree key and its logging key exists
        foundation.document['braintree'] = {} unless foundation.document.key?('braintree')
        foundation.document['braintree']['logging'] = {} unless foundation.document['braintree'].key?('logging')

        # Update top-level logging
        top_level_logging = foundation.document['logging']
        top_level_logging[:account_id] = account_id unless account_id.nil?
        top_level_logging[:s3_raw_bucket] = s3_raw_bucket unless s3_raw_bucket.nil?
        top_level_logging[:logging_iam_role] = logging_iam_role unless logging_iam_role.nil?
        top_level_logging[:cloudtrail_sqs_queue] = cloudtrail_sqs_queue unless cloudtrail_sqs_queue.nil?
        top_level_logging[:vpcflow_sqs_queue] = vpcflow_sqs_queue unless vpcflow_sqs_queue.nil?
        top_level_logging[:oam_links] = oam_links unless oam_links.nil?

        # Update braintree.logging
        braintree_logging = foundation.document['braintree']['logging']
        braintree_logging[:account_id] = account_id unless account_id.nil?
        braintree_logging[:s3_raw_bucket] = s3_raw_bucket unless s3_raw_bucket.nil?
        braintree_logging[:logging_iam_role] = logging_iam_role unless logging_iam_role.nil?
        braintree_logging[:cloudtrail_sqs_queue] = cloudtrail_sqs_queue unless cloudtrail_sqs_queue.nil?
        braintree_logging[:vpcflow_sqs_queue] = vpcflow_sqs_queue unless vpcflow_sqs_queue.nil?
        braintree_logging[:oam_links] = oam_links unless oam_links.nil?

        foundation.save
      end

      foundation.document
    end
  end
end
