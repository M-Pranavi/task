# frozen_string_literal: true

require 'json'

module Mutations
  class UpdateAccount < BaseMutation
    # arguments passed to the `resolve` method
    argument :id, ID, 'Account ID', required: true
    argument :name, String, 'Name of the Account', required: false
    argument :account_type, String, 'Type of the Account', required: false
    argument :environment, Types::EnvironmentType, 'Environment the Account is running in', required: false
    argument :owner, String, 'Owner of the account', required: false
    argument :application_name, String, 'Name of application running inside the account', required: false
    argument :distribution_list, String, 'Team distribution list of account owners', required: false
    argument :slack_service_channel, String, 'Slack service channel for the account owners team', required: false
    argument :business_unit, String, 'Business Unitt for the account owners team', required: false
    argument :data_classification, Types::DataClassificationType, 'Classification of data managed or used by the account', required: false
    argument :business_criticality, Types::BusinessCriticalityType, 'Business criticality of application within the account', required: false
    argument :connectivity, Types::AccountConnectivityType, 'Network facing type for the account', required: false
    argument :baseline_change_approval_required, Boolean, 'Whether the account requires change approval for baseline operations', required: false
    argument :provision_change_approval_required, Boolean, 'Whether the account requires change approval for provision operations', required: false
    argument :regions, [Types::RegionType], 'List of AWS regions associated with the account', required: false

    # return type from the mutation
    type Types::AccountType

    # No usages so only admin can do this.
    def authorized?(_obj)
      return true if context[:authenticated_user].admin?

      raise GraphQL::ExecutionError, 'Not authorized to perform update_account mutation'
    end

    def resolve(
      id:,
      name: nil,
      account_type: nil,
      environment: nil,
      owner: nil,
      application_name: nil,
      distribution_list: nil,
      slack_service_channel: nil,
      business_unit: nil,
      data_classification: nil,
      business_criticality: nil,
      connectivity: nil,
      baseline_change_approval_required: nil,
      provision_change_approval_required: nil,
      regions: nil
    )
      account = Account.find_sole_by(['account_id = ?', id])

      # Validate regions against business unit if both are being updated or if regions are being updated
      if regions && (business_unit || account.business_unit)
        effective_business_unit = business_unit || account.business_unit
        Types::RegionType.validate_regions_for_business_unit(regions, effective_business_unit)
      end

      account.with_lock do
        # Write to both old and new columns to ensure data is not lost during cutover
        account.document[:name] = name unless name.nil?
        account.document[:account_type] = account_type unless account_type.nil?
        account.document[:environment] = environment unless environment.nil?
        account.document[:owner] = owner unless owner.nil?
        account.document[:application_name] = application_name unless application_name.nil?
        account.document[:distribution_list] = distribution_list unless distribution_list.nil?
        account.document[:slack_service_channel] = slack_service_channel unless slack_service_channel.nil?
        account.document[:business_unit] = business_unit unless business_unit.nil?
        account.document[:data_classification] = data_classification unless data_classification.nil?
        account.document[:business_criticality] = business_criticality unless business_criticality.nil?
        account.document[:connectivity] = connectivity unless connectivity.nil?
        account.document[:baseline_change_approval_required] = baseline_change_approval_required unless baseline_change_approval_required.nil?
        account.document[:provision_change_approval_required] = provision_change_approval_required unless provision_change_approval_required.nil?
        account.document[:regions] = regions unless regions.nil?

        account.name = name unless name.nil?
        account.account_type = account_type unless account_type.nil?
        account.environment = environment unless environment.nil?
        account.owner = owner unless owner.nil?
        account.application_name = application_name unless application_name.nil?
        account.distribution_list = distribution_list unless distribution_list.nil?
        account.slack_service_channel = slack_service_channel unless slack_service_channel.nil?
        account.business_unit = business_unit unless business_unit.nil?
        account.data_classification = data_classification unless data_classification.nil?
        account.business_criticality = business_criticality unless business_criticality.nil?
        account.connectivity = connectivity unless connectivity.nil?
        account.baseline_change_approval_required = baseline_change_approval_required unless baseline_change_approval_required.nil?
        account.provision_change_approval_required = provision_change_approval_required unless provision_change_approval_required.nil?
        account.regions = regions unless regions.nil?

        account.save
      end

      account
    end
  end
end
