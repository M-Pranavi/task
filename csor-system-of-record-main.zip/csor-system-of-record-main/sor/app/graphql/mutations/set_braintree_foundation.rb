# frozen_string_literal: true

require 'json'
require_relative '../../models/auth/authenticated_user'

module Mutations
  class SetBraintreeFoundation < BaseMutation
    # argument for Braintree Cosmos
    argument :cosmos, Types::BraintreeCosmosInputType, 'Braintree Cosmos configuration', required: true

    # return type from the mutation
    type Types::FoundationType

    def authorized?(_obj)
      allowed_users = [
        Auth::AuthenticatedUser::CSOR_JENKINS_PIPELINE,
        Auth::AuthenticatedUser::ADMIN
      ]
      user = context[:authenticated_user]
      return true if user.authorized?(allowed_users)

      raise GraphQL::ExecutionError, 'Not authorized to perform set_braintree_foundation mutation'
    end

    def resolve(cosmos:)
      foundation = Foundation.first

      if foundation.nil?
        foundation = Foundation.create!(
          document: {
            braintree: {
              cosmos: {
                account_id: cosmos.account_id,
                environment: cosmos.environment,
                cpair_assume_role: cosmos.cpair_assume_role
              }
            }
          }
        )
        return foundation.document
      end

      foundation.with_lock do
        # Ensure the braintree key exists
        foundation.document['braintree'] = {} unless foundation.document.key?('braintree')
        # Ensure the cosmos key exists under braintree
        foundation.document['braintree']['cosmos'] = {} unless foundation.document['braintree'].key?('cosmos')

        braintree_cosmos = foundation.document['braintree']['cosmos']
        braintree_cosmos['account_id'] = cosmos.account_id
        braintree_cosmos['environment'] = cosmos.environment
        braintree_cosmos['cpair_assume_role'] = cosmos.cpair_assume_role

        foundation.save
      end

      foundation.document
    end
  end
end
