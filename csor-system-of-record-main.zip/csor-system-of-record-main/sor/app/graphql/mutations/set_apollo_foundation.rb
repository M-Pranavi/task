# frozen_string_literal: true

require 'json'

module Mutations
  class SetApolloFoundation < BaseMutation
    argument :account_id, String, 'Account ID of the foundation Account', required: true
    argument :logging_iam_role, String, 'Apollo logging IAM Role', required: false

    type Types::FoundationType

    def authorized?(_obj)
      return true if context[:authenticated_user].admin?

      raise GraphQL::ExecutionError, 'Not authorized to perform set_apollo_foundation mutation'
    end

    def resolve(account_id: nil, logging_iam_role: nil)
      foundation = Foundation.first

      # Create apollo logging data hash
      apollo_logging_data = {
        account_id:,
        logging_iam_role:
      }

      if foundation.nil?
        foundation = Foundation.create!(
          document: {
            apollo: {
              logging: apollo_logging_data
            }
          }
        )
        return foundation.document
      end

      # Update document
      document = foundation.document || {}
      document['apollo'] ||= {}
      document['apollo']['logging'] = apollo_logging_data

      raise GraphQL::ExecutionError, foundation.errors.full_messages.join(', ') unless foundation.update(document:)

      foundation.document
    end
  end
end
