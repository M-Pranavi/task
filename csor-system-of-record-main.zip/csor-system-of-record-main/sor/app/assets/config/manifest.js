//= link graphiql/rails/application.css
//= link graphiql/rails/application.js
