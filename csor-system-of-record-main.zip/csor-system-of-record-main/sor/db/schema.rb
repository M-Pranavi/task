# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.1].define(version: 2025_05_16_140407) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "accounts", force: :cascade do |t|
    t.jsonb "document", default: {}, null: false
    t.string "account_id", null: false
    t.string "name", null: false
    t.string "account_type", null: false
    t.string "environment", null: false
    t.string "owner"
    t.string "application_name"
    t.string "distribution_list"
    t.string "slack_service_channel"
    t.string "business_unit"
    t.string "data_classification"
    t.string "business_criticality"
    t.string "connectivity"
    t.boolean "baseline_change_approval_required"
    t.boolean "provision_change_approval_required"
    t.string "regions", null: false, array: true
    t.datetime "created_at", default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.datetime "updated_at", default: -> { "CURRENT_TIMESTAMP" }, null: false
    t.index "((document ->> 'id'::text))", name: "index_accounts_on_document_id", unique: true
    t.index ["account_id"], name: "index_accounts_on_account_id", unique: true
    t.check_constraint "(document ->> 'id'::text) IS NOT NULL", name: "check_constraint_id_not_null"
  end

  create_table "fcd", force: :cascade do |t|
    t.jsonb "configuration_document", default: {}, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "foundation", force: :cascade do |t|
    t.jsonb "document", default: {}, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "state_machine_executions", force: :cascade do |t|
    t.string "arn"
    t.string "account_id"
    t.string "account_name"
    t.string "environment"
    t.string "status"
    t.datetime "start_time"
    t.string "state_machine_type"
    t.jsonb "deployers", default: [], null: false
    t.jsonb "configuration_document", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "snow_ticket"
    t.string "region", null: false
    t.index ["account_id"], name: "index_state_machine_executions_on_account_id"
    t.index ["arn"], name: "index_state_machine_executions_on_arn", unique: true
  end

  add_foreign_key "state_machine_executions", "accounts", primary_key: "account_id"
end
