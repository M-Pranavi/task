# frozen_string_literal: true

class UpdateAccountType < ActiveRecord::Migration[7.0]
  def change
    Account.where("document->>'account_type' ILIKE ?", '%Tenant%')
           .or(Account.where("document->>'account_type' ILIKE ?", '%Foundation%'))
           .update_all("document = jsonb_set(document, '{account_type}', to_jsonb(CASE
                       WHEN document->>'account_type' ILIKE '%Tenant%' THEN 'TENANT'
                       WHEN document->>'account_type' ILIKE '%Foundation%' THEN 'FOUNDATION'
                       ELSE document->>'account_type' END))")
  end
end
