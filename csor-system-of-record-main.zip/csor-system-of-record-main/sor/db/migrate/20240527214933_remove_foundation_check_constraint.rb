# frozen_string_literal: true

class RemoveFoundationCheckConstraint < ActiveRecord::Migration[7.0]
  def change
    remove_check_constraint :foundation, name: 'check_single_row'
  end
end
