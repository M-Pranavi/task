# frozen_string_literal: true

class AddColumnsFromAccountsJson < ActiveRecord::Migration[7.1]
  def change
    add_column :accounts, :account_id, :string
    add_column :accounts, :name, :string

    add_column :accounts, :account_type, :string
    add_column :accounts, :environment, :string

    add_column :accounts, :owner, :string
    add_column :accounts, :application_name, :string
    add_column :accounts, :distribution_list, :string
    add_column :accounts, :slack_service_channel, :string

    # Should this be an enum instead of a string?
    add_column :accounts, :business_unit, :string

    add_column :accounts, :data_classification, :string
    add_column :accounts, :business_criticality, :string
    add_column :accounts, :connectivity, :string

    add_column :accounts, :baseline_change_approval_required, :boolean
    add_column :accounts, :provision_change_approval_required, :boolean

    add_column :accounts, :regions, :string, array: true

    # Copy values from `document` column
    # TODO: Update section below from SQL to Rails compatible syntax
    Account.update_all("account_id = document->>'id'")
    Account.update_all("name = document->>'name'")
    Account.update_all("account_type = document->>'account_type'")
    Account.update_all("environment = document->>'environment'")
    Account.update_all("owner = document->>'owner'")
    Account.update_all("application_name = document->>'application_name'")
    Account.update_all("distribution_list = document->>'distribution_list'")
    Account.update_all("slack_service_channel = document->>'slack_service_channel'")
    Account.update_all("business_unit = document->>'business_unit'")
    Account.update_all("data_classification = document->>'data_classification'")
    Account.update_all("business_criticality = document->>'business_criticality'")
    Account.update_all("connectivity = document->>'connectivity'")
    Account.update_all("regions = ARRAY(SELECT jsonb_array_elements_text(document->'regions'))")

    Account.update_all("baseline_change_approval_required = (document->'baseline_change_approval_required')::boolean")
    Account.update_all("provision_change_approval_required = (document->'provision_change_approval_required')::boolean")

    # Ensure `account_id` column is unique
    add_index :accounts, :account_id, unique: true

    # set NOT NULL on specific columns
    change_column_null :accounts, :account_id, false
    change_column_null :accounts, :name, false
    change_column_null :accounts, :account_type, false
    change_column_null :accounts, :environment, false
    change_column_null :accounts, :regions, false

    add_foreign_key :state_machine_executions, :accounts, column: :account_id, primary_key: :account_id
    add_index :state_machine_executions, :account_id
  end
end
