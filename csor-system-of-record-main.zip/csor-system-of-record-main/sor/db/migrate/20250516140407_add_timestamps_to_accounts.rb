# frozen_string_literal: true

class AddTimestampsToAccounts < ActiveRecord::Migration[7.1]
  def change
    add_timestamps :accounts, default: -> { 'CURRENT_TIMESTAMP' }, null: false
  end
end
