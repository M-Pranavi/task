# frozen_string_literal: true

class DeleteDuplicateEntries < ActiveRecord::Migration[7.0]
  def change
    Account.delete_by(id: '614751254790')
  end
end
