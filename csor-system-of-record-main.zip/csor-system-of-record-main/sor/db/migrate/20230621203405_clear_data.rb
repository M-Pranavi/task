# frozen_string_literal: true

class ClearData < ActiveRecord::Migration[7.0]
  def change
    Account.delete_all
  end
end
