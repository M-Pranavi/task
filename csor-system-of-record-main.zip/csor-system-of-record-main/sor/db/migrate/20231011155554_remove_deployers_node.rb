# frozen_string_literal: true

class RemoveDeployersNode < ActiveRecord::Migration[7.0]
  def change
    Account.update_all("document = document - 'deployers' ")
    Account.update_all("document = document || '{\"orchestration_metadata\": {}}'::jsonb")
  end
end
