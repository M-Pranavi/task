# frozen_string_literal: true

class CreateFoundation < ActiveRecord::Migration[7.0]
  def change
    create_table :foundation do |t|
      t.jsonb :document, null: false, default: {}
      t.timestamps
    end
    add_check_constraint :foundation, 'id = 1', name: 'check_single_row'
  end
end
