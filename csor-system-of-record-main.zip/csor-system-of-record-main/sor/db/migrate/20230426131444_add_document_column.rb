# frozen_string_literal: true

class AddDocumentColumn < ActiveRecord::Migration[7.0]
  def change
    remove_column :accounts, :name, :string
    remove_column :accounts, :account_type, :string
    remove_column :accounts, :account_id, :string
    change_table :accounts do |t|
      t.remove_timestamps
      t.jsonb :document, null: false, default: {}
    end
  end
end
