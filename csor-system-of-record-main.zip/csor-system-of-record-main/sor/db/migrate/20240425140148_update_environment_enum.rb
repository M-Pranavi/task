# frozen_string_literal: true

class UpdateEnvironmentEnum < ActiveRecord::Migration[7.0]
  def change
    Account
      .where("document->>'environment' ILIKE ?", '%DEV%')
      .or(Account.where("document->>'environment' ILIKE ?", '%QA%'))
      .update_all("document = jsonb_set(document, '{environment}', to_jsonb(CASE
                  WHEN document->>'environment' ILIKE '%DEV%' THEN 'DEV'
                  WHEN document->>'environment' ILIKE '%QA%' THEN 'QA'
                  ELSE document->>'environment' END))")
  end
end
