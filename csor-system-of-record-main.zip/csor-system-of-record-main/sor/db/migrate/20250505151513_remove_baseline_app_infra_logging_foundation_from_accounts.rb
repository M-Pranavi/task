# frozen_string_literal: true

class RemoveBaselineAppInfraLoggingFoundationFromAccounts < ActiveRecord::Migration[7.1]
  def change
    Account.update_all("document = document - 'foundation_logging'")
    Account.update_all("document = document - 'baseline'")
    Account.update_all("document = document - 'app_infra'")
  end
end
