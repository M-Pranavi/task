# frozen_string_literal: true

class AddSnowTicketColumn < ActiveRecord::Migration[7.0]
  def change
    change_table :state_machine_executions do |t|
      t.string :snow_ticket
    end
  end
end
