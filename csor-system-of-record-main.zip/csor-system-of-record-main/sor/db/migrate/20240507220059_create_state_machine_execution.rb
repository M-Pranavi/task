# frozen_string_literal: true

class CreateStateMachineExecution < ActiveRecord::Migration[7.0]
  def change
    create_table :state_machine_executions do |t|
      t.string :arn
      t.string :account_id
      t.string :account_name
      t.string :environment
      t.string :status
      t.datetime :start_time
      t.string :state_machine_type
      t.jsonb :deployers, null: false, default: []
      t.jsonb :configuration_document, null: false
      t.timestamps
    end
  end
end
