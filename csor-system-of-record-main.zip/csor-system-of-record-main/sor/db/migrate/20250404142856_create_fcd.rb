# frozen_string_literal: true

class CreateFcd < ActiveRecord::Migration[7.1]
  def change
    create_table :fcd do |t|
      t.jsonb :configuration_document, null: false, default: {}
      t.timestamps
    end
  end
end
