# frozen_string_literal: true

class AddNotNullStateMachineExecutionRegion < ActiveRecord::Migration[7.1]
  def change
    change_column_null(:state_machine_executions, :region, false)
  end
end
