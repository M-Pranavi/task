# frozen_string_literal: true

class UniqueStateMachineArn < ActiveRecord::Migration[7.0]
  def change
    add_index :state_machine_executions, :arn, unique: true
  end
end
