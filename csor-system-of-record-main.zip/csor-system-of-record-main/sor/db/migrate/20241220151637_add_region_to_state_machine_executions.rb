# frozen_string_literal: true

class AddRegionToStateMachineExecutions < ActiveRecord::Migration[7.0]
  def change
    add_column :state_machine_executions, :region, :string, null: true
  end
end
