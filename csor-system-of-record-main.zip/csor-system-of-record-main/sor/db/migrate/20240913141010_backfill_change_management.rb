# frozen_string_literal: true

class BackfillChangeManagement < ActiveRecord::Migration[7.0]
  def change
    Account
      .where("document->>'baseline_change_approval_required' IS NULL")
      .update_all("document = jsonb_set(document, '{baseline_change_approval_required}', to_jsonb(false))")

    Account
      .where("document->>'provision_change_approval_required' IS NULL")
      .update_all("document = jsonb_set(document, '{provision_change_approval_required}', to_jsonb(false))")
  end
end
