# frozen_string_literal: true

class UniqueAccounts < ActiveRecord::Migration[7.0]
  def change
    Account.delete_all

    # ensure ID always has a unique value
    add_index :accounts, "(document ->> 'id')", unique: true
    # ensure that the value of ID is not null
    add_check_constraint :accounts, "(document ->> 'id') IS NOT NULL", name: 'check_constraint_id_not_null'
  end
end
