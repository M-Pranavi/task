# frozen_string_literal: true

class CreateLogicalDataCenters < ActiveRecord::Migration[7.0]
  def change
    create_table :logical_data_centers do |t|
      t.timestamps
      t.jsonb :document, null: false, default: {}

      # ensure ID always has a unique value
      t.index "(document ->> 'id')", unique: true
      # ensure that the value of ID is not null
      t.check_constraint "(document ->> 'id') IS NOT NULL", name: 'check_constraint_id_not_null'
    end
  end
end
