# frozen_string_literal: true

class DeleteDuplicateEntriesByAccountId < ActiveRecord::Migration[7.0]
  def change
    Account.delete_by(id: '614751254790')
  end
end
