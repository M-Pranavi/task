# csor-system-of-record

The System of Record (SoR) is a central Aurora PostgreSQL RDS data store that contains metadata about all accounts for a given environment. SoR can be queried for information using GraphQL.
This repository contains the following:
  1. Ruby on Rails (RoR) application that contains the GraphQL interface used for the System of Record (SoR)
  2. Terraform Configuration for deploying System of Record (SoR)


## Table of Contents

- [Description](#description)
- [Prerequisites](#requirements)
- [Usage](#usage)
- [Deploying](#deploying)
- [Release Process](#release-process)
- [Accessing RDS Cluster](#accessing-rds-cluster)
- [Contributing](#contributing)
- [Contact](#contact)

---

## Description

This repository contains the following components:

#### csor-system-of-record

| Directory | Description |
| --- | --- |
| `bin/` | Scripts to release this repository, run SOR tests and run Docker container
| `sor/` | Ruby on Rails (RoR) application that contains the GraphQL interface used for the System of Record (SoR) |
| `infrastructure/` | All IaC code (terraform) configuration for deploying SoR: API Gateway, VPCs, IAM roles, Datdog configuration and other AWS infrastructure |

The deploy is managed by Jenkins [`Jenkinsfile`](https://github.com/PayPal-Braintree/csor-system-of-record/blob/main/Jenkinsfile).

[![Build Status](https://ci.braintree.tools/buildStatus/icon?job=PayPal-Braintree%2Fcsor-system-of-record%2Fmain&subject=Main%20build)](https://ci.braintree.tools/job/PayPal-Braintree/job/csor-system-of-record/)

- **PR** Request in this repo will trigger a pipeline run to TF Checks and TF Plan in the **Dev environment**, 
- **PR** Merge in this repo will trigger a pipeline run to TF Apply in the **Dev environment**.
- To apply changes to the higher environments, refer to the **Release** section.
- CHANGELOG update is checked during PR build.

## Requirements

- Teraform >= 1.5.2
- Ruby 3.2.8


## Usage  

Jenkins pipeline is using a Docker image created by other csor repository [csor-tooling](https://github.com/PayPal-Braintree/dockerfiles/blob/main/app_base/csor_tooling/). The image is passed as an environment variable in `Jenkinsfile`

```
pipeline {
  agent any
  environment {
    TOOLING_IMAGE = "dockerhub.braintree.tools/infrastructure-tooling:latest"
  }
```
- [CSOR_TOOLING_IMAGE docker file](https://github.com/PayPal-Braintree/dockerfiles/blob/main/app_base/csor_tooling/Dockerfile) - This one is used for all Terraform stages in Jenkins.


The deployment is done by Jenkins and it is using AWS Credentials (AWS Access Key ID and AWS Secret Access Key) provided by the CCOE Service Account. These credentials can be found in secrets manager in the respective environment's AWS secrets account `<env>-bt-secrets`, in region `us-west-2`.

These credentials map to the Jenkins IAM role `csor-sor-<env>-jenkins-service-account-role` in the SOR AWS account, and it's AWS Access Key and Secret is configured as a credential in the Jenkins pipeline configuration. These credentials must be manually retrieved from AWS secrets manager and rotated in Jenkins every 60 days. This service account also has a role created in the AWS security foundation account, the role is used by terraform init (backend).

The role is configure in ./infrastructure/terraform.tf

```
  backend "s3" {
    bucket = "<tfstate_bucket_name"
    key    = "<tfstate_key>.tfstate"

    region   = "<aws region>"
    role_arn = "<role_arn"
  }
```

When running a pipeline from this repo, some terraform format, code linting, security checks and error checks will be executed:
- terraform_fmt
- tflint
- tfsec
- pylint
- mypy

The TFLINT is using the .tflinh.hcl file to enable to aws linter, as follow

```
plugin "aws" {
  enabled = true
  version = "0.27.0"
  source  = "github.com/terraform-linters/tflint-ruleset-aws"
}
```

Both `tflint` and `tfsec` are executed in the `code analysis` jenkins pipeline stage, warnings will appear in the pipeline output, the pipeline wont break when warnings are detected. Also both tools are installed in the TOOLING_IMAGE docker image, that is the one used by jenkins to run the pipeline.

## Setting up new environment

 For setting up a new environment, please refer to this [link](https://paypal.atlassian.net/wiki/spaces/BTSRE/pages/983595324/Onboarding+a+new+CSoR+environment)

## Release Process
By default, changes merged to `main` are deployed to `internal-dev`. To release changes to higher environments a developer needs to tag `main` and kick off the Jenkins build.

To kick off a release to all higher environments:

```
git co main
git pull
./bin/release.sh
```

The project now uses [semantic versioning](https://semver.org/) (semver) for releases. The release script will:

1. Check for existing semantic version tags (format: X.Y.Z)
2. It will prompt you to choose the type of version increment:
   - **Major version update** (X.0.0): For backwards-incompatible changes
   - **Minor version update** (0.X.0): For backwards-compatible new features
   - **Patch update** (0.0.X): For backwards-compatible bug fixes

For more details on CSoR semantic versioning guidelines, visit our confluence page. [CSoR Versioning Guidelines](https://paypal.atlassian.net/wiki/spaces/BTSRE/pages/2266999535/CSoR+Versioning+Guidelines).

After confirming the new version, the script will tag the latest commit on `main` and kick off the Jenkins pipeline to release the changes to higher environments. As of today, this build will deploy to `internal-qa`, `dev`, `qa`, `sand` and `prod`. When the pipeline reaches the `prod` stage, a change ticket will be created automatically and an UNO notification for change ticket approval will be sent to an engineer who is online of the CloudNX team. Once the change ticket is reviewed and approved, the change ticket will automatically move to the `Implement` state. The Jenkins pipeline will then proceed and complete the production deployment, and accordingly `Close` the change ticket with a Success/Failure result.

### bt-authorize

To run bt-authorize commands, you need to have CSoR Sandbox and CSoR Production LDAP access.
- MyAccess roles - Sandbox: `PP_BT_LDAP_SAND_CSOR_ADMIN`, Production: `PP_BT_LDAP_PROD_CSOR_ADMIN`
- Sandbox and Production deploys require manual authorization using `bt-authorize`. As part of the release pipeline, Jenkins will notify in `#csor-builds` when a build stage is ready to be authorized.
- Follow the link to the Jenkins build
- Review the terraform diff
- Confirm no conflicting operations are in progress
- Run the provided `bt-authorize` command from your laptop to proceed (if you haven’t installed `bt-authorize`, follow the [installation instructions](https://github.com/PayPal-Braintree/jenkins-production-worker#installing-bt-authorize) included in the slack prompt)
- For Sandbox deploys, we use bt-authorize for terraform apply
- For Production deploys, the order of actions are bt-authorize for terraform plan -> confirm diff in pipeline via Jenkins UI -> SNOW ticket -> bt-authorize for terraform apply

After the release is complete, create a new pull request to update the CHANGELOG: move the contents of the `Unreleased` section under the newly created tag, and leave the `Unreleased` section empty. 

List of Approvers: [CloudNX](https://paypal.service-now.com/now/nav/ui/classic/params/target/sys_user_group.do%3Fsys_id%3Df81549bf9720869c901f36be2153af63%26sysparm_view%3Dtext_search) 

Associated CI: [csor_platform](https://paypal.service-now.com/cmdb_ci_sdlc_component.do?sys_id=e868b469c3ad9e14725eabec7a013109&sysparm_record_target=cmdb_ci_sdlc_component&sysparm_record_row=2&sysparm_record_rows=5&sysparm_record_list=sys_created_on%3E%3D2024-10-28+14%3A41%3A50%5Esys_created_by%3Daiswv%5EORDERBYname)

The notification of the deployment request and result will be sent to the #csor-builds slack channel.

## Accessing RDS Cluster

To access the RDS instance in AWS, we will need to utilize a bastion host because the RDS instance is located with a VPC and is not pubicly accessible.

Note: The steps and code below are borrowed heavily from [rds/bin/psql](https://github.braintreeps.com/cosmos/postgres-terraform/blob/fa87090c525b5c7f6710664098cd585b29f5a790/rds/bin/psql) script in [cosmos/postgres-terraform](https://github.braintreeps.com/cosmos/postgres-terraform)

1. Get the AWS CLI credentials for appropriate System of Record account (example: `dev-bt-csor-sor`). The naming convention is `${env}-bt-csor-sor`, where `${env}` one of the following values: `dev`, `qa`, `sand` or `prod`
    * Navigate to https://paypalsso.awsapps.com/start
    * Click the triangle next to the account to display all the roles for the account
    * Next to the role, click the `Access keys` link
    * Copy the environment variables from `Option 1` into your cpair
1. From within your cpair, using AWS CLI, get the endpoint of the RDS cluster
   ```bash
   identifier=cloud-system-of-record-datastore
   remote_pghost=$(aws --region=$region rds describe-db-clusters --db-cluster-identifier=$identifier | jq -cr ".DBClusters | first.Endpoint")
   ```
1. Using AWS CLI, get the master password
   ```bash
   aws --region=$region secretsmanager get-secret-value --secret-id database_password | jq -r '.SecretString'
   ```
1. Create SSH tunnel to bastion host. Find a local port and then create SSH tunnel.
   ```bash
   ephemeral_port_min=41952
   ephemeral_port_max=65535

   # Find the first unused local port in our ephemeral port range
   # to use for port forwarding.
   for local_port in $(seq $ephemeral_port_min $ephemeral_port_max) ; do
     /usr/bin/ss -H -n -t -a \( sport = $local_port \) | grep -q $local_port || break
   done

   /usr/bin/ssh -o ExitOnForwardFailure=yes -f -L ${local_port}:${remote_pghost}:5432 -l ${SSH_USERNAME} bastion-${env}-${region}.dev.braintree-api.com sleep 60
   ```
1. Access RDS instance using `psql`, and provide the password from Step 3
   ```bash
   psql --username=demo_user -h localhost -p ${local_port} -d system_of_records
   ```

## Updating Schema GraphQL and JSON

When you make a change to the GraphQL schema in the `sor/app` folder, please ensure to run the following two commands in the `sor` folder:
```bash
bundle install
bundler exec rails graphql:schema:dump
```
This will ensure that the `schema.graphql` and `schema.json` files are up to date with your changes.

## Contributing

To contribute in this repository, ensure you have access to it. Open a Pull request with your proposed changes, this PR will be reviewed by the @PayPal-Braintree/bt-cloud-infra team

Also ensure that you open you PR following the bellow:

- [Development Standards](https://engineering.paypalcorp.com/confluence/display/Braintree/Simple+Development+Standards) 
- Add the items you changed in your PR to the CHANGELOG.md file


### General Guidelines

- Ensure that you are familiar with the project's objective and architecture before making significant changes.
- Maintain a consistent coding style and follow the conventions adopted by the team.

## Contact

<cloudnx@paypal.com>
