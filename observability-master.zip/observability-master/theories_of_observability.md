# Theories of Observability

I'm noting for posterity here some links I've saved over the years to articles and such that helped form my philosophies on observability/alerting/etc.

* [My Philosophy on Alerting](https://docs.google.com/document/d/199PqyG3UsyXlwieHaqbGiWVa8eMWi8zzAn0YfcApr8Q/edit)
	* This was the first article I read which really started to open my mind to modern thinking on monitoring and alerting. Circa-2014, the author was an SRE at Google and ideas herein ultimately became a chapter in [Site Reliability Engineering: How Google Runs Production Systems](http://shop.oreilly.com/product/0636920041528.do). This was where I first encountered the concept of "symptom-based monitoring." It also puts forth a great concept which I still haven't seen implemented in modern tools which is where you have symptom-based paging which also includes summary lists of currently-firing cause-based monitors.
* [The RED Method: How to Instrument Your Services](https://grafana.com/blog/2018/08/02/the-red-method-how-to-instrument-your-services/)
	* Folks have probably heard me refer to `RED` many times. This is where I picked that up from. A really good short article, with a link to a talk, that briefly summarizes the relatively simple concepts of what key metrics one should always monitor and which should drive the majority of symptom-based alerting.
* [Monitoring and Observability With USE and RED](https://orangematter.solarwinds.com/2017/10/05/monitoring-and-observability-with-use-and-red/)
	* Another good short article about USE and RED methodologies
* [Good and Bad Monitoring](https://raynorelyp.medium.com/good-and-bad-monitoring-9e1370d808c2)
	* Really good article about good patterns and anti-patterns in monitoring, why dashboards aren't always that helpful, and most importantly: why you want your alerts to favor accuracy over precision.
* [How to Monitor the SRE Golden Signals](https://faun.pub/how-to-monitor-the-sre-golden-signals-1391cadc7524)
	* Another one about the "golden signals" with some discussion about averages vs percentiles, anomaly detection, and links to some specific guides for extracting signals from different tools and services.
* [Why Your Server Monitoring (Still) Sucks](https://www.linuxjournal.com/content/why-your-server-monitoring-still-sucks)
	* Mostly a rant, but makes some good points about common challenges in monitoring/observability, such as being too attached to old technologies and being too enamored of new ones.
* [We can do better than percentile latencies](https://medium.com/theburningmonk-com/we-can-do-better-than-percentile-latencies-2257d20c3b39)
	* Interesting article about some weaknesses in percentile latencies but also goes into issues like why one Dashboard to rule them all rarely works, and why if you're going to have dashboards you likely need dashboards designed for different disciplines. The Ops/SRE dashboard likely needs to look different than the Developer's dashboard or the Product Manager's dashboard or the Support person's dashboard.
* [Latency SLOs Done Right](https://www.circonus.com/2018/08/latency-slos-done-right/)
	* Another delve into latencies and SLOs and why histograms are great and we just don't use them enough.
* [Applying HumanOps To On-Call](https://blog.stackpath.com/applying-humanops-to-on-call/)
	* Less about observability directly and more about creating humane on-call processes for humans. But since Observability tends to be the primary source of pages for on-call folks, it's worth thinking about keeping that experience humane.
