# ULP Production On-Call Playbook (Blue)
- [Primary Components](#primary-components)
- [Dashboards and Resources](#dashboards-and-resources)
- [High-level Workflow](#high-level-workflow)
- [Regular Maintenance](#regular-maintenance)
- [Common Issues](#common-issues)
- [Stakeholder Communication](#stakeholder-communication)

## Primary components

### Rsyslog
- Log forwarding agent
- Installed on most (but not all) hosts in Blue
- Requires omkafka output plugin for integration with ULP
- Kafka configuration files:
			https://github.braintreeps.com/braintree/infrastructure/blob/master/modules/rsyslog/manifests/kafka.pp
			https://github.braintreeps.com/braintree/infrastructure/blob/master/modules/rsyslog/templates/kafka.erb

### log-kafka cluster
- Runs Kafka
- Cluster specific to the logging platform
- Owned and operated by Team Streams

### [kafka-log-worker](https://github.braintreeps.com/braintree/kafka-log-worker)
- Kubernetes Deployment
- Runs fluentd
- Consumes from v1_firebhose_raw topic
- Parses logs according to this set of rules
- Produces structured logs to v1_firehose topic
	
### [log-kafka-s3-sink](https://github.braintreeps.com/braintree/log-kafka-s3-sink)
- Kubernetes Deployment
- Runs fluentd
- Consumes from v1_firehose topic
- Uploads logs to bt-structured-logs-{environment} bucket

## Dashboards and Resources

- [Log Kafka](https://app.datadoghq.com/dashboard/p2i-xt8-ke8/log-kafka) Datadog dashboard
- [Structured Log Current vs Historical volume Sumo dashboard](https://service.sumologic.com/ui/#/dashboardv2/WSJzeSuuXHNFHpo56Q7yh4x9eNYu2EMhcfFnEkDU4qtnZ70EGNfJya3Htk2m) (Dashboard link might not work. Location is Library -> Observability)
- [Structured Log Ingestion Latency](https://service.sumologic.com/ui/dashboard.html?k=7POxcSCD198hRtcUgvgS5WmKXnnc3s9wF4eYSZPkq2vUDa0clCeboLPJeGet&f=&t=r) Sumo dashboard

## High-level workflow
Main points of failure are denoted by **bold** text.

- Application and infrastructure hosts **produce logs** to the v1_firehose_raw topic of the log-kafka cluster using the rsyslog omkafka output plugin
- The kafka-log-worker Kubernetes deployment **consumes and processes** these logs into a structured format and **produces** them to the v1_firehose topic of the log-kafka cluster
- The log-kafka-s3-sink Kubernetes deployment **consumes** the logs from the v1_firehose topic and **uploads them to S3** in batches to the bt-structured-logs-{environment} bucket in us-east-1
- S3 replication policy on the bucket **replicates the logs** from the bt-structured-logs-{environment} bucket to the bt-structured-logs-sumo-replica-{environment} bucket
- Object create events on the bt-structured-logs-sumo-replica-{environment} bucket are **published to an SNS topic**, which Sumo is subscribed to and ingests from (primarily)

## Regular Maintenance

### Deploying

Deploying the kafka-log-worker or log-kafka-s3-sink should result in little-to-no end-user impact.  It should be safe to perform this operation at any time without taking special precautions.

The majority of routine updates are deployed through production using the CI/CD pipeline for the given repository ([kafka-log-worker](https://ci.braintree.tools/blue/organizations/jenkins/braintree%2Fkafka-log-worker/activity) | [log-kafka-s3-sink](https://ci.braintree.tools/blue/organizations/jenkins/braintree%2Flog-kafka-s3-sink/activity)).

### Kafka Upgrades

Occasionally, Team Streams may need to upgrade Kafka for the log-kafka cluster.  Generally, this results in no impact to pipeline functioning.  However, in the past we have observed that a few partitions can get stuck after the upgrade, increasing lag.  If this happens after an upgrade, re-deploy the application:

1. Make sure that the Infra repo and the repo you need to re-deploy are both up-to-date
2. Delete the deployment: `kubectl-compile kubernetes/ | kubectl delete -f -`
3. Wait until all pods are terminated
4. Re-deploy the application: `kubectl-compile kubernetes/ | kubectl apply -f -`

### Broker IP change

If one of the log-kafka broker IP addresses changes, we will need to update network policies for both the kafka-log-worker and log-kafka-s3-sink deployments.

In lower environments, we can re-deploy the network policies ourselves:

1. Navigate to the k8s-infrastructure repo
2. Review the network policy diff: `kubectl-compile networkpolicies/[namespace]/network-policy.yaml.erb | kubectl-diff`
3. Apply: `kubectl-compile networkpolicies/[namespace]/network-policy.yaml.erb | kubectl apply -f -`

In production, network policies can only be applied by someone with Prod k8s access.  Seek assistance from the appropriate team.

## Common Issues

### Host(s) can't connect to log-kafka cluster

In some cases, a host may lose connectivity to the log-kafka cluster, preventing rsyslog from being able to produce messages to the v1_firehose_raw topic.

If there is a widespread networking issue with the log-kafka cluster, this will likely manifest as a significant drop in volume to the v1_firehose_raw topic, which will be reflected on the "Messages In" graph of the [Log Kafka dashboard](https://app.datadoghq.com/dashboard/p2i-xt8-ke8/log-kafka).

Otherwise, we have [monitoring](https://app.datadoghq.com/monitors/17822214) set up to detect when individual hosts cannot connect to log-kafka.  In these cases, use the below steps to diagnose whether there is a networking issue and temporarily disable forwarding logs to the ULP until the networking issue is resolved. (NOTE: we'll need to figure how we'd do this when everything is cutover to the new pipeline.  Maybe we could have a way of sending them via the log-relay hosts?)

#### Rsyslog unable to communicate with kafka ####

The datadog monitor is doing a TCP connect to the designated log-kafka brokers on the designated port, so if the monitor indicates connections are failing that is a fairly definitive test. But you can look at the rsyslog config on the host (/etc/rsyslog.d/03-kafka on blue hosts) to see what hosts/ports are defined there and do standard network connectivity troubleshooting from the host. Depending on the problem, assistance may be needed from infra, k8s, networking, or kafka teams.

To disable writing to kafka for a given host:

1. Update hiera yaml file for that host to specify: `rsyslog::use_kafka: false`
2. Puppet the host

Obviously that means logs for that host are not being collected, so steps should be taken to resolve the connectivity issue and re-enable writing to kafka from that host as quickly as possible.

### Rsyslog gets stuck and stops forwarding logs to log-kafka

We have experienced a few cases where rsyslog appears to hang and stop forwarding logs to log-kafka. Most often it is because rsyslog is unable to communicate with the log-kafka brokers as per above. This condition can often be detected when log files are not properly rotated, which we have monitors set up to alert on.

These issues are usually resolved by restarting the rsyslog process on the host where it is stuck: `sudo systemctl restart rsyslog`

It will take a minute or so to restart because systemd will be forced to kill -9 the process as it won't respond to a clean shutdown or reload signals.

### Lag building on one or more partitions

If lag builds on a topic partition, this will result in some logs being delayed.  Because messages are assigned to topics randomly, there is no way of knowing which subset of logs is affected.  Lag will be apparent by reviewing the Raw->Structured Consumers or Structured->S3 Consumers section of the [Log Kafka dashboard](https://app.datadoghq.com/dashboard/p2i-xt8-ke8/log-kafka). 

If one or more partitions appears to be lagging behind the rest, troubleshooting will be needed to determine why some partitions aren't keeping up. If *all* partitions are increasing in lag that suggests there is a problem with the whole kafka-log-worker or log-kafka-s3-sink deployment, depending on which consumer group's lag is increasing. If only some partitions are increasing in lag, typically so far that has indicated insufficient resources in the deployment to keep up with all the partitions. Increasing the replica count of the deployment and re-deploying has alleviated that condition so far. Note that the number of partitions (currently 50 in prod environments) represents the logical maximum number of replicas that can perform work. Any replicas beyond that won't be able to acquire a partition to consume. There could be many other reasons why workers are not able to keep up though, such as a fluentd configuration change causing a drastic increase in CPU required for log parsing, a significant increase in total log volume, insufficient CPU or memory resources on the kubernetes cluster, etc.

#### Re-deploying kafka-log-worker

1. Make sure that the Infra repo and the kafka-log-worker repo are both up-to-date

2. Delete the deployment: `kubectl-compile kubernetes/ | kubectl delete -f -`

3. Wait until all pods are terminated

4. Re-deploy the application: `kubectl-compile kubernetes/ | kubectl apply -f -`

5. Review the Raw->Structured Consumers section of the Log Kafka dashboard to see if lag on the offending partitions begins to decrease.  Note: this may take several minutes to be reflected in the graphs.

#### Re-deploying log-kafka-s3-sink

1. Make sure that the Infra repo and the log-kafka-s3-sink repo are both up-to-date

2. Delete the deployment: `kubectl-compile kubernetes/ | kubectl delete -f -`

3. Wait until all pods are terminated

4. Re-deploy the application: `kubectl-compile kubernetes/ | kubectl apply -f -`

5. Review the Structured->S3 Consumers section of the Log Kafka dashboard to see if lag on the offending partitions begins to decrease.  Note, this may take several minutes to be reflected in the graphs.

### Output buffers growing

If data cannot be successfully flushed to the given output destination, the output buffers will begin to fill up.  Because the data has already been consumed from Kafka (and offsets committed) by the time it reaches the output buffers, data loss is possible if the buffered data cannot ultimately be flushed successfully.  We utilize retry logic to retry failed flush attempts automatically, which is usually sufficient to cover transient connection issues or temporal errors.

While fluentd will attempt to flush buffers when sent a graceful shutdown signal, we have observed that this does not always happen and it is possible for data to be lost.  Given this risk, it is important to address growing buffers in a timely manner.

The current size of the output buffers can be found on the Output Buffers (total bytes) panel of the [Log Kafka dashboard](https://app.datadoghq.com/dashboard/p2i-xt8-ke8/log-kafka) for each of the main Kubernetes Deployments.

1. Determine if the underlying issue is on-going

	This will require some investigation and troubleshooting.  Review the deployment's logs for any specific indications for the source of the problem.  Common reasons for buffers filling are listed below for each deployment:
	
	- kafka-log-worker
		- Networking issues preventing producing to the v1_firehose topic
		- log-kafka cluster health
			- Review Cluster section of the [Log Kafka dashboard](https://app.datadoghq.com/dashboard/p2i-xt8-ke8/log-kafka)
	- log-kafka-s3-sink
		- Internetproxy issues
  			- Review [internetproxy logs for errors](https://service.sumologic.com/ui/#/library/folder/15197616/17290505)
		- S3 issues
  			- Review S3 metrics on the [Log Kafka dashboard](https://app.datadoghq.com/dashboard/p2i-xt8-ke8/log-kafka) for 4xx or 5xx errors
  			- Ensure that Deployment secrets are using expected AWS credentials
				1. Run `kubectl describe deployment log-kafka-s3-sink`
				2. Ensure that AWS_ACCESS_KEY and AWS_SECRET_KEY are populated from the `secrets-vault` secret
	
	If so, fix the underlying problem or coordinate with the appropriate team for help resolving.  Once the root cause is addressed, retry logic should automatically handle flush attempts.  Verify that the buffers decrease in size and operation has returned to normal.

2. Force flush buffers

	If there are no on-going issues but buffers are still growing, it may be necessary to force the buffers to flush. Be aware: the below operations may result in data loss!
	
	- Only a few impacted pods?
		- Delete the bad pods and wait for their replacement: `kubectl delete pods [pod]`
	- Many pods impacted?
		- Delete the deployment and re-apply:
			1. Make sure that the Infra repo and the repo you need to re-deploy are both up-to-date
			2. Delete the deployment: `kubectl-compile kubernetes/ | kubectl delete -f -`
			3. Wait until all pods are terminated
			4. Re-deploy the application: `kubectl-compile kubernetes/ | kubectl apply -f -`

### Consumer group stuck in a rebalance loop

This is visible in the container logs as repeated messages about joining the consumer group.  These conditions will also be indicated on the [Log Kafka dashboard](https://app.datadoghq.com/dashboard/p2i-xt8-ke8/log-kafka) by missing (NO DATA) lag data.  

On a kafkautilNN.{env} host you can run the following commands to get the state of the consumer group (as far as Kafka is concerned).

Get basic consumer group state:
`kcg -g [group] --cluster log -- --describe --state`

Get partition assignments:
`kcg -d -g [group] --cluster log`

Typically rebalances should resolve themselves within 5-10 minutes. If they don't it could represent a configuration problem in the deployment, or on the log-kafka brokers, or some new problem we have not encountered.  Try the following debugging steps:

1. Delete the deployment, wait 5 minutes, then deploy again
2. Delete a pod to trigger a rebalance
3. If the above attempts don't work, assistance from Team Streams may be required

### Logs not flowing into Sumo or arriving late

We have several monitors set up to detect these scenarios proactively, however it may still be possible that Incident Management or another stakeholder reports a problem about log delivery into Sumo.

1. Review the following Sumo dashboards for any abberations in volume or ingest latency
    - [Structured Log Current vs Historical volume Sumo dashboard](https://service.sumologic.com/ui/#/dashboardv2/WSJzeSuuXHNFHpo56Q7yh4x9eNYu2EMhcfFnEkDU4qtnZ70EGNfJya3Htk2m) (Dashboard link might not work. Location is Library -> Observability)
    - [Structured Log Ingestion Latency](https://service.sumologic.com/ui/dashboard.html?k=7POxcSCD198hRtcUgvgS5WmKXnnc3s9wF4eYSZPkq2vUDa0clCeboLPJeGet&f=&t=r)

2. Review the Log Kafka dashboard for any obvious signs of pipeline problems (throughput to a topic decreased, increase in lag for a consumer group, issues writing to S3, etc)

3. Check S3 replication metrics for signs of replication-based delays
	- Navigate to the bt-structured-logs-{environment} bucket in the S3 AWS Console
	- Go to the Management -> Metrics -> Replication tab to see if replication latency or any other relevant metrics look substantially increased
	- If so, file a ticket with AWS support.  Otherwise, there is nothing we can do until the issue is resolved on the AWS side

4. If all other pipeline stages prior to hitting Sumo appear to be operating normally, file a support ticket with Sumo Logic.  It is possible there may be ingest delays or problems on their side.

### Resetting consumer group offsets to latest.

In an unfortunate and unexpected situation, we may need to make a decision to forgo transporting older logs through the pipeline in order to process more recently created logs. The following procedure will accomplish this by setting the kafka-log-worker consumer group offset to its latest value.

*WARNING* Performing the following steps _will_ result in lost logs - the amount of logs lost will be equal to the consumer group lag on each partition at the time the pods are recreated and the consumer group finishes rebalancing.

1. rekube into the kafka-log-worker namespace and ssh into the kafkautil box for the environment you are working in.
2. Delete the deployment; once all pods terminate, confirm that the KLW consumer group is empty by running `bt-kafka-consumer-groups --cluster log -g v1_firehose_raw_k8s_${DATACENTER}_consumers -d` on the kafkautil box.
3. Run `bt-kafka-consumer-groups --cluster log -- --delete --group v1_firehose_raw_k8s_${DATACENTER}_consumers`
4. Apply the kafka-log-worker deployment and confirm that the consumer group rebalances, and that lag metrics reset to near zero.

## Stakeholder Communication

If you believe that the problem you're investigating could potentially impact Paymentus support operations (for example, critical log categories are missing or significantly delayed), page Incident Management using the `@page-ic` handle in the [#incident-management](https://braintree.slack.com/archives/C8RH8N8TE) Slack channel, explaining the problem and expected impact.
