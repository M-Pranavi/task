# Phased migration to the Unified Logging Pipeline

This runbook describes how to migrate one or more tags from the current structured logging pipeline to the new Unified Logging Pipeline.

## Specific tags

The following section describes how to cutover or rollback a list of individually-specified tags.

### Cutover

#### QA

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-qa`
3.  Add chosen log tags to `log_kafka_s3_sink::tags_to_forward` in `data/domains/qa.braintreepayments.com/common.yaml` in infrastructure repo. 
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.qa puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..3}.qa puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.
8.  Commit infra repo changes and push.

#### QA2

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date. 
2.  `kubectx blue-qa2`
3.  Add chosen log tags to `log_kafka_s3_sink::tags_to_forward` in `data/domains/qa2.braintreepayments.com/common.yaml` in infrastructure repo. 
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.qa2 puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..3}.qa2 puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.
8.  Commit infra repo changes and push.

#### STQ

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date. 
2.  `kubectx blue-stq`
3.  Add chosen log tags to `log_kafka_s3_sink::tags_to_forward` in `data/domains/stq.braintreepayments.com/common.yaml` in infrastructure repo. 
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.stq puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..3}.stq puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.
8.  Commit infra repo changes and push.

#### STC

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-stc`
3.  Add chosen log tags to `log_kafka_s3_sink::tags_to_forward` in `data/domains/stc.braintreepayments.com/common.yaml` in infrastructure repo. 
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.stc puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..3}.stc puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.
8.  Commit infra repo changes and push.

#### Sandbox

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-sand`
3.  Add chosen log tags to `log_kafka_s3_sink::tags_to_forward` in `data/domains/sand.braintreepayments.com/common.yaml` in infrastructure repo. 
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.sand puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..5}.sand puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.  Use this [Sumo query](https://service.sumologic.com/ui/#/search/@1595284948734,1595285848734@(*%20or%20_index%3Dtier_*)%20%20app_name%3Dmyapp%20environment%3Denv%0A%7C%20json%20%22processed_by%22%0A%7C%20parse%20field%3Dprocessed_by%20%22*-worker*%22%20as%20worker%2C%20therest%0A%7C%20timeslice%201m%0A%7C%20count%20by%20_timeslice%2C%20worker%0A%7C%20transpose%20row%20_timeslice%20column%20worker) to verify that the S3 source has switched as-expected.
8.  Commit infra repo changes and push.

#### QWT

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-qwt`
3.  Add chosen log tags to `log_kafka_s3_sink::tags_to_forward` in `data/domains/qwt.braintreepayments.com/common.yaml` in infrastructure repo. 
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.qwt puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..9}.qwt puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.  Use this [Sumo query](https://service.sumologic.com/ui/#/search/@1595284948734,1595285848734@(*%20or%20_index%3Dtier_*)%20%20app_name%3Dmyapp%20environment%3Denv%0A%7C%20json%20%22processed_by%22%0A%7C%20parse%20field%3Dprocessed_by%20%22*-worker*%22%20as%20worker%2C%20therest%0A%7C%20timeslice%201m%0A%7C%20count%20by%20_timeslice%2C%20worker%0A%7C%20transpose%20row%20_timeslice%20column%20worker) to verify that the S3 source has switched as-expected.
8.  Commit infra repo changes and push.

#### SAV

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-sav`
3.  Add chosen log tags to `log_kafka_s3_sink::tags_to_forward` in `data/domains/sav.braintreepayments.com/common.yaml` in infrastructure repo. 
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.sav puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..9}.sav puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.  Use this [Sumo query](https://service.sumologic.com/ui/#/search/@1595284948734,1595285848734@(*%20or%20_index%3Dtier_*)%20%20app_name%3Dmyapp%20environment%3Denv%0A%7C%20json%20%22processed_by%22%0A%7C%20parse%20field%3Dprocessed_by%20%22*-worker*%22%20as%20worker%2C%20therest%0A%7C%20timeslice%201m%0A%7C%20count%20by%20_timeslice%2C%20worker%0A%7C%20transpose%20row%20_timeslice%20column%20worker) to verify that the S3 source has switched as-expected.
8.  Commit infra repo changes and push.

### Rollback

The rollback procedure is essentially a simple reversal of the cutover steps:

1.  `kubectx {context}`
2.  Remove `log_kafka_s3_sink::tags_to_forward` additions from `data/domains/{domain}/common.yaml`
3.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.{domain} puppet:noop` in the environment to check the log-worker diff.
4.  Puppet log-workers: `GROUP_SIZE=3 cap {host list} puppet:apply_server_by_server WITHOUT_PROMPTS=true`
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -`  on log-kafka-s3-sink pane 
6.  Ensure chosen log source objects are being created in S3, with log-worker in the object name instead of log-kafka-s3-sink – ensure that objects with log-kafka-s3-sink in object name are not being created.
7.  Commit infra repo changes and push.

## All tags (entire environment)

The following section describes how to cutover or rollback all tags for a given domain.

### Cutover

#### QA

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-qa`
3.  Delete `log_kafka_s3_sink::tags_to_forward` Hiera value in `data/domains/qa.braintreepayments.com/common.yaml` (or potentially in `data/environemnts/qa/common.yaml`) in the  infrastructure repo.  At the same time, set `td_agent::s3_enabled: false` in `data/domains/qa.braintreepayments.com/log-worker.yaml` to stop log-workers from uploading to S3.  Note: the log-workers will continue to upload logs to log-storage.
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.qa puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..3}.qa puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.
8.  Commit infra repo changes and push.

#### QA2

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-qa2`
3.  Delete `log_kafka_s3_sink::tags_to_forward` Hiera value in `data/domains/qa2.braintreepayments.com/common.yaml` (or potentially in `data/environemnts/qa/common.yaml`) in the  infrastructure repo.  At the same time, set `td_agent::s3_enabled: false` in `data/domains/qa2.braintreepayments.com/log-worker.yaml` to stop log-workers from uploading to S3.  Note: the log-workers will continue to upload logs to log-storage.
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.qa2 puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..3}.qa2 puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created.
8.  Commit infra repo changes and push.

#### Sandbox

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  `kubectx blue-sand`
3.  Delete `log_kafka_s3_sink::tags_to_forward` Hiera value in `data/domains/sand.braintreepayments.com/common.yaml` (or potentially in `data/environemnts/sandbox/common.yaml`) in the  infrastructure repo.  At the same time, set `td_agent::s3_enabled: false` in `data/domains/sand.braintreepayments.com/log-worker.yaml` to stop log-workers from uploading to S3.  Note: the log-workers will continue to upload logs to log-storage.
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.sand puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..5}.sand puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created. Use this [Sumo query](https://service.sumologic.com/ui/#/search/@1595284948734,1595285848734@(*%20or%20_index%3Dtier_*)%20%20app_name%3Dmyapp%20environment%3Denv%0A%7C%20json%20%22processed_by%22%0A%7C%20parse%20field%3Dprocessed_by%20%22*-worker*%22%20as%20worker%2C%20therest%0A%7C%20timeslice%201m%0A%7C%20count%20by%20_timeslice%2C%20worker%0A%7C%20transpose%20row%20_timeslice%20column%20worker) to verify that the S3 source has switched as-expected.
8.  Commit infra repo changes and push.

#### QWT

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  Update hiera value in `data/domains/qwt.braintreepayments.com/common.yaml`: `juniper_switches::syslog_host: "%{hiera('log-relay01_vlan4000_ip')}"` and commit
2.  `kubectx blue-qwt`
3.  Delete `log_kafka_s3_sink::tags_to_forward` Hiera value in `data/domains/qwt.braintreepayments.com/common.yaml` (or potentially in `data/environemnts/production/common.yaml`) in the  infrastructure repo.  At the same time, set `td_agent::s3_enabled: false` in `data/domains/qwt.braintreepayments.com/log-worker.yaml` to stop log-workers from uploading to S3.  Note: the log-workers will continue to upload logs to log-storage.
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.qwt puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Have network admins run rake task to update syslog target for network gear
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..9}.qwt puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created. Use this [Sumo query](https://service.sumologic.com/ui/#/search/@1595284948734,1595285848734@(*%20or%20_index%3Dtier_*)%20%20app_name%3Dmyapp%20environment%3Denv%0A%7C%20json%20%22processed_by%22%0A%7C%20parse%20field%3Dprocessed_by%20%22*-worker*%22%20as%20worker%2C%20therest%0A%7C%20timeslice%201m%0A%7C%20count%20by%20_timeslice%2C%20worker%0A%7C%20transpose%20row%20_timeslice%20column%20worker) to verify that the S3 source has switched as-expected.
8.  Commit infra repo changes and push.

#### SAV

1.  Ensure infrastructure and log-kafka-s3-sink repos are up-to-date.
2.  Update hiera value in `data/domains/sav.braintreepayments.com/common.yaml`: `juniper_switches::syslog_host: "%{hiera('log-relay01_vlan4000_ip')}"` and commit
2.  `kubectx blue-sav`
3.  Delete `log_kafka_s3_sink::tags_to_forward` Hiera value in `data/domains/sav.braintreepayments.com/common.yaml` (or potentially in `data/environemnts/production/common.yaml`) in the  infrastructure repo.  At the same time, set `td_agent::s3_enabled: false` in `data/domains/sav.braintreepayments.com/log-worker.yaml` to stop log-workers from uploading to S3.  Note: the log-workers will continue to upload logs to log-storage.
4.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.sav puppet:noop` in the environment to check the log-worker diff.
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -` on log-kafka-s3-sink pane. Note the time, as duplicates will exist from this point until the change has been applied to the log-workers.
6.  Have network admins run rake task to update syslog target for network gear
6.  Puppet log-workers: `GROUP_SIZE=3 cap log-worker0{1..9}.sav puppet:apply_server_by_server WITHOUT_PROMPTS=true`
7.  Ensure chosen log source objects are being created in S3, with log-kafka-s3-sink in the object name instead of log-worker – ensure that objects with log-worker in object name are not being created. Use this [Sumo query](https://service.sumologic.com/ui/#/search/@1595284948734,1595285848734@(*%20or%20_index%3Dtier_*)%20%20app_name%3Dmyapp%20environment%3Denv%0A%7C%20json%20%22processed_by%22%0A%7C%20parse%20field%3Dprocessed_by%20%22*-worker*%22%20as%20worker%2C%20therest%0A%7C%20timeslice%201m%0A%7C%20count%20by%20_timeslice%2C%20worker%0A%7C%20transpose%20row%20_timeslice%20column%20worker) to verify that the S3 source has switched as-expected.
8.  Commit infra repo changes and push.

### Rollback

The rollback procedure is essentially a simple reversal of the cutover steps:

1.  `kubectx {context}`
2.  Revert `log_kafka_s3_sink::tags_to_forward` changes in `data/domains/{domain}/common.yaml` and restore `td_agent::s3_enabled: true` value in `data/domains/{domain}/log-worker.yaml`.
3.  Run `kubectl-compile kubernetes/ | kubectl-diff` on the log-kafka-s3-sink pane and ensure diff is expected. Run `cap log-worker01.{domain} puppet:noop` in the environment to check the log-worker diff.
4.  Puppet log-workers: `GROUP_SIZE=3 cap {host list} puppet:apply_server_by_server WITHOUT_PROMPTS=true`
5.  Run `kubectl-compile kubernetes/ | kubectl apply -f -`  on log-kafka-s3-sink pane 
6.  Ensure chosen log source objects are being created in S3, with log-worker in the object name instead of log-kafka-s3-sink – ensure that objects with log-kafka-s3-sink in object name are not being created.
7.  Commit infra repo changes and push.
