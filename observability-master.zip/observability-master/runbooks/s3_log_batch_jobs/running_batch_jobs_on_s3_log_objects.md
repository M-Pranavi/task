### Background

In early April 2020, we discovered that our structured cosmos log buckets were not set up to have objects 
encrypted by default. We switched this setting to use a customer managed KMS key to encrypt all newly
created objects. However, this left many millions of objects unencrypted in the structured log
buckets. We used s3 batch jobs to recreate these objects via PUT Copy action, which encrypted them due
to the new default setting. Documenting all that went into this process here, in case we ever need to perform
a similar operation again. 


### Setup

There were a few requirements that we needed to set up before we could run a batch job to encrypt these objects. 

## Inventories

 Needed to generate inventories on each structured log bucket, to identify and separate the unencrypted objects
from the ones being default encrypted with KMS.

This required additional configuration in [aws-account-terraform](https://github.braintreeps.com/cosmos/aws-account-terraform/blob/main/region-specific/system_logging.tf#L308-L374) and a new bucket policy to be applied. It also requires a destination bucket where the inventories will be placed after being generated.  

## Identifying unencrypted records. 

The inventories generated above contain a column with encryption information about each s3 object in the structured logs bucket. We can use the inventory to create
a CSV that the s3 batch job can use as a manifest. 

[This script](https://github.braintreeps.com/braintree/observability/blob/master/s3_bucket_inventories/bucket_encryption.sh) in the Observability repo pulls down the inventory from each region, concatenates the data, looks for `NOT-SSE` in the encryption status column (identifying the record as unencrypted,) and writes these objects out to a CSV that can be used by the s3 batch job. It then pushes the generated CSV to the inventory bucket in each region.  

## IAM Permissions

In order for a batch job to successfully operate on the structured log objects, several IAM changes needed to be applied in each account.

First, create a new IAM role that the s3 batch job service can assume_role into. 
https://github.braintreeps.com/cosmos/aws-account-terraform/blob/main/roles.tf#L681-L700

Second, the key policy for the KMS key used to encrypt the structured log bucket must include a statement allowing 
kms:GenerateDataKey and kms:Decrypt actions. 
https://github.braintreeps.com/cosmos/aws-account-terraform/blob/main/region-specific/system_logging.tf#L75-L88

Lastly, the newly created role must be assigned the correct actions to pull from the bucket where inventories are being generated, the source bucket, and
the target bucket. 
https://github.braintreeps.com/cosmos/aws-account-terraform/blob/main/roles.tf#L645-L679

### Creating and running the batch jobs. 

Log into the account where you would like to create the new batch job. Navigate to the s3 service, and locate the `Batch Operations` link
on the left menu. Select `Create Job.`

Select the region where you would like to create the job. For purposes of example, let's select ap-south-1.

Under `Manifest Format,` select CSV, and then select the CSV uploaded by script earlier. In this example, we'd supply the path `s3://cosmos-log-inventories-production-ap-south-1/cosmos-structured-logs-production-ap-south-1/cosmos-structured-logs-production-ap-south-1-inventory/cosmos-structured-logs-production-ap-south-1-unencrypted-objects-fixed.csv`  

![Batch Image 1](./images/Batch_Image_1.png)

On the next page, select the `Copy` operation type. Select the destination structured log bucket as the copy destination. In this example, we'd use `s3://cosmos-structured-logs-production-ap-south-1`
Keep all remaining settings on this page the same, and select `Next.`

![Batch_Image_2](./images/Batch_Image_2.png)

Adjust the batch job name and priority as you see fit. It is recommended to generate a completion report and select a s3 path for it to be created once the job has finished running. Then, select the IAM role you created earlier. Hit Next, and review that all details are correct before creating the job. 

![Batch_Image_3](./images/Batch_Image_3.png)

Once the job has finished `Preparing,` you can confirm that you wish to run it by selecting it and hitting the `Run Job` button. 

You'll then be able to view the job's status, completion percentage, and failure rate in the main s3 batch job UI. There is a region
drop-down to switch between jobs running in different regions. 


### Batch deleting objects

Per [DTRTSVCS-111](https://engineering.paypalcorp.com/jira/browse/DTRTSVCS-111) and [DTRTSVCS-189](https://engineering.paypalcorp.com/jira/browse/DTRTSVCS-189), unencrypted objects ("NON-SSE") were copied to an archive s3 bucket, e.g. `s3://archived-cosmos-structured-logs-production-us-east-1`, then deleted from the original s3 bucket, e.g. `s3://cosmos-structured-logs-production-us-east-1`.

This section documents reproducing the deletion efforts and verifying the current inventory contains no "NON-SSE" data.

#### Tagging
Follow the above steps for creating and running the batch jobs, providing the following substitutions:

1. Instead of `Copy`, choose `Replace all object tags`
2. Add an appropriate Key/Value. I used `DTRTSVCS-189-deletion` and `true`

#### Effective Deletion

Once your objects have been tagged,
it's time to create a [lifecycle rule](https://docs.aws.amazon.com/AmazonS3/latest/user-guide/create-lifecycle.html) targeting the custom object tag.

1. Enter a "Lifecycle rule name"
2. Select the radio button "Limit the scope of this rule using one or more filters"
3. Add the object tag you previously used; `DTRTSVCS-189-deletion` with value `true` in the example

![Lifecycle_rule_Image_1](./images/Lifecycle_rule_Image_1.png)

4. Select "Expire current versions of object"
5. Select "Permanently delete previous versions of objects"
6. Set "Number of days after object creation" to 1
7. Set "Number of days after objects become previous versions" to 1
8. Click "Create rule"

![Lifecycle_rule_Image_2](./images/Lifecycle_rule_Image_2.png)
