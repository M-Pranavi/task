# observability-scratchpad
Scratchpad / scripts for the Observability team
