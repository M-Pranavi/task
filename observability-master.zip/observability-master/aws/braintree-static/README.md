This is a downloaded copy of the contents of the braintree-static S3 bucket in the braintree-opseng AWS account

It was being served via a cloudfront distribution as a publicly-available static website, for making certain image files available for nagios alert emails, statuspage site logos, etc

Since the braintree-opseng account is being shut down, saving them here for posterity

