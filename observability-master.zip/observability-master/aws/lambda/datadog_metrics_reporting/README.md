# AWS Lambda function for Datadog metrics reporting
This Lambda function queries Datadog's `/metrics` API endpoint to get the list of actively reporting metrics and then
POSTs back to Datadog's API as the metric name `datadog.active_metrics.1h.count`.

## Installation
Clone this repo. Ensure you have the following dependencies installed:
* Python3
* Pip3

From this directory, run the following commands to add the required package dependencies:
```
cd package
pip3 install datadog --target .
```
Then compress the contents of the `package` directory:
```
zip -r9 ../function.zip .
```
Now go back to the root directory and add the function code to the archive:
```
cd ..
zip -g function.zip function.py
```
Now you can update the function code with the newly packaged archive:
```
aws --profile opseng lambda update-function-code --function-name datadogMetricsReport --zip-file fileb://function.zip
```
#### NOTE: The above command assumes that you've used `aws configure --profile opseng` to setup your AWS API key/secret

## Lambda Execution
The lambda is configured under the `braintree-opseng` account. It is triggered hourly by the Cloudwatch Rule: `report-hourly-dd-metric-count`.
