#!/usr/bin/env python3

from datadog import initialize, api
import os
import time

options = {
        'api_key': os.environ['API_KEY'],
        'app_key': os.environ['APP_KEY']
        }

initialize(**options)

def lambda_handler(event, context):
    metric_name = 'datadog.active_metrics.1hr.count'
    from_time = int(time.time()) - 60 * 60 * 1

    result = api.Metric.list(from_time)
    active_metrics = int(len(result['metrics']))

    now = time.time()
    api.Metric.send(metric=metric_name, points=(now, active_metrics), host='aws_lambda', tags=[("region:%s" % os.environ['AWS_REGION'])])

    return "Active metrics for the past 60 minutes: %s" % active_metrics
