import boto3
import json
import logging
import os
import hashlib
import hmac
import httplib

from base64 import b64decode
from urlparse import parse_qs


slack_signing_secret = os.environ['slack_secret']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

notify_sendgrid_body = json.dumps(
{
  "personalizations": [
    {
      "to": [
        {
          "email": "no-reply@getbraintree.com"
        },
          ],
      "bcc": [
        {
          "email": "early-incident-notify@getbraintree.com"
        }
          ],
      "subject": "Early Incident Notify Test"
    }
  ],
  "from": {
    "email": "no-reply@getbraintree.com"
  },
  "template_id": "d-e977bfd88b6e4f64aa678b6fd178da2b"
}
)

resolve_sendgrid_body = json.dumps(
{
  "personalizations": [
    {
      "to": [
        {
          "email": "no-reply@getbraintree.com"
        },
          ],
      "bcc": [
        {
          "email": "early-incident-notify@getbraintree.com"
        }
          ],
      "subject": "Early Incident Notify Test"
    }
  ],
  "from": {
    "email": "no-reply@getbraintree.com"
  },
  "template_id": "d-e977bfd88b6e4f64aa678b6fd178da2b"
}
)

def confirm_sendgrid_email(sendgrid_request_body, response_text=None):
    print sendgrid_request_body
    print response_text
    return respond(None, "In confirm_sendgrid_email")
    logger.info("Sending Sendgrid API call")
    sendgrid_api_key = os.environ['sendgrid_api_key']
    sendgrid_connection = httplib.HTTPSConnection("api.sendgrid.com", 443)
    headers = {"Content-Type": "application/json", "Authorization": ("Bearer " + sendgrid_api_key) }
    sendgrid_connection.request("POST", "/v3/mail/send", sendgrid_request_body, headers)
    response = sendgrid_connection.getresponse()
    print response.status
    return respond(None, "Investigation email has been sent.")


def respond(err, res=None):
    return {
        'statusCode': '200',
        'body': err.message if err else json.dumps(res),
        'headers': {
            'Content-Type': 'application/json',
        },
    }


def lambda_handler(event, context):
    params = parse_qs(event['body'])
    headers = event['headers']
    print event
    print params
    print headers
    timestamp = headers['X-Slack-Request-Timestamp']
    print timestamp

    sig_basestring = 'v0:' + timestamp + ':' + event['body']

    print sig_basestring

    slack_signature_digest = 'v0=' + hmac.new(
           slack_signing_secret,
           msg=sig_basestring,
           digestmod=hashlib.sha256
        ).hexdigest()

    request_signature_digest = headers['X-Slack-Signature']

    print slack_signature_digest
    print request_signature_digest

    if hmac.compare_digest(unicode(slack_signature_digest), unicode(request_signature_digest)):

        if 'payload' in params:
            payload = params['payload']
            parsed_payload = json.loads(payload[0])

            logger.error(parsed_payload)
            user_id = parsed_payload['user']['id']
            confirm_yn = parsed_payload['actions'][0]['value']
            callback_id = parsed_payload['callback_id']

            if 'custom_text' in params:
                pass
            else:
                custom_email_text = None

            print callback_id
            if confirm_yn == 'no':
                return respond(None, "Canceling... Email will not be sent.")


        #user = params['user_name'][0]
        #user_id = params['user_id'][0]
        #command = params['command'][0]
        #channel = params['channel_name'][0]
        #command = params['command'][0]




        if user_id not in ['W8GSP3YRZ',
                           'W6BE40JNB',
                           'W9NJUS8TT',
                           'W3XT402GK',
                           'W3X8BMANL',
                           'W3XT5MZDZ',
                           'W3YKNFGB0',
                           'W3XT286R1',
                           'W58TC58CA']:
            logger.error("Unauthorized user")
            return respond(Exception('User is not authorized to use this command.'))


        print callback_id
        if callback_id == 'confirm_notify_action':
            return confirm_sendgrid_email(notify_sendgrid_body, response_text=custom_email_text)
        elif callback_id == 'confirm_resolve_action':
            return confirm_sendgrid_email(resolve_sendgrid_body, response_text=custom_email_text)
        else:
            logger.error("ERROR: Unknown callback_id")
            return respond(Exception('Malformed request error'))

    else:
        logger.error("Request signature does not match expected signature.")
        return respond(Exception('Invalid request token'))
