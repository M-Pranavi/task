import boto3
import json
import logging
import os
import hashlib
import hmac
import httplib

from base64 import b64decode
from urlparse import parse_qs


slack_signing_secret = os.environ['slack_secret']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

initial_button_response_json = {
    "response_type": "in_channel",
    "text": "Send an incident notification to top merchants?",
    "attachments": [
        {
            "fallback": "An error occurred. Not sending notification...",
            "callback_id": "confirm_notify_action",
            "color": "#3AA3E3",
            "attachment_type": "default",
            "actions": [
                {
                    "name": "yes",
                    "text": "Yes",
                    "type": "button",
                    "value": "yes",
                    "style": "primary",
                    "confirm": {
                      "title": "Are you sure?",
                      "text": "Clicking yes will send an email notification to our top merchants.",
                      "ok_text": "Yes",
                      "dismiss_text": "No"
                    }
                },
                {
                    "name": "no",
                    "text": "No",
                    "type": "button",
                    "value": "no",
                    "style": "danger"
                }
            ]
        }
    ]
}


def respond(err, res=None):
    print err
    print json.dumps(res)
    response = {
        'statusCode': '200',
        'body': err.message if err else json.dumps(res),
        'headers': {
            'Content-Type': 'application/json',
        },
    }
    print response
    return response


def handle_ic_notification(slack_command, params):
    if 'user_id' in params:
        user_id = params['user_id'][0]
        callback_id = None

    custom_email_text = None
    if 'text' in params:
        custom_email_text = params['text'][0]
        if len(custom_email_text) > 180:
            return respond(None, "Submitted email text is too long. Please submit a message less than 180 characters")

    if 'payload' in params:
        payload = params['payload']
        parsed_payload = json.loads(payload[0])

        logger.error(parsed_payload)
        user_id = parsed_payload['user']['id']
        confirm_yn = parsed_payload['actions'][0]['value']
        callback_id = parsed_payload['callback_id']

        print callback_id
        if confirm_yn == 'no':
            return respond(None, "Canceling... Email will not be sent.")


    if user_id not in ['W8GSP3YRZ', 'W6BE40JNB', 'W9NJUS8TT', 'W3XT402GK','W3X8BMANL','W3XT5MZDZ','W3YKNFGB0','W3XT286R1', 'W58TC58CA']:
        logger.error("Unauthorized user")
        return respond(Exception('User is not authorized to use this command.'))

    if slack_command == "/notify-investigation":
        print slack_command
        return respond(None, res=initial_button_response_json)
    elif slack_command == "/notify-resolved":
        if custom_email_text:
            initial_button_response_json['text'] = "Insert the following text to our resolution template and send to top merchants? - " + custom_email_text
        else:
            initial_button_response_json['text'] = "You are about to notify merchants that an incident was not detected. Is this correct? Y/N"

        initial_button_response_json['attachments'][0]['callback_id'] = "confirm_resolve_action"
        return respond(None, res=initial_button_response_json)
    else:
        return respond(None, "Unexpected slack command...exiting.")

def lambda_handler(event, context):
    params = parse_qs(event['body'])
    headers = event['headers']
    print event
    print params
    print headers
    timestamp = headers['X-Slack-Request-Timestamp']
    print timestamp

    sig_basestring = 'v0:' + timestamp + ':' + event['body']

    print sig_basestring

    slack_signature_digest = 'v0=' + hmac.new(
           slack_signing_secret,
           msg=sig_basestring,
           digestmod=hashlib.sha256
        ).hexdigest()

    request_signature_digest = headers['X-Slack-Signature']

    print slack_signature_digest
    print request_signature_digest

    if hmac.compare_digest(unicode(slack_signature_digest), unicode(request_signature_digest)):
        if 'command' in params:
            slack_command = params['command'][0]

        print "Slack Command:" + slack_command
        return handle_ic_notification(slack_command, params)

    else:
        logger.error("Request signature does not match expected signature.")
        return respond(Exception('Invalid request token'))
