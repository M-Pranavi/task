# Parse Tester

This script takes a file containing a regex pattern, and a file containing lines of text to test that pattern against.

It will test the regex against each line in the file and record whether the regex matched the line or not as well as storing any named captures, if there are any.

Then it will summarize the results. By default it only outputs a list of the strings that were not matched by the regex, but the `-v` flag will instruct it to report details about all the matched lines as well, and the keys and values of any named captures.

I opted to require the regex to be read from its own file so that one would not have to fiddle with escaping any special characters on the command line. The regex can by copied and pasted from a fluentd parser rule, for example, as-is without modifications.

Do not include the beginning and trailing `/`s in the regex, however.

Good example regex:  `^(?<time>[^ ]+) (?<host>[^ ]+) (?<ident>[a-zA-Z0-9_\/\.\-\(\)]+)(?:\[(?<pid>[-0-9]+)\])?(?:[^\ ]*\:)? *(?<received_syslog_message>.+)$`

Bad example regex (don't include the slashes!):  `/^(?<time>[^ ]+) (?<host>[^ ]+) (?<ident>[a-zA-Z0-9_\/\.\-\(\)]+)(?:\[(?<pid>[-0-9]+)\])?(?:[^\ ]*\:)? *(?<received_syslog_message>.+)$/`


## Usage

```
Usage: ./parse_tester.rb -r regex_pattern_file -f strings_file [-v]
    -r, --regex-file REGEX_FILE      File containing regex to be tested
    -f, --strings-file STRINGS_FILE  File containing list of strings to be tested
    -v, --[no-]verbose               Output results of all matches, not just failed matches
```

## Examples

Given a file in your home directory called `regex` which contains the regex to test
and a file in your home directory called `logs` which contain the lines to test the regex against:

Test the regex and only print the lines that failed to match:
```
parse_tester.rb -r ~/regex -f ~/logs
```

or also print out the lines that match along with any named captures
```
parse_tester.rb -r ~/regex -f ~/logs -v
```

