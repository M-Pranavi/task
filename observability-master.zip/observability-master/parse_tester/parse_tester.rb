#!/usr/bin/env ruby
#
# Given a regex pattern and a list of string, test the regex against every string and report failures
#
require 'optparse'
options = {}

opt_parse = OptionParser.new do |opts|
  opts.banner = "Usage: #{$PROGRAM_NAME} -r regex_pattern_file -f strings_file [-v]"

  opts.on("-r", "--regex-file REGEX_FILE", "File containing regex to be tested") do |option| options[:regex_file] = option
  end

  opts.on("-f", "--strings-file STRINGS_FILE", "File containing list of strings to be tested") do |option|
    options[:strings_file] = option
  end

  opts.on("-v", "--[no-]verbose", "Output results of all matches, not just failed matches") do |option|
    options[:verbose] = option
  end
end

opt_parse.parse %w[--help] if ARGV.empty?

opt_parse.parse!

if options[:regex_file].nil? or options[:strings_file].nil?
    abort(opt_parse.help)
end

regex_file = options[:regex_file]
strings_file = options[:strings_file]
verbose = options[:verbose]

regex = Regexp.compile(File.open(regex_file, &:readline).chomp!)

print "Compiled regex is #{regex}\n\n"

Match = Struct.new(:line, :named_captures)
matches = []
nomatches = []

File.readlines(strings_file).each do |line|
  line.chomp!
  result = line.match(regex)

  if !result then
    nomatches << line
  else
    matches << Match.new(line, result.named_captures)
  end
end

if (matches.length > 0 and verbose) then
  puts "Strings matched:"
  matches.each do |item|
    puts "String: #{item.line}"
    puts "Named captures: #{item.named_captures}"
    puts
  end
end

if nomatches.length > 0 then
  puts "Strings not matched:"
  nomatches.each do |item|
    puts item
  end
  puts
end

puts "Lines matched: #{matches.length{}}"
puts "Lines not matched: #{nomatches.length{}}"
