require 'braintree'
require 'securerandom'
require 'benchmark'
require 'logger'
require 'json'
require 'httparty'
require 'rubygems'
require 'dogapi'

Braintree::Configuration.environment = :production
Braintree::Configuration.merchant_id = ENV['BT_MID']
Braintree::Configuration.public_key = ENV['BT_PUB_KEY']
Braintree::Configuration.private_key = ENV['BT_PRIV_KEY']

sumo_endpoint = ENV['SUMO_ENDPOINT']

api_key= ENV['DATADOG_API_KEY']
dog = Dogapi::Client.new(api_key)

hostname = ENV['DATADOG_HOSTNAME']

class MyLog
  def self.log
    if @logger.nil?
      @logger = Logger.new '/home/braintree/network/network_tests.log'
      @logger.level = Logger::DEBUG
      @logger.datetime_format = '%Y-%m-%d %H:%M:%S '
    end
    @logger
  end
end

begin_time = Time.now

results = Braintree::ClientToken.generate

end_time = Time.now
time = end_time - begin_time

MyLog.log.info "#{time}"

dog.emit_point('opseng.gateway.client.token.time', time, :host => hostname)

HTTParty.post(sumo_endpoint,
  {
    :body => [ { "time" => time, "merchant_id" => Braintree::Configuration.merchant_id, "type_of_request" => 'client_token/create'} ].to_json
  })


mtr_report_json = []

mtr_report = `/usr/bin/mtr -trc5 -f 5 api.braintreegateway.com`
MyLog.log.info "#{mtr_report}"
puts mtr_report
mtr_report = mtr_report.split("\n").drop(2)

mtr_report.each do |item|
  item = item.split(" ")
  hostname = item[1]
  loss = item[2]
  sent = item[3]
  last = item[4]
  avg = item[5]
  best = item[6]
  worst = item[7]
  mtrstring = {:hostname => hostname, :loss => loss, :sent => sent, :last => last, :avg => avg, :best => best, :worst => worst}
  mtr_report_json.push(mtrstring)
end

HTTParty.post(sumo_endpoint,
  {
    :body => mtr_report_json.to_json
  })

#puts client_token
