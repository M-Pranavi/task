#!/usr/bin/env bash
set -euxo pipefail

i="$1"
IFS=- read junk1 junk2 junk3 dimension region <<< $i
eval "aws s3 cp s3://cosmos-log-inventories-$dimension-$region/$i/$i-inventory/$i-unencrypted-objects.csv ./"
