#!/usr/bin/env zsh
set -uxo pipefail

# Try to load $1 followed by common file names
set +u
if [[ -s "${1}" ]]; then
  file="${1}"
elif [[ -s "cosmos-structured-logs-production-$(cat /aws/meta-data/placement/region)-unencrypted-objects.csv" ]]; then
  file="cosmos-structured-logs-production-$(cat /aws/meta-data/placement/region)-unencrypted-objects.csv"
elif [[ -s "cosmos-structured-logs-production-$(cat /aws/meta-data/placement/region)-unencrypted-objects.json" ]]; then
  file="cosmos-structured-logs-production-$(cat /aws/meta-data/placement/region)-unencrypted-objects.json"
else
  echo >2 "Unable to locate suitable csv or json file."
  exit 2
fi
set -u

export region="$(cat /aws/meta-data/placement/region)"
# For 8 parallel processes, 500 lines per process, delete s3 bucket Keys.
#
# The AWS s3api delete-objects^1 docs states the limit is 1000 Keys per request;
# however, given the length and depth of path and filename conventions,
# we are limited^2.
#
# Additionally, AWS rate limits; 500 is a nice round number.
#
# 1: https://docs.aws.amazon.com/cli/latest/reference/s3api/delete-objects.html#description
# 2: https://wiki.debian.org/CommonErrorMessages/ArgumentListTooLong
awk -F\" '{print $4}' "${file}" | \
  xargs -P8 -n500 zsh -c \
  'aws s3api delete-objects --bucket cosmos-structured-logs-production-$region --delete "Objects=[$(printf "{Key=%s}," "$@")],Quiet=true"' _
