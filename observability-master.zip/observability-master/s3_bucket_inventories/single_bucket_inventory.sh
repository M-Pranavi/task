#!/usr/bin/env bash
set -euxo pipefail

i="$1"
mkdir -p "$i"
IFS=- read junk1 junk2 junk3 dimension region <<< $i
echo "Looking in s3://cosmos-log-inventories-$dimension-$region/$i/$i-inventory/data/"
eval "aws s3 cp s3://cosmos-log-inventories-$dimension-$region/$i/$i-inventory/data/ ./$i --recursive"
if [[ "$?" -eq 1 ]]; then
 echo "Error pulling inventories for $i, continuing..."
fi
echo "Concatenating to $i-aggregated.csv\n"
echo "Looking for unencrypted objects and writing their IDs to $i-unencrypted-objects.csv\n"
unpigz -c ./$i/*.csv.gz | awk -F "," '$8 == "\"NOT-SSE\"" {OFS=","; print $1,$2}' > "./$i/$i-unencrypted-objects.csv"

if [[ -s "./$i/$i-unencrypted-objects.csv" ]]; then
  echo "Uploading PUT COPY batch job for $i-unencrypted-objects.csv\n" 
  eval "aws s3 cp ./$i/$i-unencrypted-objects.csv s3://cosmos-log-inventories-$dimension-$region/$i/$i-inventory/"
else
  echo "No NOT-SSE objects found for $i. Moving on....\n"
fi
