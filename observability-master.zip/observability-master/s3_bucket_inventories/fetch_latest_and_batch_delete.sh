#!/usr/bin/env zsh

set -euxo pipefail

trap 'cleanup' ERR EXIT

cleanup() {
  mkdir -p cosmos
  rm -rf cosmos*/
}


region="$(cat /aws/meta-data/placement/region)"
count=0
while test $count -lt 5; do
  cleanup
  ./single_bucket_inventory.sh $(./bucket_encryption.sh | grep $region)
  ./batch_delete.sh cosmos*/cosmos*.csv
  cleanup
  count=$(($count + 1))
done
