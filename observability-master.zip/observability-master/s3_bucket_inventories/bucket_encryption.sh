#!/bin/bash

declare -a inv_buckets=("cosmos-structured-logs-${cosmos_account}-ap-south-1"
"cosmos-structured-logs-${cosmos_account}-ap-southeast-2"
"cosmos-structured-logs-${cosmos_account}-eu-central-1"
"cosmos-structured-logs-${cosmos_account}-us-east-1"
"cosmos-structured-logs-${cosmos_account}-us-east-2"
"cosmos-structured-logs-${cosmos_account}-us-west-2"
)

for i in "${inv_buckets[@]}"
do
  echo "$i"
done
