# DEPRECATED

See [s3-log-scrubber](https://github.braintreeps.com/braintree/s3-log-scrubbing)
